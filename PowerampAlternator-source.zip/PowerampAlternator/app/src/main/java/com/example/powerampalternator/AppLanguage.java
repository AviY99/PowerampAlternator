package com.example.powerampalternator;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/**
 * Application language preference shared by the GUI and foreground service.
 *
 * EN: The app stores an explicit "he" or "en" choice. Before the user chooses,
 *     the device language decides the default. This class contains no playlist logic.
 * HE: האפליקציה שומרת בחירה מפורשת בעברית או באנגלית. לפני בחירה ידנית,
 *     שפת המכשיר קובעת את ברירת המחדל. מחלקה זו אינה משנה את אלגוריתם הפלייליסט.
 */
final class AppLanguage {
    private static final String PREFS = "prefs";
    private static final String KEY_LANGUAGE = "ui_language";
    static final String HEBREW = "he";
    static final String ENGLISH = "en";

    private AppLanguage() {}

    static boolean isHebrew(Context context) {
        SharedPreferences p = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String saved = p.getString(KEY_LANGUAGE, "");
        if (HEBREW.equals(saved)) return true;
        if (ENGLISH.equals(saved)) return false;
        String device = Locale.getDefault().getLanguage();
        return "he".equalsIgnoreCase(device) || "iw".equalsIgnoreCase(device);
    }

    static String text(Context context, String hebrew, String english) {
        return isHebrew(context) ? hebrew : english;
    }

    static void setLanguage(Context context, String language) {
        String safe = HEBREW.equals(language) ? HEBREW : ENGLISH;
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_LANGUAGE, safe).apply();
    }
}
