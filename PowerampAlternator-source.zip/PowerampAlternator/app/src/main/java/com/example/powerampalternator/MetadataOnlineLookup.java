package com.example.powerampalternator;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Read-only Internet metadata suggestions for Playlist Maker 3.4.0.
 *
 * EN: MusicBrainz is queried only after the user explicitly agrees. Results are suggestions;
 * this class never writes audio files and never applies an override by itself. Requests obey
 * MusicBrainz's one-request-per-second limit and identify the application with a User-Agent.
 * HE: MusicBrainz נבדק רק לאחר אישור מפורש של המשתמש. התוצאות הן הצעות בלבד;
 * המחלקה אינה כותבת לקובצי אודיו ואינה מחילה override בעצמה. הבקשות מוגבלות לבקשה
 * אחת בשנייה ומזדהות באמצעות User-Agent תקין.
 */
final class MetadataOnlineLookup {
    static final String SOURCE = "MusicBrainz";
    private static final String API = "https://musicbrainz.org/ws/2/";
    private static final String USER_AGENT = "PlaylistMaker/3.4.0 (https://github.com/AviY99/PowerampAlternator)";
    private static final Object RATE_LOCK = new Object();
    private static long lastRequestAt = 0L;

    static final class Result {
        final String field;
        final String suggestedValue;
        final int confidence;
        final boolean genreSupported;
        final String matchedTitle;
        final String matchedArtist;
        final String matchedAlbum;
        final String matchedYear;
        final List<String> genreCandidates;
        final String detail;

        Result(String field, String suggestedValue, int confidence, boolean genreSupported,
               String matchedTitle, String matchedArtist, String matchedAlbum, String matchedYear,
               List<String> genreCandidates, String detail) {
            this.field = field;
            this.suggestedValue = suggestedValue;
            this.confidence = confidence;
            this.genreSupported = genreSupported;
            this.matchedTitle = matchedTitle;
            this.matchedArtist = matchedArtist;
            this.matchedAlbum = matchedAlbum;
            this.matchedYear = matchedYear;
            this.genreCandidates = genreCandidates;
            this.detail = detail;
        }
    }

    private static final class Match {
        JSONObject recording;
        int searchScore;
        int confidence;
        String title;
        String artist;
        String album;
        String year;
        String recordingId;
        String releaseId;
        String releaseGroupId;
        String albumArtist;
    }

    private static final class GenreItem {
        final String name;
        final int count;
        GenreItem(String name, int count) {
            this.name = name;
            this.count = count;
        }
    }

    static Result lookup(MainActivity.Song song, String field) throws Exception {
        Match match = findBestRecording(song);
        if (match == null) {
            return new Result(field, null, 0, false, null, null, null, null,
                    new ArrayList<>(), "No matching MusicBrainz recording was found.");
        }

        String suggestion = null;
        boolean genreSupported = false;
        List<String> genres = new ArrayList<>();
        int confidence = match.confidence;

        if (MainActivity.META_FIELD_ARTIST.equals(field)) {
            suggestion = match.artist;
        } else if (MainActivity.META_FIELD_ALBUM_ARTIST.equals(field)) {
            suggestion = ensureAlbumArtist(match);
            if (suggestion == null) suggestion = match.artist;
            confidence = Math.max(0, confidence - (match.albumArtist == null ? 8 : 0));
        } else if (MainActivity.META_FIELD_TITLE.equals(field)) {
            suggestion = match.title;
        } else if (MainActivity.META_FIELD_ALBUM.equals(field)) {
            suggestion = match.album;
            if (suggestion == null) confidence = 0;
        } else if (MainActivity.META_FIELD_YEAR.equals(field)) {
            suggestion = match.year;
            if (suggestion == null) confidence = 0;
        } else if (MainActivity.META_FIELD_GENRE.equals(field)) {
            List<GenreItem> genreItems = loadGenres(match);
            for (GenreItem item : genreItems) genres.add(item.name);
            String current = clean(song.genre);
            if (current != null) {
                String currentKey = norm(MainActivity.canonicalGenre(current));
                for (GenreItem item : genreItems) {
                    // Playlist Maker intentionally works with its existing canonical Genre buckets.
                    // Compare the Internet tag through the same mapping so the value shown to the
                    // user is the value that would actually be stored after approval.
                    if (currentKey.equals(norm(MainActivity.canonicalGenre(item.name)))) {
                        genreSupported = true;
                        suggestion = current;
                        break;
                    }
                }
            }
            if (!genreSupported && !genreItems.isEmpty()) {
                suggestion = clean(MainActivity.canonicalGenre(genreItems.get(0).name));
            }
            if (genreItems.isEmpty()) {
                confidence = 0;
            } else {
                int top = Math.max(0, genreItems.get(0).count);
                int total = 0;
                for (GenreItem item : genreItems) total += Math.max(0, item.count);
                int genreStrength = total > 0 ? clamp((int) Math.round(100.0 * top / total), 35, 100) : 55;
                confidence = clamp((int) Math.round(match.confidence * 0.72 + genreStrength * 0.28), 0, 100);
            }
        }

        if (clean(suggestion) == null) confidence = 0;
        return new Result(field, clean(suggestion), confidence, genreSupported,
                match.title, match.artist, match.album, match.year, genres,
                "MusicBrainz recording match score: " + match.searchScore + "/100");
    }

    private static Match findBestRecording(MainActivity.Song song) throws Exception {
        String title = clean(song.displayTitle());
        // Prefer the track Artist for recording identification. Album Artist/Band remains a
        // fallback when the track Artist itself is missing.
        String artist = clean(song.artist);
        if (artist == null) artist = clean(song.artistIdentity());
        if (title == null && artist == null) return null;

        StringBuilder q = new StringBuilder();
        if (title != null) q.append("recording:\"").append(lucene(title)).append("\"");
        if (artist != null) {
            if (q.length() > 0) q.append(" AND ");
            q.append("artist:\"").append(lucene(artist)).append("\"");
        }
        String url = API + "recording/?query=" + enc(q.toString()) + "&fmt=json&limit=5";
        JSONObject root = getJson(url);
        JSONArray recordings = root.optJSONArray("recordings");
        if (recordings == null || recordings.length() == 0) return null;

        Match best = null;
        int bestRank = Integer.MIN_VALUE;
        for (int i = 0; i < recordings.length(); i++) {
            JSONObject r = recordings.optJSONObject(i);
            if (r == null) continue;
            Match m = parseMatch(r, song);
            int rank = m.searchScore;
            if (title != null && norm(title).equals(norm(m.title))) rank += 14;
            if (artist != null && artistCreditMatches(artist, m.artist)) rank += 14;
            String currentAlbum = clean(song.album);
            if (currentAlbum != null && m.album != null && norm(currentAlbum).equals(norm(m.album))) rank += 8;
            if (rank > bestRank) {
                bestRank = rank;
                best = m;
            }
        }
        if (best == null) return null;

        int identity = best.searchScore;
        if (title != null && norm(title).equals(norm(best.title))) identity += 5;
        if (artist != null && artistCreditMatches(artist, best.artist)) identity += 5;
        // A title-only or artist-only lookup is intrinsically more ambiguous, even when the
        // search engine returns a high score. Keep the UI confidence conservative.
        if (title == null) identity -= 25;
        if (artist == null) identity -= 20;
        best.confidence = clamp(identity, 0, 100);
        return best;
    }

    private static Match parseMatch(JSONObject r, MainActivity.Song song) {
        Match m = new Match();
        m.recording = r;
        m.recordingId = clean(r.optString("id", null));
        m.searchScore = parseInt(r.opt("score"), 0);
        m.title = clean(r.optString("title", null));
        m.artist = artistCredit(r.optJSONArray("artist-credit"));
        m.year = yearFromDate(clean(r.optString("first-release-date", null)));

        JSONArray releases = r.optJSONArray("releases");
        JSONObject selected = selectRelease(releases, song.album);
        if (selected != null) {
            m.album = clean(selected.optString("title", null));
            m.releaseId = clean(selected.optString("id", null));
            if (m.year == null) m.year = yearFromDate(clean(selected.optString("date", null)));
            JSONObject rg = selected.optJSONObject("release-group");
            if (rg != null) m.releaseGroupId = clean(rg.optString("id", null));
            m.albumArtist = artistCredit(selected.optJSONArray("artist-credit"));
        }
        return m;
    }

    private static JSONObject selectRelease(JSONArray releases, String wantedAlbum) {
        if (releases == null || releases.length() == 0) return null;
        String wanted = clean(wantedAlbum);
        JSONObject firstOfficial = null;
        for (int i = 0; i < releases.length(); i++) {
            JSONObject release = releases.optJSONObject(i);
            if (release == null) continue;
            String title = clean(release.optString("title", null));
            if (wanted != null && title != null && norm(wanted).equals(norm(title))) return release;
            if (firstOfficial == null && "official".equals(norm(release.optString("status", "")))) firstOfficial = release;
        }
        if (firstOfficial != null) return firstOfficial;
        return releases.optJSONObject(0);
    }

    private static String ensureAlbumArtist(Match match) throws Exception {
        if (clean(match.albumArtist) != null) return match.albumArtist;
        if (clean(match.releaseId) == null) return null;
        JSONObject release = getJson(API + "release/" + encPath(match.releaseId)
                + "?inc=artist-credits+release-groups&fmt=json");
        match.albumArtist = artistCredit(release.optJSONArray("artist-credit"));
        return clean(match.albumArtist);
    }

    private static List<GenreItem> loadGenres(Match match) throws Exception {
        List<GenreItem> out = new ArrayList<>();
        if (clean(match.recordingId) != null) {
            JSONObject recording = getJson(API + "recording/" + encPath(match.recordingId)
                    + "?inc=genres+releases+release-groups+artist-credits&fmt=json");
            collectGenres(recording.optJSONArray("genres"), out);
            if (match.releaseGroupId == null) {
                JSONArray groups = recording.optJSONArray("release-groups");
                if (groups != null && groups.length() > 0) {
                    JSONObject rg = groups.optJSONObject(0);
                    if (rg != null) match.releaseGroupId = clean(rg.optString("id", null));
                }
            }
            if (match.releaseGroupId == null) {
                JSONArray releases = recording.optJSONArray("releases");
                JSONObject rel = selectRelease(releases, match.album);
                if (rel != null) {
                    JSONObject rg = rel.optJSONObject("release-group");
                    if (rg != null) match.releaseGroupId = clean(rg.optString("id", null));
                }
            }
        }
        if (out.isEmpty() && clean(match.releaseGroupId) != null) {
            JSONObject rg = getJson(API + "release-group/" + encPath(match.releaseGroupId)
                    + "?inc=genres+artist-credits&fmt=json");
            collectGenres(rg.optJSONArray("genres"), out);
        }
        out.sort(Comparator.comparingInt((GenreItem x) -> x.count).reversed().thenComparing(x -> x.name, String.CASE_INSENSITIVE_ORDER));
        return out;
    }

    private static void collectGenres(JSONArray arr, List<GenreItem> out) {
        if (arr == null) return;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject g = arr.optJSONObject(i);
            if (g == null) continue;
            String name = clean(g.optString("name", null));
            if (name == null) continue;
            int count = parseInt(g.opt("count"), 0);
            boolean merged = false;
            for (int j = 0; j < out.size(); j++) {
                GenreItem old = out.get(j);
                if (norm(old.name).equals(norm(name))) {
                    if (count > old.count) out.set(j, new GenreItem(old.name, count));
                    merged = true;
                    break;
                }
            }
            if (!merged) out.add(new GenreItem(name, count));
        }
    }

    private static String artistCredit(JSONArray credit) {
        if (credit == null || credit.length() == 0) return null;
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < credit.length(); i++) {
            JSONObject c = credit.optJSONObject(i);
            if (c == null) continue;
            String name = clean(c.optString("name", null));
            if (name == null) {
                JSONObject artist = c.optJSONObject("artist");
                if (artist != null) name = clean(artist.optString("name", null));
            }
            if (name == null) continue;
            if (out.length() > 0 && !endsWithJoin(out)) out.append(" & ");
            out.append(name);
            String join = c.optString("joinphrase", "");
            if (join != null) out.append(join);
        }
        return clean(out.toString());
    }

    private static boolean endsWithJoin(StringBuilder s) {
        if (s.length() == 0) return false;
        char c = s.charAt(s.length() - 1);
        return Character.isWhitespace(c) || c == '&' || c == ',' || c == '/';
    }

    private static boolean artistCreditMatches(String wanted, String found) {
        String a = norm(wanted);
        String b = norm(found);
        if (a.isEmpty() || b.isEmpty()) return false;
        return a.equals(b) || b.contains(a) || a.contains(b);
    }

    private static JSONObject getJson(String urlText) throws Exception {
        Exception last = null;
        for (int attempt = 0; attempt < 2; attempt++) {
            waitForRateLimit();
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(urlText).openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(20000);
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("User-Agent", USER_AGENT);
                int code = conn.getResponseCode();
                InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
                String body = read(stream);
                if (code >= 200 && code < 300) return new JSONObject(body);
                if (code == 503 || code == 429) {
                    last = new IllegalStateException("MusicBrainz is temporarily rate-limiting requests (HTTP " + code + ").");
                    continue;
                }
                throw new IllegalStateException("MusicBrainz request failed (HTTP " + code + ").");
            } catch (Exception e) {
                last = e;
                if (attempt == 0) continue;
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        throw last == null ? new IllegalStateException("MusicBrainz request failed.") : last;
    }

    private static void waitForRateLimit() throws InterruptedException {
        synchronized (RATE_LOCK) {
            long now = System.currentTimeMillis();
            long wait = 1100L - (now - lastRequestAt);
            if (wait > 0) Thread.sleep(wait);
            lastRequestAt = System.currentTimeMillis();
        }
    }

    private static String read(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) out.append(line);
        }
        return out.toString();
    }

    private static String yearFromDate(String date) {
        if (date == null) return null;
        for (int i = 0; i + 4 <= date.length(); i++) {
            String part = date.substring(i, i + 4);
            if (part.matches("\\d{4}")) {
                int year = parseInt(part, 0);
                if (year >= 1000 && year <= 2999) return part;
            }
        }
        return null;
    }

    private static String lucene(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String enc(String value) throws Exception {
        return URLEncoder.encode(value, "UTF-8");
    }

    private static String encPath(String value) throws Exception {
        return URLEncoder.encode(value, "UTF-8").replace("+", "%20");
    }

    private static int parseInt(Object value, int fallback) {
        if (value == null) return fallback;
        try { return Integer.parseInt(String.valueOf(value)); }
        catch (Exception ignored) { return fallback; }
    }

    private static String clean(String value) {
        if (value == null) return null;
        String s = value.trim();
        return s.isEmpty() ? null : s;
    }

    private static String norm(String value) {
        String s = clean(value);
        if (s == null) return "";
        s = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        s = s.toLowerCase(Locale.ROOT).replace('&', ' ');
        return s.replaceAll("[^\\p{L}\\p{N}]+", " ").trim().replaceAll("\\s+", " ");
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private MetadataOnlineLookup() {}
}
