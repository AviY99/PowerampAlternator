package com.example.powerampalternator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Resumable foreground worker for analysis and playlist creation.
 *
 * EN: Persists task identity/progress, owns the worker thread and WakeLock, restores the
 * analysis snapshot after process recreation, and posts a separate completion notification.
 * HE: שומר את זהות המשימה וההתקדמות, מנהל Worker ו-WakeLock, משחזר snapshot לאחר
 * יצירת תהליך מחדש ושולח התראת סיום נפרדת מהתראת העבודה.
 */
public class BackgroundWorkService extends Service {
    private static final String CHANNEL_ID = "playlist_background_work";
    private static final String RESULT_CHANNEL_ID = "playlist_results";
    private static final int NOTIFICATION_ID = 2401;
    private static final int RESULT_NOTIFICATION_ID = 2402;
    private static final String STATE_PREFS = "background_job_state";
    private static final String SNAPSHOT_FILE = "last_analysis_snapshot.json";

    private static final String KEY_BUSY = "busy";
    private static final String KEY_STATUS = "status";
    private static final String KEY_PROGRESS = "progress";
    private static final String KEY_TASK_TYPE = "task_type";
    private static final String KEY_TREE_URI = "task_tree_uri";
    private static final String KEY_OUTPUT_TREE_URI = "task_output_tree_uri";
    private static final String KEY_MODE = "task_mode";
    private static final String KEY_PLAYLIST_NAME = "task_playlist_name";
    private static final String KEY_ANALYSIS_READY = "analysis_ready";
    private static final String KEY_ANALYSIS_REVISION = "analysis_revision";
    private static final String KEY_SKIPPED = "analysis_skipped";
    private static final String KEY_CACHE_HITS = "analysis_cache_hits";
    private static final String KEY_RESULT_TEXT = "result_text";
    private static final String KEY_PLAYLIST_READY = "playlist_ready";
    private static final String KEY_REPORT_ENABLED = "task_report_enabled";
    private static final String KEY_LAST_DURATION_MS = "last_duration_ms";
    private static final String KEY_FILTER_MODE = "task_filter_mode";
    private static final String KEY_FILTER_ARTIST = "task_filter_artist";
    private static final String KEY_FILTER_GENRE = "task_filter_genre";
    private static final String KEY_SORT_STRATEGY = "task_sort_strategy";
    private static final String KEY_DIRECT_SORT_CRITERIA = "task_direct_sort_criteria";

    private static final String TASK_ANALYZE = "ANALYZE";
    private static final String TASK_CREATE = "CREATE";

    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private static final Object WORK_GUARD = new Object();
    private static volatile boolean workerActive = false;

    private static final Object WAKE_LOCK_GUARD = new Object();
    private static PowerManager.WakeLock wakeLock;

    private static final Object SNAPSHOT_GUARD = new Object();
    private static List<MainActivity.Song> snapshotCache = new ArrayList<>();
    private static boolean snapshotLoaded = false;

    private static volatile String currentText = "";
    private static volatile int currentProgress = 0;
    private static volatile boolean currentIndeterminate = true;

    @Override
    public void onCreate() {
        super.onCreate();
        ensureChannel(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences p = prefs(this);
        currentText = p.getString(KEY_STATUS, AppLanguage.text(this, "מחדש עבודה ברקע…", "Resuming background work…"));
        currentProgress = p.getInt(KEY_PROGRESS, 0);
        currentIndeterminate = currentProgress <= 0;
        startForeground(NOTIFICATION_ID, buildNotification(this, currentText, currentProgress, currentIndeterminate));
        ensureWakeLock(getApplicationContext());
        resumePersistedTask();
        // Android may recreate this service and redeliver the original start intent.
        // The real task definition is persisted, so duplicate intents are harmless.
        return START_REDELIVER_INTENT;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        // If Android is destroying the process during a busy task, persisted KEY_BUSY remains
        // true and the redelivered service resumes it. Release the process-local wake lock here.
        releaseWakeLock();
        super.onDestroy();
    }

    public static void startAnalysis(Context context, Uri treeUri) {
        Context app = context.getApplicationContext();
        SharedPreferences.Editor e = prefs(app).edit();
        e.putBoolean(KEY_BUSY, true)
                .putString(KEY_STATUS, AppLanguage.text(app, "סורק קבצי מוזיקה…", "Scanning music files…"))
                .putInt(KEY_PROGRESS, 0)
                .putString(KEY_TASK_TYPE, TASK_ANALYZE)
                .putString(KEY_TREE_URI, treeUri.toString())
                .remove(KEY_PLAYLIST_NAME)
                .putInt(KEY_MODE, 0)
                .putBoolean(KEY_ANALYSIS_READY, false)
                .putBoolean(KEY_PLAYLIST_READY, false)
                .putLong(KEY_LAST_DURATION_MS, 0L)
                .putString(KEY_RESULT_TEXT, "");
        e.commit();
        cancelResultNotification(app);
        startForegroundServiceCompat(app);
    }

    public static void startPlaylist(Context context, Uri treeUri, Uri outputTreeUri, int mode, String playlistName,
                                     boolean reportEnabled, int filterMode, String artistFilter,
                                     String genreFilter, int sortStrategy, String directSortCriteria) {
        Context app = context.getApplicationContext();
        SharedPreferences.Editor e = prefs(app).edit();
        e.putBoolean(KEY_BUSY, true)
                .putString(KEY_STATUS, AppLanguage.text(app, "מכין את הפלייליסט…", "Preparing playlist…"))
                .putInt(KEY_PROGRESS, 0)
                .putString(KEY_TASK_TYPE, TASK_CREATE)
                .putString(KEY_TREE_URI, treeUri.toString())
                .putString(KEY_OUTPUT_TREE_URI, outputTreeUri == null ? treeUri.toString() : outputTreeUri.toString())
                .putInt(KEY_MODE, mode)
                .putString(KEY_PLAYLIST_NAME, playlistName == null ? "" : playlistName)
                .putBoolean(KEY_REPORT_ENABLED, reportEnabled)
                .putInt(KEY_FILTER_MODE, filterMode)
                .putString(KEY_FILTER_ARTIST, artistFilter == null ? "" : artistFilter)
                .putString(KEY_FILTER_GENRE, genreFilter == null ? "" : genreFilter)
                .putInt(KEY_SORT_STRATEGY, sortStrategy)
                .putString(KEY_DIRECT_SORT_CRITERIA, directSortCriteria == null ? "" : directSortCriteria)
                .putBoolean(KEY_PLAYLIST_READY, false)
                .putLong(KEY_LAST_DURATION_MS, 0L)
                .putString(KEY_RESULT_TEXT, "");
        e.commit();
        cancelResultNotification(app);
        startForegroundServiceCompat(app);
    }

    private static void startForegroundServiceCompat(Context app) {
        Intent intent = new Intent(app, BackgroundWorkService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) app.startForegroundService(intent);
        else app.startService(intent);
    }

    // ================== RESUMABLE BACKGROUND TASK - START ==================
    // EN: Reads the persisted task descriptor and starts exactly one worker. If Android
    //     recreated the service, the saved tree URI/task type and analysis snapshot allow
    //     work to resume without the Activity owning the job.
    // HE: קורא את תיאור המשימה השמור ומפעיל Worker יחיד. לאחר יצירת השירות מחדש,
    //     URI/סוג המשימה וה-snapshot מאפשרים חידוש ללא תלות ב-Activity.
    private void resumePersistedTask() {
        synchronized (WORK_GUARD) {
            if (workerActive) return;
            State state = getState(getApplicationContext());
            if (!state.busy) {
                stopForegroundCompat();
                stopSelf();
                releaseWakeLock();
                return;
            }
            final String type = state.taskType;
            final String treeText = prefs(this).getString(KEY_TREE_URI, "");
            if (treeText == null || treeText.trim().isEmpty() || type.isEmpty()) {
                failTask(AppLanguage.text(this, "שגיאה: לא ניתן לשחזר את פרטי העבודה ברקע.", "Error: background task details could not be restored."));
                return;
            }
            workerActive = true;
            ensureWakeLock(getApplicationContext());
            WORKER.execute(() -> {
                try {
                    if (TASK_ANALYZE.equals(type)) {
                        runAnalysisTask(Uri.parse(treeText));
                    } else if (TASK_CREATE.equals(type)) {
                        runCreateTask(Uri.parse(treeText));
                    } else {
                        throw new IllegalStateException(AppLanguage.text(this, "סוג משימה לא מוכר", "Unknown task type"));
                    }
                } catch (Exception e) {
                    failTask(AppLanguage.text(this, "שגיאה: ", "Error: ") + MainActivity.safeMessage(e));
                } finally {
                    workerActive = false;
                }
            });
        }
    }

    // =================== RESUMABLE BACKGROUND TASK - END ===================

    private void runAnalysisTask(Uri treeUri) throws Exception {
        long startedAt = System.currentTimeMillis();
        MainActivity.AnalysisResult result = MainActivity.performAnalysis(
                getApplicationContext(), treeUri, this::publishProgress);
        long durationMs = Math.max(0L, System.currentTimeMillis() - startedAt);
        setAnalysisSnapshot(getApplicationContext(), result.songs, result.skipped, result.cacheHits);
        SharedPreferences.Editor e = prefs(this).edit();
        e.putBoolean(KEY_BUSY, false)
                .putString(KEY_STATUS, AppLanguage.text(this, "הניתוח הסתיים בהצלחה. אפשר לעבור לתוצאות וליצור פלייליסט.", "Analysis completed successfully. You can review results and create a playlist."))
                .putInt(KEY_PROGRESS, 100)
                .putString(KEY_TASK_TYPE, "")
                .putBoolean(KEY_ANALYSIS_READY, true)
                .putBoolean(KEY_PLAYLIST_READY, false)
                .putLong(KEY_LAST_DURATION_MS, durationMs)
                .putString(KEY_RESULT_TEXT, "");
        e.commit();
        finishService(AppLanguage.text(this, "הניתוח הסתיים", "Analysis complete"), result.songs.size() + AppLanguage.text(this, " שירים מוכנים לבניית פלייליסט.", " songs are ready for playlist creation."), false);
    }

    private void runCreateTask(Uri treeUri) throws Exception {
        long startedAt = System.currentTimeMillis();
        List<MainActivity.Song> source = getAnalysisSnapshot(getApplicationContext());
        if (source.size() < 2) {
            throw new IllegalStateException(AppLanguage.text(this, "ניתוח השירים השמור לא נמצא. יש לבצע ניתוח מחדש.", "Saved song analysis was not found. Run analysis again."));
        }
        SharedPreferences p = prefs(this);
        int mode = p.getInt(KEY_MODE, 0);
        String playlistName = p.getString(KEY_PLAYLIST_NAME, "");
        boolean reportEnabled = p.getBoolean(KEY_REPORT_ENABLED, true);
        int filterMode = p.getInt(KEY_FILTER_MODE, MainActivity.FILTER_ALL);
        String artistFilter = p.getString(KEY_FILTER_ARTIST, "");
        String genreFilter = p.getString(KEY_FILTER_GENRE, "");
        int sortStrategy = p.getInt(KEY_SORT_STRATEGY, MainActivity.SORT_SMART);
        String directSortCriteria = p.getString(KEY_DIRECT_SORT_CRITERIA, "");
        String outputTreeText = p.getString(KEY_OUTPUT_TREE_URI, treeUri.toString());
        Uri outputTreeUri = outputTreeText == null || outputTreeText.trim().isEmpty()
                ? treeUri : Uri.parse(outputTreeText);

        // ================= PLAYLIST OUTPUT RESTORE - START =================
        // EN: The output SAF tree is persisted with the CREATE task independently of the music
        // source tree, so process recreation writes to exactly the folder the user selected.
        // Older tasks without this key safely fall back to the music tree.
        // HE: URI הפלט נשמר כחלק ממשימת CREATE בנפרד מתיקיית המוזיקה, ולכן שחזור
        // תהליך ממשיך לכתוב לאותה תיקייה. משימות ישנות חוזרות בבטחה לתיקיית המוזיקה.
        // ================== PLAYLIST OUTPUT RESTORE - END ==================

        // ================= BACKGROUND FILTER APPLICATION - START =================
        // EN: Apply the persisted playlist filter to the full analysis snapshot before the
        // selected ordering engine. Filter sets are persisted with the task, so process
        // recreation resumes the same subset for either Smart Sort or Direct Sort.
        // HE: החלת הסינון השמור על snapshot המלא לפני מנוע הסידור שנבחר. קבוצות
        // הבחירה נשמרות עם המשימה ולכן שחזור ממשיך עם אותה קבוצת שירים.
        List<MainActivity.Song> filtered = MainActivity.filterSongsForPlaylist(
                source, filterMode, artistFilter, genreFilter);
        if (filtered.size() < 2) {
            throw new IllegalStateException(AppLanguage.text(this,
                    "הסינון הנוכחי מכיל פחות משני שירים.",
                    "The current filter contains fewer than two songs."));
        }
        // ================== BACKGROUND FILTER APPLICATION - END ==================

        // ====================== DIRECT SORT PREPARATION - START ======================
        // EN: Year was not stored by 3.2.1. If Direct Sort needs it, enrich only the selected
        // songs with a lightweight metadata read and persist the updated snapshot. Smart Sort
        // never enters this path and its scheduler remains untouched.
        // HE: גרסה 3.2.1 לא שמרה שנה. אם Direct Sort משתמש בשנה, נקראת רק תגית השנה
        // לשירים המסוננים ונשמר snapshot מעודכן. Smart Sort אינו עובר במסלול הזה.
        if (sortStrategy == MainActivity.SORT_DIRECT && MainActivity.directSortUsesYear(directSortCriteria)) {
            publishProgress(AppLanguage.text(this, "קורא תגיות שנה עבור Direct Sort…",
                    "Reading year metadata for Direct Sort…"), 1);
            int refreshedYears = MainActivity.ensureYearMetadata(getApplicationContext(), filtered);
            if (refreshedYears > 0) {
                State current = getState(getApplicationContext());
                setAnalysisSnapshot(getApplicationContext(), source, current.skipped, current.cacheHits);
            }
        }
        // ======================= DIRECT SORT PREPARATION - END =======================

        String filterDescription = MainActivity.filterDescription(this, filterMode, artistFilter, genreFilter);
        MainActivity.PlaylistResult result = MainActivity.performPlaylist(
                getApplicationContext(), outputTreeUri, filtered, sortStrategy, mode, directSortCriteria,
                playlistName, reportEnabled, filterDescription, this::publishProgress);
        long durationMs = Math.max(0L, System.currentTimeMillis() - startedAt);

        String summary = MainActivity.buildPlaylistResultSummary(this, result.playlist, sortStrategy, mode,
                directSortCriteria, durationMs);
        StringBuilder resultText = new StringBuilder(summary)
                .append(AppLanguage.text(this, "\n\nסינון: ", "\n\nFilter: "))
                .append(filterDescription)
                .append(AppLanguage.text(this, "\nקובץ: ", "\nFile: ")).append(result.playlistName)
                .append(AppLanguage.text(this, "\nנשמר ב: ", "\nSaved in: ")).append(result.savedAt);
        if (result.reportName != null && !result.reportName.isEmpty()) {
            resultText.append(AppLanguage.text(this, "\nקובץ בדיקה: ", "\nDiagnostic file: ")).append(result.reportName);
        } else {
            resultText.append(AppLanguage.text(this, "\nקובץ בדיקה: לא נוצר לפי הבחירה שלך.", "\nDiagnostic file: not created by your choice."));
        }
        if (result.mediaScannerRequested) {
            resultText.append(AppLanguage.text(this,
                    "\nרענון Android: נשלחה בקשת MediaScanner כללית.",
                    "\nAndroid refresh: generic MediaScanner request sent."));
        } else {
            resultText.append(AppLanguage.text(this,
                    "\nרענון Android: הקובץ נשמר וה-provider עודכן; ייתכן שאפליקציות מסוימות ידרשו Rescan.",
                    "\nAndroid refresh: file saved and provider notified; some apps may still require Rescan."));
        }
        if (result.warning != null && !result.warning.isEmpty()) resultText.append("\n").append(result.warning);

        SharedPreferences.Editor e = prefs(this).edit();
        e.putBoolean(KEY_BUSY, false)
                .putString(KEY_STATUS, AppLanguage.text(this, "הפלייליסט נוצר בהצלחה ונשמר בתיקייה שבחרת.", "Playlist created successfully and saved in the selected folder."))
                .putInt(KEY_PROGRESS, 100)
                .putString(KEY_TASK_TYPE, "")
                .putBoolean(KEY_PLAYLIST_READY, true)
                .putLong(KEY_LAST_DURATION_MS, durationMs)
                .putString(KEY_RESULT_TEXT, resultText.toString());
        e.commit();
        finishService(AppLanguage.text(this, "הפלייליסט מוכן", "Playlist ready"), result.playlist.size() + AppLanguage.text(this, " שירים נוצרו בהצלחה.", " songs were created successfully."), false);
    }

    private void publishProgress(String text, int progress) {
        update(getApplicationContext(), text, progress);
    }

    private void failTask(String text) {
        String detail = text == null || text.trim().isEmpty() ? AppLanguage.text(this, "אירעה שגיאה לא צפויה.", "An unexpected error occurred.") : text.trim();
        if (detail.startsWith("שגיאה:")) detail = detail.substring("שגיאה:".length()).trim();
        if (detail.startsWith("Error:")) detail = detail.substring("Error:".length()).trim();
        String status = AppLanguage.text(this, "לא ניתן להשלים את העבודה: ", "Could not complete the task: ") + detail;
        prefs(this).edit()
                .putBoolean(KEY_BUSY, false)
                .putString(KEY_STATUS, status)
                .putInt(KEY_PROGRESS, 0)
                .putString(KEY_TASK_TYPE, "")
                .putString(KEY_RESULT_TEXT, AppLanguage.text(this, "העבודה לא הושלמה.\n", "The task did not complete.\n") + detail + AppLanguage.text(this, "\nאפשר לפתוח את האפליקציה ולנסות שוב.", "\nOpen the app and try again."))
                .commit();
        finishService(AppLanguage.text(this, "העבודה לא הושלמה", "Task not completed"), detail, true);
    }

    private void finishService(String title, String text, boolean error) {
        State state = getState(getApplicationContext());
        currentText = state.status;
        currentProgress = state.progress;
        currentIndeterminate = false;
        stopForegroundCompat();
        showResultNotification(this, title, text, error);
        releaseWakeLock();
        stopSelf();
    }

    private void stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
    }

    public static void update(Context context, String text, int progressPercent) {
        Context app = context.getApplicationContext();
        currentText = text == null ? AppLanguage.text(context, "עובד ברקע…", "Working in background…") : text;
        currentProgress = Math.max(0, Math.min(100, progressPercent));
        currentIndeterminate = false;
        prefs(app).edit()
                .putBoolean(KEY_BUSY, true)
                .putString(KEY_STATUS, currentText)
                .putInt(KEY_PROGRESS, currentProgress)
                .commit();
        ensureChannel(app);
        NotificationManager manager = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(app, currentText, currentProgress, false));
    }

    public static boolean isWorkerActive() {
        return workerActive;
    }

    public static State getState(Context context) {
        SharedPreferences p = prefs(context.getApplicationContext());
        return new State(
                p.getBoolean(KEY_BUSY, false),
                p.getString(KEY_STATUS, ""),
                p.getInt(KEY_PROGRESS, 0),
                p.getString(KEY_TASK_TYPE, ""),
                p.getBoolean(KEY_ANALYSIS_READY, false),
                p.getInt(KEY_ANALYSIS_REVISION, 0),
                p.getInt(KEY_SKIPPED, 0),
                p.getInt(KEY_CACHE_HITS, 0),
                p.getString(KEY_RESULT_TEXT, ""),
                p.getBoolean(KEY_PLAYLIST_READY, false),
                p.getLong(KEY_LAST_DURATION_MS, 0L)
        );
    }

    public static final class State {
        public final boolean busy;
        public final String status;
        public final int progress;
        public final String taskType;
        public final boolean analysisReady;
        public final int analysisRevision;
        public final int skipped;
        public final int cacheHits;
        public final String resultText;
        public final boolean playlistReady;
        public final long lastDurationMs;

        State(boolean busy, String status, int progress, String taskType, boolean analysisReady,
              int analysisRevision, int skipped, int cacheHits, String resultText, boolean playlistReady,
              long lastDurationMs) {
            this.busy = busy;
            this.status = status == null ? "" : status;
            this.progress = Math.max(0, Math.min(100, progress));
            this.taskType = taskType == null ? "" : taskType;
            this.analysisReady = analysisReady;
            this.analysisRevision = analysisRevision;
            this.skipped = skipped;
            this.cacheHits = cacheHits;
            this.resultText = resultText == null ? "" : resultText;
            this.playlistReady = playlistReady;
            this.lastDurationMs = Math.max(0L, lastDurationMs);
        }
    }

    public static void setAnalysisSnapshot(Context context, List<MainActivity.Song> songs, int skipped, int cacheHits) {
        Context app = context.getApplicationContext();
        synchronized (SNAPSHOT_GUARD) {
            snapshotCache = cloneSongs(songs);
            snapshotLoaded = true;
            writeSnapshotFile(app, snapshotCache);
        }
        SharedPreferences p = prefs(app);
        int revision = p.getInt(KEY_ANALYSIS_REVISION, 0) + 1;
        p.edit()
                .putBoolean(KEY_ANALYSIS_READY, songs != null && songs.size() >= 2)
                .putInt(KEY_ANALYSIS_REVISION, revision)
                .putInt(KEY_SKIPPED, skipped)
                .putInt(KEY_CACHE_HITS, cacheHits)
                .commit();
    }

    public static List<MainActivity.Song> getAnalysisSnapshot(Context context) {
        Context app = context.getApplicationContext();
        synchronized (SNAPSHOT_GUARD) {
            if (!snapshotLoaded) {
                snapshotCache = readSnapshotFile(app);
                snapshotLoaded = true;
            }
            return cloneSongs(snapshotCache);
        }
    }

    public static void clearAnalysisSnapshot(Context context) {
        Context app = context.getApplicationContext();
        synchronized (SNAPSHOT_GUARD) {
            snapshotCache = new ArrayList<>();
            snapshotLoaded = true;
            File f = new File(app.getFilesDir(), SNAPSHOT_FILE);
            if (f.exists()) f.delete();
        }
        SharedPreferences p = prefs(app);
        p.edit()
                .putBoolean(KEY_BUSY, false)
                .putString(KEY_STATUS, AppLanguage.text(context, "מוכן לסריקה.", "Ready to scan."))
                .putInt(KEY_PROGRESS, 0)
                .putString(KEY_TASK_TYPE, "")
                .putBoolean(KEY_ANALYSIS_READY, false)
                .putBoolean(KEY_PLAYLIST_READY, false)
                .putString(KEY_RESULT_TEXT, "")
                .putLong(KEY_LAST_DURATION_MS, 0L)
                .putInt(KEY_ANALYSIS_REVISION, p.getInt(KEY_ANALYSIS_REVISION, 0) + 1)
                .commit();
    }

    private static void writeSnapshotFile(Context context, List<MainActivity.Song> songs) {
        File target = new File(context.getFilesDir(), SNAPSHOT_FILE);
        File temp = new File(context.getFilesDir(), SNAPSHOT_FILE + ".tmp");
        try {
            JSONArray arr = new JSONArray();
            if (songs != null) {
                for (MainActivity.Song s : songs) {
                    JSONObject o = new JSONObject();
                    o.put("name", s.name);
                    o.put("relativePath", s.relativePath);
                    o.put("documentId", s.documentId);
                    o.put("uri", s.uri.toString());
                    o.put("size", s.size);
                    o.put("lastModified", s.lastModified);
                    o.put("analyzed", s.analyzed);
                    o.put("rmsDb", s.rmsDb);
                    o.put("bpm", s.bpm);
                    o.put("activity", s.activity);
                    o.put("energy", s.energy);
                    putNullable(o, "title", s.title);
                    putNullable(o, "artist", s.artist);
                    putNullable(o, "albumArtist", s.albumArtist);
                    putNullable(o, "album", s.album);
                    putNullable(o, "genre", s.genre);
                    if (s.yearMetadataLoaded) {
                        if (s.year > 0) o.put("year", s.year); else o.put("year", JSONObject.NULL);
                    }
                    putNullable(o, "genreSource", s.genreSource);
                    putNullable(o, "artistSource", s.artistSource);
                    o.put("embeddedPresenceLoaded", s.embeddedMetadataPresenceLoaded);
                    if (s.embeddedMetadataPresenceLoaded) {
                        o.put("embeddedArtist", s.embeddedArtist);
                        o.put("embeddedAlbumArtist", s.embeddedAlbumArtist);
                        o.put("embeddedTitle", s.embeddedTitle);
                        o.put("embeddedAlbum", s.embeddedAlbum);
                        o.put("embeddedYear", s.embeddedYear);
                        o.put("embeddedGenre", s.embeddedGenre);
                    }
                    o.put("overrideArtistSet", s.overrideArtistSet);
                    o.put("overrideAlbumArtistSet", s.overrideAlbumArtistSet);
                    o.put("overrideTitleSet", s.overrideTitleSet);
                    o.put("overrideAlbumSet", s.overrideAlbumSet);
                    o.put("overrideYearSet", s.overrideYearSet);
                    o.put("overrideGenreSet", s.overrideGenreSet);
                    arr.put(o);
                }
            }
            try (FileWriter writer = new FileWriter(temp, false)) {
                writer.write(arr.toString());
                writer.flush();
            }
            if (target.exists()) target.delete();
            if (!temp.renameTo(target)) {
                try (FileWriter writer = new FileWriter(target, false)) {
                    writer.write(arr.toString());
                }
                temp.delete();
            }
        } catch (Exception ignored) {
            temp.delete();
        }
    }

    private static List<MainActivity.Song> readSnapshotFile(Context context) {
        List<MainActivity.Song> out = new ArrayList<>();
        File f = new File(context.getFilesDir(), SNAPSHOT_FILE);
        if (!f.exists()) return out;
        try {
            StringBuilder text = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(f))) {
                String line;
                while ((line = reader.readLine()) != null) text.append(line);
            }
            JSONArray arr = new JSONArray(text.toString());
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                MainActivity.Song s = new MainActivity.Song(
                        o.getString("name"), o.getString("relativePath"), o.getString("documentId"),
                        Uri.parse(o.getString("uri")), o.optLong("size", 0), o.optLong("lastModified", 0));
                s.analyzed = o.optBoolean("analyzed", true);
                s.rmsDb = o.optDouble("rmsDb", 0);
                s.bpm = o.optDouble("bpm", 0);
                s.activity = o.optDouble("activity", 0);
                s.energy = o.optDouble("energy", 0.5);
                s.title = jsonNullToString(o, "title");
                s.artist = jsonNullToString(o, "artist");
                s.albumArtist = jsonNullToString(o, "albumArtist");
                s.album = jsonNullToString(o, "album");
                s.genre = jsonNullToString(o, "genre");
                s.yearMetadataLoaded = o.has("year");
                s.year = s.yearMetadataLoaded ? o.optInt("year", 0) : 0;
                s.genreSource = jsonNullToString(o, "genreSource");
                s.artistSource = jsonNullToString(o, "artistSource");
                s.embeddedMetadataPresenceLoaded = o.optBoolean("embeddedPresenceLoaded", false);
                if (s.embeddedMetadataPresenceLoaded) {
                    s.embeddedArtist = o.optBoolean("embeddedArtist", false);
                    s.embeddedAlbumArtist = o.optBoolean("embeddedAlbumArtist", false);
                    s.embeddedTitle = o.optBoolean("embeddedTitle", false);
                    s.embeddedAlbum = o.optBoolean("embeddedAlbum", false);
                    s.embeddedYear = o.optBoolean("embeddedYear", false);
                    s.embeddedGenre = o.optBoolean("embeddedGenre", false);
                }
                s.overrideArtistSet = o.optBoolean("overrideArtistSet", false);
                s.overrideAlbumArtistSet = o.optBoolean("overrideAlbumArtistSet", false);
                s.overrideTitleSet = o.optBoolean("overrideTitleSet", false);
                s.overrideAlbumSet = o.optBoolean("overrideAlbumSet", false);
                s.overrideYearSet = o.optBoolean("overrideYearSet", false);
                s.overrideGenreSet = o.optBoolean("overrideGenreSet", false);
                s.invalidateScheduleKeys();
                out.add(s);
            }
        } catch (Exception ignored) {
            out.clear();
        }
        return out;
    }

    private static List<MainActivity.Song> cloneSongs(List<MainActivity.Song> source) {
        List<MainActivity.Song> out = new ArrayList<>();
        if (source == null) return out;
        for (MainActivity.Song original : source) {
            MainActivity.Song s = new MainActivity.Song(original.name, original.relativePath,
                    original.documentId, original.uri, original.size, original.lastModified);
            s.analyzed = original.analyzed;
            s.fromCache = original.fromCache;
            s.rmsDb = original.rmsDb;
            s.bpm = original.bpm;
            s.activity = original.activity;
            s.energy = original.energy;
            s.title = original.title;
            s.artist = original.artist;
            s.albumArtist = original.albumArtist;
            s.album = original.album;
            s.genre = original.genre;
            s.year = original.year;
            s.yearMetadataLoaded = original.yearMetadataLoaded;
            s.genreSource = original.genreSource;
            s.artistSource = original.artistSource;
            s.embeddedMetadataPresenceLoaded = original.embeddedMetadataPresenceLoaded;
            s.embeddedArtist = original.embeddedArtist;
            s.embeddedAlbumArtist = original.embeddedAlbumArtist;
            s.embeddedTitle = original.embeddedTitle;
            s.embeddedAlbum = original.embeddedAlbum;
            s.embeddedYear = original.embeddedYear;
            s.embeddedGenre = original.embeddedGenre;
            s.overrideArtistSet = original.overrideArtistSet;
            s.overrideAlbumArtistSet = original.overrideAlbumArtistSet;
            s.overrideTitleSet = original.overrideTitleSet;
            s.overrideAlbumSet = original.overrideAlbumSet;
            s.overrideYearSet = original.overrideYearSet;
            s.overrideGenreSet = original.overrideGenreSet;
            s.invalidateScheduleKeys();
            out.add(s);
        }
        return out;
    }

    private static void putNullable(JSONObject o, String key, String value) throws Exception {
        if (value == null) o.put(key, JSONObject.NULL);
        else o.put(key, value);
    }

    private static String jsonNullToString(JSONObject o, String key) {
        if (!o.has(key) || o.isNull(key)) return null;
        String value = o.optString(key, null);
        return value == null || value.trim().isEmpty() ? null : value;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE);
    }

    private static void ensureWakeLock(Context context) {
        synchronized (WAKE_LOCK_GUARD) {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                if (pm == null) return;
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        "PowerampAlternator:BackgroundProcessing");
                wakeLock.setReferenceCounted(false);
            }
            if (!wakeLock.isHeld()) wakeLock.acquire(6L * 60L * 60L * 1000L);
        }
    }

    private static void releaseWakeLock() {
        synchronized (WAKE_LOCK_GUARD) {
            if (wakeLock != null && wakeLock.isHeld()) {
                try { wakeLock.release(); } catch (RuntimeException ignored) {}
            }
        }
    }

    private static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel workChannel = new NotificationChannel(
                CHANNEL_ID, AppLanguage.text(context, "עבודה ברקע", "Background work"), NotificationManager.IMPORTANCE_LOW);
        workChannel.setDescription(AppLanguage.text(context, "מציג התקדמות בזמן ניתוח ובניית פלייליסט", "Shows progress during analysis and playlist creation"));
        manager.createNotificationChannel(workChannel);

        NotificationChannel resultChannel = new NotificationChannel(
                RESULT_CHANNEL_ID, AppLanguage.text(context, "תוצאות וסיום", "Results and completion"), NotificationManager.IMPORTANCE_DEFAULT);
        resultChannel.setDescription(AppLanguage.text(context, "מודיע כאשר ניתוח או בניית פלייליסט הסתיימו", "Notifies when analysis or playlist creation completes"));
        manager.createNotificationChannel(resultChannel);
    }

    private static void cancelResultNotification(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.cancel(RESULT_NOTIFICATION_ID);
    }

    private static void showResultNotification(Context context, String title, String text, boolean error) {
        ensureChannel(context);
        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) piFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 1, openApp, piFlags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, RESULT_CHANNEL_ID)
                : new Notification.Builder(context);
        builder.setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(error ? android.R.drawable.stat_notify_error : android.R.drawable.stat_sys_download_done)
                .setAutoCancel(true)
                .setOngoing(false)
                .setContentIntent(pendingIntent)
                .setCategory(error ? Notification.CATEGORY_ERROR : Notification.CATEGORY_STATUS);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(RESULT_NOTIFICATION_ID, builder.build());
    }

    private static Notification buildNotification(Context context, String text, int progress, boolean indeterminate) {
        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) piFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, openApp, piFlags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        builder.setContentTitle("Playlist Maker")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(progress < 100)
                .setOnlyAlertOnce(true)
                .setContentIntent(pendingIntent)
                .setCategory(Notification.CATEGORY_PROGRESS);
        if (indeterminate) builder.setProgress(0, 0, true);
        else builder.setProgress(100, Math.max(0, Math.min(100, progress)), false);
        return builder.build();
    }
}
