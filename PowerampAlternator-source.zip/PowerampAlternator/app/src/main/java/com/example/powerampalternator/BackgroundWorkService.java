package com.example.powerampalternator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Owns the long-running worker thread and a partial wake lock.
 * The Activity submits the user-started job, while the worker thread and wake lock
 * live here for the duration of the task. This prevents analysis/playlist creation from
 * pausing when the screen turns off or the Activity is no longer visible.
 */
public class BackgroundWorkService extends Service {
    private static final String CHANNEL_ID = "playlist_background_work";
    private static final int NOTIFICATION_ID = 2401;
    private static final String STATE_PREFS = "background_job_state";
    private static final String KEY_BUSY = "busy";
    private static final String KEY_STATUS = "status";
    private static final String KEY_PROGRESS = "progress";

    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private static volatile boolean workerActive = false;
    private static final Object WAKE_LOCK_GUARD = new Object();
    private static PowerManager.WakeLock wakeLock;

    private static volatile String currentText = "עובד ברקע…";
    private static volatile int currentProgress = 0;
    private static volatile boolean currentIndeterminate = true;

    @Override
    public void onCreate() {
        super.onCreate();
        ensureChannel(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String text = intent.getStringExtra("text");
            if (text != null && !text.trim().isEmpty()) currentText = text;
            currentProgress = intent.getIntExtra("progress", currentProgress);
            currentIndeterminate = intent.getBooleanExtra("indeterminate", currentIndeterminate);
        }

        // startForeground first, then keep the CPU awake for the user-started job.
        startForeground(NOTIFICATION_ID, buildNotification(this, currentText, currentProgress, currentIndeterminate));
        ensureWakeLock(getApplicationContext());
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        releaseWakeLock();
        super.onDestroy();
    }

    public static void start(Context context, String text) {
        Context app = context.getApplicationContext();
        currentText = text == null ? "עובד ברקע…" : text;
        currentProgress = 0;
        currentIndeterminate = true;
        Intent intent = new Intent(app, BackgroundWorkService.class)
                .putExtra("text", currentText)
                .putExtra("progress", currentProgress)
                .putExtra("indeterminate", true);
        persistState(app, true, currentText, currentProgress);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            app.startForegroundService(intent);
        } else {
            app.startService(intent);
        }
    }

    /**
     * Submit a long-running task to the service-owned single worker.
     * The wake lock is acquired before submission so screen-off cannot suspend
     * the analysis in the small window before onStartCommand executes.
     */
    public static void execute(Context context, Runnable job) {
        Context app = context.getApplicationContext();
        ensureWakeLock(app);
        workerActive = true;
        try {
            WORKER.execute(() -> {
                try {
                    job.run();
                } finally {
                    workerActive = false;
                }
            });
        } catch (RuntimeException e) {
            workerActive = false;
            throw e;
        }
    }

    public static void update(Context context, String text, int progressPercent) {
        Context app = context.getApplicationContext();
        currentText = text == null ? "עובד ברקע…" : text;
        currentProgress = Math.max(0, Math.min(100, progressPercent));
        currentIndeterminate = false;
        persistState(app, true, currentText, currentProgress);
        ensureChannel(app);
        NotificationManager manager = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(NOTIFICATION_ID, buildNotification(app, currentText, currentProgress, false));
        }
    }

    public static void finish(Context context, String finalText) {
        Context app = context.getApplicationContext();
        currentText = finalText == null ? currentText : finalText;
        currentProgress = 100;
        currentIndeterminate = false;
        persistState(app, false, currentText, currentProgress);
        stop(app);
    }

    public static void stop(Context context) {
        Context app = context.getApplicationContext();
        try {
            app.stopService(new Intent(app, BackgroundWorkService.class));
        } catch (Exception ignored) {
        } finally {
            releaseWakeLock();
        }
    }

    public static boolean isWorkerActive() {
        return workerActive;
    }

    public static State getState(Context context) {
        SharedPreferences p = context.getApplicationContext()
                .getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE);
        return new State(
                p.getBoolean(KEY_BUSY, false),
                p.getString(KEY_STATUS, ""),
                p.getInt(KEY_PROGRESS, 0)
        );
    }

    private static void persistState(Context context, boolean busy, String status, int progress) {
        context.getApplicationContext().getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_BUSY, busy)
                .putString(KEY_STATUS, status == null ? "" : status)
                .putInt(KEY_PROGRESS, Math.max(0, Math.min(100, progress)))
                .apply();
    }

    public static final class State {
        public final boolean busy;
        public final String status;
        public final int progress;

        State(boolean busy, String status, int progress) {
            this.busy = busy;
            this.status = status == null ? "" : status;
            this.progress = Math.max(0, Math.min(100, progress));
        }
    }

    private static void ensureWakeLock(Context context) {
        synchronized (WAKE_LOCK_GUARD) {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                if (pm == null) return;
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        "PowerampAlternator:BackgroundProcessing");
                wakeLock.setReferenceCounted(false);
            }
            if (!wakeLock.isHeld()) {
                // Safety timeout: Android's dataSync foreground-service limit is much longer;
                // this only prevents a leaked lock if an unexpected failure bypasses cleanup.
                wakeLock.acquire(6L * 60L * 60L * 1000L);
            }
        }
    }

    private static void releaseWakeLock() {
        synchronized (WAKE_LOCK_GUARD) {
            if (wakeLock != null && wakeLock.isHeld()) {
                try {
                    wakeLock.release();
                } catch (RuntimeException ignored) {
                }
            }
        }
    }

    private static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "עבודה ברקע",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("מציג התקדמות בזמן ניתוח ובניית פלייליסט");
        manager.createNotificationChannel(channel);
    }

    private static Notification buildNotification(Context context, String text, int progress, boolean indeterminate) {
        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) piFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, openApp, piFlags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        builder.setContentTitle("Poweramp Alternator")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(pendingIntent)
                .setCategory(Notification.CATEGORY_PROGRESS);
        if (indeterminate) {
            builder.setProgress(0, 0, true);
        } else {
            builder.setProgress(100, progress, false);
        }
        return builder.build();
    }
}
