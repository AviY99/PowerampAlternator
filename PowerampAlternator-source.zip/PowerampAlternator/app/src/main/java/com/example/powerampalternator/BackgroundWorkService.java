package com.example.powerampalternator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

public class BackgroundWorkService extends Service {
    private static final String CHANNEL_ID = "playlist_background_work";
    private static final int NOTIFICATION_ID = 2401;
    private static volatile String currentText = "עובד ברקע…";
    private static volatile int currentProgress = 0;
    private static volatile boolean currentIndeterminate = true;

    @Override
    public void onCreate() {
        super.onCreate();
        ensureChannel(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String text = intent.getStringExtra("text");
            if (text != null && !text.trim().isEmpty()) currentText = text;
            currentProgress = intent.getIntExtra("progress", currentProgress);
            currentIndeterminate = intent.getBooleanExtra("indeterminate", currentIndeterminate);
        }
        startForeground(NOTIFICATION_ID, buildNotification(this, currentText, currentProgress, currentIndeterminate));
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static void start(Context context, String text) {
        currentText = text == null ? "עובד ברקע…" : text;
        currentProgress = 0;
        currentIndeterminate = true;
        Intent intent = new Intent(context, BackgroundWorkService.class)
                .putExtra("text", currentText)
                .putExtra("progress", currentProgress)
                .putExtra("indeterminate", true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }

    public static void update(Context context, String text, int progressPercent) {
        currentText = text == null ? "עובד ברקע…" : text;
        currentProgress = Math.max(0, Math.min(100, progressPercent));
        currentIndeterminate = false;
        ensureChannel(context);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(NOTIFICATION_ID, buildNotification(context, currentText, currentProgress, false));
        }
    }

    public static void stop(Context context) {
        try {
            context.stopService(new Intent(context, BackgroundWorkService.class));
        } catch (Exception ignored) {
        }
    }

    private static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "עבודה ברקע",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("מציג התקדמות בזמן ניתוח ובניית פלייליסט");
        manager.createNotificationChannel(channel);
    }

    private static Notification buildNotification(Context context, String text, int progress, boolean indeterminate) {
        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) piFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, openApp, piFlags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        builder.setContentTitle("Poweramp Alternator")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(pendingIntent)
                .setCategory(Notification.CATEGORY_PROGRESS);
        if (indeterminate) {
            builder.setProgress(0, 0, true);
        } else {
            builder.setProgress(100, progress, false);
        }
        return builder.build();
    }
}
