package com.example.powerampalternator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Resumable foreground worker for analysis, playlist creation and online metadata lookup.
 *
 * EN: Persists task identity/progress, owns the worker thread and WakeLock, restores the
 * analysis snapshot after process recreation, checkpoints metadata lookup results, and posts
 * a separate completion notification.
 * HE: שומר את זהות המשימה וההתקדמות, מנהל Worker ו-WakeLock, משחזר snapshot לאחר
 * יצירת תהליך מחדש, שומר checkpoints לחיפוש metadata ושולח התראת סיום נפרדת.
 */
public class BackgroundWorkService extends Service {
    private static final String CHANNEL_ID = "playlist_background_work";
    private static final String RESULT_CHANNEL_ID = "playlist_results";
    private static final int NOTIFICATION_ID = 2401;
    private static final int RESULT_NOTIFICATION_ID = 2402;
    private static final String STATE_PREFS = "background_job_state";
    private static final String SNAPSHOT_FILE = "last_analysis_snapshot.json";
    private static final String METADATA_TASK_FILE = "metadata_lookup_task.json";

    private static final String KEY_BUSY = "busy";
    private static final String KEY_STATUS = "status";
    private static final String KEY_PROGRESS = "progress";
    private static final String KEY_TASK_TYPE = "task_type";
    private static final String KEY_TREE_URI = "task_tree_uri";
    // 3.4.5: active analysis roots + per-root recursion preference. KEY_TREE_URI is retained as
    // the primary root for legacy task/output compatibility.
    private static final String KEY_LIBRARY_SELECTIONS = "task_library_selections";
    private static final String KEY_OUTPUT_TREE_URI = "task_output_tree_uri";
    private static final String KEY_MODE = "task_mode";
    private static final String KEY_PLAYLIST_NAME = "task_playlist_name";
    private static final String KEY_ANALYSIS_READY = "analysis_ready";
    private static final String KEY_ANALYSIS_REVISION = "analysis_revision";
    private static final String KEY_SKIPPED = "analysis_skipped";
    private static final String KEY_CACHE_HITS = "analysis_cache_hits";
    private static final String KEY_RESULT_TEXT = "result_text";
    private static final String KEY_PLAYLIST_READY = "playlist_ready";
    private static final String KEY_REPORT_ENABLED = "task_report_enabled";
    private static final String KEY_LAST_DURATION_MS = "last_duration_ms";
    private static final String KEY_FILTER_MODE = "task_filter_mode";
    private static final String KEY_FILTER_ARTIST = "task_filter_artist";
    private static final String KEY_FILTER_GENRE = "task_filter_genre";
    private static final String KEY_SORT_STRATEGY = "task_sort_strategy";
    private static final String KEY_DIRECT_SORT_CRITERIA = "task_direct_sort_criteria";
    private static final String KEY_METADATA_RESULTS_READY = "metadata_results_ready";
    private static final String KEY_METADATA_RESULTS_REVISION = "metadata_results_revision";
    private static final String KEY_METADATA_FIELD = "metadata_field";
    private static final String KEY_METADATA_EXISTING_GENRE = "metadata_existing_genre";

    private static final String TASK_ANALYZE = "ANALYZE";
    private static final String TASK_CREATE = "CREATE";
    private static final String TASK_METADATA_LOOKUP = "METADATA_LOOKUP";

    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private static final Object WORK_GUARD = new Object();
    private static volatile boolean workerActive = false;

    private static final Object WAKE_LOCK_GUARD = new Object();
    private static PowerManager.WakeLock wakeLock;

    private static final Object SNAPSHOT_GUARD = new Object();
    private static List<MainActivity.Song> snapshotCache = new ArrayList<>();
    private static boolean snapshotLoaded = false;

    private static volatile String currentText = "";
    private static volatile int currentProgress = 0;
    private static volatile boolean currentIndeterminate = true;

    @Override
    public void onCreate() {
        super.onCreate();
        ensureChannel(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences p = prefs(this);
        currentText = p.getString(KEY_STATUS, AppLanguage.text(this, "מחדש עבודה ברקע…", "Resuming background work…"));
        currentProgress = p.getInt(KEY_PROGRESS, 0);
        currentIndeterminate = currentProgress <= 0;
        startForeground(NOTIFICATION_ID, buildNotification(this, currentText, currentProgress, currentIndeterminate));
        ensureWakeLock(getApplicationContext());
        resumePersistedTask();
        // Android may recreate this service and redeliver the original start intent.
        // The real task definition is persisted, so duplicate intents are harmless.
        return START_REDELIVER_INTENT;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        // If Android is destroying the process during a busy task, persisted KEY_BUSY remains
        // true and the redelivered service resumes it. Release the process-local wake lock here.
        releaseWakeLock();
        super.onDestroy();
    }

    public static void startAnalysis(Context context, Uri treeUri) {
        List<MainActivity.LibrarySelection> singleton = new ArrayList<>();
        singleton.add(new MainActivity.LibrarySelection(treeUri, true, true));
        startAnalysis(context, singleton);
    }

    public static void startAnalysis(Context context, List<MainActivity.LibrarySelection> libraries) {
        Context app = context.getApplicationContext();
        List<MainActivity.LibrarySelection> active = new ArrayList<>();
        if (libraries != null) {
            for (MainActivity.LibrarySelection selection : libraries) {
                if (selection != null && selection.selected && selection.uri != null) {
                    active.add(new MainActivity.LibrarySelection(selection.uri, true, selection.includeSubdirectories));
                }
            }
        }
        if (active.isEmpty()) return;
        Uri primary = active.get(0).uri;
        SharedPreferences.Editor e = prefs(app).edit();
        e.putBoolean(KEY_BUSY, true)
                .putString(KEY_STATUS, AppLanguage.text(app, "סורק ספריות מוזיקה…", "Scanning music libraries…"))
                .putInt(KEY_PROGRESS, 0)
                .putString(KEY_TASK_TYPE, TASK_ANALYZE)
                .putString(KEY_TREE_URI, primary.toString())
                .putString(KEY_LIBRARY_SELECTIONS, MainActivity.encodeLibrarySelections(active))
                .remove(KEY_PLAYLIST_NAME)
                .putInt(KEY_MODE, 0)
                .putBoolean(KEY_ANALYSIS_READY, false)
                .putBoolean(KEY_PLAYLIST_READY, false)
                .putBoolean(KEY_METADATA_RESULTS_READY, false)
                .putLong(KEY_LAST_DURATION_MS, 0L)
                .putString(KEY_RESULT_TEXT, "");
        e.commit();
        cancelResultNotification(app);
        startForegroundServiceCompat(app);
    }

    /**
     * Starts a resumable online metadata lookup as the same foreground/background service used by
     * analysis and playlist creation. The task file stores request indexes, partial results and the
     * next position, so a recreated process resumes instead of depending on the Activity thread.
     * Results are proposals only; no metadata override is applied in this service.
     */
    public static boolean startMetadataLookup(Context context, List<Integer> songIndexes, String field,
                                              boolean checkingExistingGenre) {
        Context app = context.getApplicationContext();
        if (songIndexes == null || songIndexes.isEmpty() || field == null || field.trim().isEmpty()) return false;
        SharedPreferences p = prefs(app);
        if (p.getBoolean(KEY_BUSY, false)) return false;
        try {
            JSONObject task = new JSONObject();
            task.put("field", field);
            task.put("checkingExistingGenre", checkingExistingGenre);
            task.put("next", 0);
            JSONArray requested = new JSONArray();
            for (Integer index : songIndexes) {
                if (index != null && index >= 0) requested.put(index);
            }
            if (requested.length() == 0) return false;
            task.put("requested", requested);
            task.put("results", new JSONArray());
            writeMetadataTaskFile(app, task);

            p.edit()
                    .putBoolean(KEY_BUSY, true)
                    .putString(KEY_STATUS, AppLanguage.text(app, "מתחיל בדיקת metadata ברשת…", "Starting online metadata check…"))
                    .putInt(KEY_PROGRESS, 0)
                    .putString(KEY_TASK_TYPE, TASK_METADATA_LOOKUP)
                    .putString(KEY_METADATA_FIELD, field)
                    .putBoolean(KEY_METADATA_EXISTING_GENRE, checkingExistingGenre)
                    .putBoolean(KEY_METADATA_RESULTS_READY, false)
                    .putBoolean(KEY_PLAYLIST_READY, false)
                    .putLong(KEY_LAST_DURATION_MS, 0L)
                    .putString(KEY_RESULT_TEXT, "")
                    .commit();
            cancelResultNotification(app);
            startForegroundServiceCompat(app);
            return true;
        } catch (Exception e) {
            // Do not leave the app permanently "busy" if Android rejects service startup.
            p.edit()
                    .putBoolean(KEY_BUSY, false)
                    .putString(KEY_TASK_TYPE, "")
                    .putString(KEY_STATUS, AppLanguage.text(app,
                            "לא ניתן להתחיל את בדיקת metadata ברקע.",
                            "Could not start the background metadata check."))
                    .commit();
            File taskFile = new File(app.getFilesDir(), METADATA_TASK_FILE);
            if (taskFile.exists()) taskFile.delete();
            return false;
        }
    }

    public static void startPlaylist(Context context, Uri treeUri, Uri outputTreeUri, int mode, String playlistName,
                                     boolean reportEnabled, int filterMode, String artistFilter,
                                     String genreFilter, int sortStrategy, String directSortCriteria) {
        Context app = context.getApplicationContext();
        SharedPreferences.Editor e = prefs(app).edit();
        e.putBoolean(KEY_BUSY, true)
                .putString(KEY_STATUS, AppLanguage.text(app, "מכין את הפלייליסט…", "Preparing playlist…"))
                .putInt(KEY_PROGRESS, 0)
                .putString(KEY_TASK_TYPE, TASK_CREATE)
                .putString(KEY_TREE_URI, treeUri.toString())
                .putString(KEY_OUTPUT_TREE_URI, outputTreeUri == null ? treeUri.toString() : outputTreeUri.toString())
                .putInt(KEY_MODE, mode)
                .putString(KEY_PLAYLIST_NAME, playlistName == null ? "" : playlistName)
                .putBoolean(KEY_REPORT_ENABLED, reportEnabled)
                .putInt(KEY_FILTER_MODE, filterMode)
                .putString(KEY_FILTER_ARTIST, artistFilter == null ? "" : artistFilter)
                .putString(KEY_FILTER_GENRE, genreFilter == null ? "" : genreFilter)
                .putInt(KEY_SORT_STRATEGY, sortStrategy)
                .putString(KEY_DIRECT_SORT_CRITERIA, directSortCriteria == null ? "" : directSortCriteria)
                .putBoolean(KEY_PLAYLIST_READY, false)
                .putBoolean(KEY_METADATA_RESULTS_READY, false)
                .putLong(KEY_LAST_DURATION_MS, 0L)
                .putString(KEY_RESULT_TEXT, "");
        e.commit();
        cancelResultNotification(app);
        startForegroundServiceCompat(app);
    }

    private static void startForegroundServiceCompat(Context app) {
        Intent intent = new Intent(app, BackgroundWorkService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) app.startForegroundService(intent);
        else app.startService(intent);
    }

    // ================== RESUMABLE BACKGROUND TASK - START ==================
    // EN: Reads the persisted task descriptor and starts exactly one worker. If Android
    //     recreated the service, the saved tree URI/task type and analysis snapshot allow
    //     work to resume without the Activity owning the job.
    // HE: קורא את תיאור המשימה השמור ומפעיל Worker יחיד. לאחר יצירת השירות מחדש,
    //     URI/סוג המשימה וה-snapshot מאפשרים חידוש ללא תלות ב-Activity.
    private void resumePersistedTask() {
        synchronized (WORK_GUARD) {
            if (workerActive) return;
            State state = getState(getApplicationContext());
            if (!state.busy) {
                stopForegroundCompat();
                stopSelf();
                releaseWakeLock();
                return;
            }
            final String type = state.taskType;
            SharedPreferences taskPrefs = prefs(this);
            final String treeText = taskPrefs.getString(KEY_TREE_URI, "");
            final String libraryText = taskPrefs.getString(KEY_LIBRARY_SELECTIONS, "");
            boolean createNeedsTree = TASK_CREATE.equals(type);
            boolean analyzeHasSource = TASK_ANALYZE.equals(type)
                    && ((libraryText != null && !libraryText.trim().isEmpty())
                    || (treeText != null && !treeText.trim().isEmpty()));
            if (type.isEmpty() || (createNeedsTree && (treeText == null || treeText.trim().isEmpty()))
                    || (TASK_ANALYZE.equals(type) && !analyzeHasSource)) {
                failTask(AppLanguage.text(this, "שגיאה: לא ניתן לשחזר את פרטי העבודה ברקע.", "Error: background task details could not be restored."));
                return;
            }
            workerActive = true;
            ensureWakeLock(getApplicationContext());
            WORKER.execute(() -> {
                try {
                    if (TASK_ANALYZE.equals(type)) {
                        List<MainActivity.LibrarySelection> restored = MainActivity.decodeLibrarySelections(libraryText);
                        if (restored.isEmpty() && treeText != null && !treeText.trim().isEmpty()) {
                            restored.add(new MainActivity.LibrarySelection(Uri.parse(treeText), true, true));
                        }
                        runAnalysisTask(restored);
                    } else if (TASK_CREATE.equals(type)) {
                        runCreateTask(Uri.parse(treeText));
                    } else if (TASK_METADATA_LOOKUP.equals(type)) {
                        runMetadataLookupTask();
                    } else {
                        throw new IllegalStateException(AppLanguage.text(this, "סוג משימה לא מוכר", "Unknown task type"));
                    }
                } catch (Exception e) {
                    failTask(AppLanguage.text(this, "שגיאה: ", "Error: ") + MainActivity.safeMessage(e));
                } finally {
                    workerActive = false;
                }
            });
        }
    }

    // =================== RESUMABLE BACKGROUND TASK - END ===================

    // ================= METADATA LOOKUP BACKGROUND TASK - START =================
    // EN: Online correction lookup runs inside the foreground service, persists every completed
    // request and resumes from the next item after process recreation. It never applies an override.
    // HE: חיפוש תיקוני metadata מתבצע בשירות הרקע, שומר כל תוצאה וממשיך מהפריט הבא
    // לאחר יצירת תהליך מחדש. השירות לעולם אינו מחיל override בעצמו.
    private void runMetadataLookupTask() throws Exception {
        long startedAt = System.currentTimeMillis();
        JSONObject task = readMetadataTaskFile(getApplicationContext());
        if (task == null) throw new IllegalStateException(AppLanguage.text(this,
                "משימת בדיקת metadata השמורה לא נמצאה.", "Saved metadata lookup task was not found."));

        String field = task.optString("field", "");
        boolean checkingExistingGenre = task.optBoolean("checkingExistingGenre", false);
        JSONArray requested = task.optJSONArray("requested");
        JSONArray results = task.optJSONArray("results");
        if (results == null) results = new JSONArray();
        int next = Math.max(0, task.optInt("next", results.length()));
        if (field.trim().isEmpty() || requested == null || requested.length() == 0) {
            throw new IllegalStateException(AppLanguage.text(this,
                    "פרטי בדיקת metadata אינם תקינים.", "Metadata lookup task details are invalid."));
        }

        List<MainActivity.Song> songs = getAnalysisSnapshot(getApplicationContext());
        if (songs.isEmpty()) {
            throw new IllegalStateException(AppLanguage.text(this,
                    "ניתוח השירים השמור לא נמצא.", "Saved song analysis was not found."));
        }

        for (int i = next; i < requested.length(); i++) {
            int songIndex = requested.optInt(i, -1);
            JSONObject item = new JSONObject();
            item.put("songIndex", songIndex);
            if (songIndex < 0 || songIndex >= songs.size()) {
                item.put("error", "Song index is no longer available.");
            } else {
                try {
                    MetadataOnlineLookup.Result result = MetadataOnlineLookup.lookup(songs.get(songIndex), field);
                    item.put("result", metadataResultToJson(result));
                } catch (Exception e) {
                    item.put("error", MainActivity.safeMessage(e));
                }
            }
            results.put(item);
            task.put("results", results);
            task.put("next", i + 1);
            writeMetadataTaskFile(getApplicationContext(), task);

            int done = i + 1;
            int progress = Math.max(1, Math.min(99, (int) Math.round(100.0 * done / requested.length())));
            publishProgress(AppLanguage.text(this, "בודק metadata ברשת ", "Checking online metadata ")
                    + done + "/" + requested.length() + "…", progress);
        }

        long durationMs = Math.max(0L, System.currentTimeMillis() - startedAt);
        SharedPreferences p = prefs(this);
        int revision = p.getInt(KEY_METADATA_RESULTS_REVISION, 0) + 1;
        p.edit()
                .putBoolean(KEY_BUSY, false)
                .putString(KEY_STATUS, AppLanguage.text(this,
                        "בדיקת metadata ברשת הסתיימה. פתח את התוצאות כדי לבחור אילו הצעות לאשר.",
                        "Online metadata check completed. Open the results to choose which proposals to approve."))
                .putInt(KEY_PROGRESS, 100)
                .putString(KEY_TASK_TYPE, "")
                .putBoolean(KEY_METADATA_RESULTS_READY, true)
                .putInt(KEY_METADATA_RESULTS_REVISION, revision)
                .putString(KEY_METADATA_FIELD, field)
                .putBoolean(KEY_METADATA_EXISTING_GENRE, checkingExistingGenre)
                .putLong(KEY_LAST_DURATION_MS, durationMs)
                .commit();
        finishService(AppLanguage.text(this, "בדיקת metadata הסתיימה", "Metadata check complete"),
                results.length() + AppLanguage.text(this, " תוצאות מוכנות לבדיקה.", " results are ready for review."), false);
    }
    // ================== METADATA LOOKUP BACKGROUND TASK - END ==================

    private void runAnalysisTask(List<MainActivity.LibrarySelection> libraries) throws Exception {
        long startedAt = System.currentTimeMillis();
        MainActivity.AnalysisResult result = MainActivity.performAnalysis(
                getApplicationContext(), libraries, this::publishProgress);
        long durationMs = Math.max(0L, System.currentTimeMillis() - startedAt);
        setAnalysisSnapshot(getApplicationContext(), result.songs, result.skipped, result.cacheHits);
        SharedPreferences.Editor e = prefs(this).edit();
        e.putBoolean(KEY_BUSY, false)
                .putString(KEY_STATUS, AppLanguage.text(this, "הניתוח הסתיים בהצלחה. אפשר לעבור לתוצאות וליצור פלייליסט.", "Analysis completed successfully. You can review results and create a playlist."))
                .putInt(KEY_PROGRESS, 100)
                .putString(KEY_TASK_TYPE, "")
                .putBoolean(KEY_ANALYSIS_READY, true)
                .putBoolean(KEY_PLAYLIST_READY, false)
                .putLong(KEY_LAST_DURATION_MS, durationMs)
                .putString(KEY_RESULT_TEXT, "");
        e.commit();
        finishService(AppLanguage.text(this, "הניתוח הסתיים", "Analysis complete"), result.songs.size() + AppLanguage.text(this, " שירים מוכנים לבניית פלייליסט.", " songs are ready for playlist creation."), false);
    }

    private void runCreateTask(Uri treeUri) throws Exception {
        long startedAt = System.currentTimeMillis();
        List<MainActivity.Song> source = getAnalysisSnapshot(getApplicationContext());
        if (source.size() < 2) {
            throw new IllegalStateException(AppLanguage.text(this, "ניתוח השירים השמור לא נמצא. יש לבצע ניתוח מחדש.", "Saved song analysis was not found. Run analysis again."));
        }
        SharedPreferences p = prefs(this);
        int mode = p.getInt(KEY_MODE, 0);
        String playlistName = p.getString(KEY_PLAYLIST_NAME, "");
        boolean reportEnabled = p.getBoolean(KEY_REPORT_ENABLED, true);
        int filterMode = p.getInt(KEY_FILTER_MODE, MainActivity.FILTER_ALL);
        String artistFilter = p.getString(KEY_FILTER_ARTIST, "");
        String genreFilter = p.getString(KEY_FILTER_GENRE, "");
        int sortStrategy = p.getInt(KEY_SORT_STRATEGY, MainActivity.SORT_SMART);
        String directSortCriteria = p.getString(KEY_DIRECT_SORT_CRITERIA, "");
        String outputTreeText = p.getString(KEY_OUTPUT_TREE_URI, treeUri.toString());
        Uri outputTreeUri = outputTreeText == null || outputTreeText.trim().isEmpty()
                ? treeUri : Uri.parse(outputTreeText);

        // ================= PLAYLIST OUTPUT RESTORE - START =================
        // EN: The output SAF tree is persisted with the CREATE task independently of the music
        // source tree, so process recreation writes to exactly the folder the user selected.
        // Older tasks without this key safely fall back to the music tree.
        // HE: URI הפלט נשמר כחלק ממשימת CREATE בנפרד מתיקיית המוזיקה, ולכן שחזור
        // תהליך ממשיך לכתוב לאותה תיקייה. משימות ישנות חוזרות בבטחה לתיקיית המוזיקה.
        // ================== PLAYLIST OUTPUT RESTORE - END ==================

        // ================= BACKGROUND FILTER APPLICATION - START =================
        // EN: Apply the persisted playlist filter to the full analysis snapshot before the
        // selected ordering engine. Filter sets are persisted with the task, so process
        // recreation resumes the same subset for Smart Sort, Direct Sort or Era Spread.
        // HE: החלת הסינון השמור על snapshot המלא לפני מנוע הסידור שנבחר. קבוצות
        // הבחירה נשמרות עם המשימה ולכן שחזור ממשיך עם אותה קבוצת שירים.
        List<MainActivity.Song> filtered = MainActivity.filterSongsForPlaylist(
                source, filterMode, artistFilter, genreFilter);
        if (filtered.size() < 2) {
            throw new IllegalStateException(AppLanguage.text(this,
                    "הסינון הנוכחי מכיל פחות משני שירים.",
                    "The current filter contains fewer than two songs."));
        }
        // ================== BACKGROUND FILTER APPLICATION - END ==================

        // ======================= YEAR METADATA PREPARATION - START =======================
        // EN: Year metadata is needed only for Direct Sort when Year is selected, or for the
        // standalone Era Spread engine. Smart Sort never enters this path and remains unchanged.
        // HE: תגית שנה נדרשת רק כאשר Direct Sort ממיין לפי Year או כאשר נבחר Era Spread
        // הנפרד. Smart Sort אינו עובר במסלול הזה ונשאר ללא שינוי.
        boolean needsYearMetadata =
                (sortStrategy == MainActivity.SORT_DIRECT && MainActivity.directSortUsesYear(directSortCriteria))
                        || sortStrategy == MainActivity.SORT_ERA;
        if (needsYearMetadata) {
            boolean eraMode = sortStrategy == MainActivity.SORT_ERA;
            publishProgress(AppLanguage.text(this,
                    eraMode ? "קורא תגיות שנה עבור Era Spread…" : "קורא תגיות שנה עבור Direct Sort…",
                    eraMode ? "Reading year metadata for Era Spread…" : "Reading year metadata for Direct Sort…"), 1);
            int refreshedYears = MainActivity.ensureYearMetadata(getApplicationContext(), filtered);
            if (refreshedYears > 0) {
                State current = getState(getApplicationContext());
                setAnalysisSnapshot(getApplicationContext(), source, current.skipped, current.cacheHits);
            }
        }
        // ======================== YEAR METADATA PREPARATION - END =======================

        String filterDescription = MainActivity.filterDescription(this, filterMode, artistFilter, genreFilter);
        MainActivity.PlaylistResult result = MainActivity.performPlaylist(
                getApplicationContext(), outputTreeUri, filtered, sortStrategy, mode, directSortCriteria,
                playlistName, reportEnabled, filterDescription, this::publishProgress);
        long durationMs = Math.max(0L, System.currentTimeMillis() - startedAt);

        String summary = MainActivity.buildPlaylistResultSummary(this, result.playlist, sortStrategy, mode,
                directSortCriteria, durationMs);
        StringBuilder resultText = new StringBuilder(summary)
                .append(AppLanguage.text(this, "\n\nסינון: ", "\n\nFilter: "))
                .append(filterDescription)
                .append(AppLanguage.text(this, "\nקובץ: ", "\nFile: ")).append(result.playlistName)
                .append(AppLanguage.text(this, "\nנשמר ב: ", "\nSaved in: ")).append(result.savedAt);
        if (result.reportName != null && !result.reportName.isEmpty()) {
            resultText.append(AppLanguage.text(this, "\nקובץ בדיקה: ", "\nDiagnostic file: ")).append(result.reportName);
        } else {
            resultText.append(AppLanguage.text(this, "\nקובץ בדיקה: לא נוצר לפי הבחירה שלך.", "\nDiagnostic file: not created by your choice."));
        }
        if (result.mediaScannerRequested) {
            resultText.append(AppLanguage.text(this,
                    "\nרענון Android: נשלחה בקשת MediaScanner כללית.",
                    "\nAndroid refresh: generic MediaScanner request sent."));
        } else {
            resultText.append(AppLanguage.text(this,
                    "\nרענון Android: הקובץ נשמר וה-provider עודכן; ייתכן שאפליקציות מסוימות ידרשו Rescan.",
                    "\nAndroid refresh: file saved and provider notified; some apps may still require Rescan."));
        }
        if (result.warning != null && !result.warning.isEmpty()) resultText.append("\n").append(result.warning);

        SharedPreferences.Editor e = prefs(this).edit();
        e.putBoolean(KEY_BUSY, false)
                .putString(KEY_STATUS, AppLanguage.text(this, "הפלייליסט נוצר בהצלחה ונשמר בתיקייה שבחרת.", "Playlist created successfully and saved in the selected folder."))
                .putInt(KEY_PROGRESS, 100)
                .putString(KEY_TASK_TYPE, "")
                .putBoolean(KEY_PLAYLIST_READY, true)
                .putLong(KEY_LAST_DURATION_MS, durationMs)
                .putString(KEY_RESULT_TEXT, resultText.toString());
        e.commit();
        finishService(AppLanguage.text(this, "הפלייליסט מוכן", "Playlist ready"), result.playlist.size() + AppLanguage.text(this, " שירים נוצרו בהצלחה.", " songs were created successfully."), false);
    }

    private void publishProgress(String text, int progress) {
        update(getApplicationContext(), text, progress);
    }

    private void failTask(String text) {
        String detail = text == null || text.trim().isEmpty() ? AppLanguage.text(this, "אירעה שגיאה לא צפויה.", "An unexpected error occurred.") : text.trim();
        if (detail.startsWith("שגיאה:")) detail = detail.substring("שגיאה:".length()).trim();
        if (detail.startsWith("Error:")) detail = detail.substring("Error:".length()).trim();
        String status = AppLanguage.text(this, "לא ניתן להשלים את העבודה: ", "Could not complete the task: ") + detail;
        prefs(this).edit()
                .putBoolean(KEY_BUSY, false)
                .putString(KEY_STATUS, status)
                .putInt(KEY_PROGRESS, 0)
                .putString(KEY_TASK_TYPE, "")
                .putString(KEY_RESULT_TEXT, AppLanguage.text(this, "העבודה לא הושלמה.\n", "The task did not complete.\n") + detail + AppLanguage.text(this, "\nאפשר לפתוח את האפליקציה ולנסות שוב.", "\nOpen the app and try again."))
                .commit();
        finishService(AppLanguage.text(this, "העבודה לא הושלמה", "Task not completed"), detail, true);
    }

    private void finishService(String title, String text, boolean error) {
        State state = getState(getApplicationContext());
        currentText = state.status;
        currentProgress = state.progress;
        currentIndeterminate = false;
        stopForegroundCompat();
        showResultNotification(this, title, text, error);
        releaseWakeLock();
        stopSelf();
    }

    private void stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
    }

    public static void update(Context context, String text, int progressPercent) {
        Context app = context.getApplicationContext();
        currentText = text == null ? AppLanguage.text(context, "עובד ברקע…", "Working in background…") : text;
        currentProgress = Math.max(0, Math.min(100, progressPercent));
        currentIndeterminate = false;
        prefs(app).edit()
                .putBoolean(KEY_BUSY, true)
                .putString(KEY_STATUS, currentText)
                .putInt(KEY_PROGRESS, currentProgress)
                .commit();
        ensureChannel(app);
        NotificationManager manager = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(app, currentText, currentProgress, false));
    }

    public static boolean isWorkerActive() {
        return workerActive;
    }

    public static State getState(Context context) {
        SharedPreferences p = prefs(context.getApplicationContext());
        return new State(
                p.getBoolean(KEY_BUSY, false),
                p.getString(KEY_STATUS, ""),
                p.getInt(KEY_PROGRESS, 0),
                p.getString(KEY_TASK_TYPE, ""),
                p.getBoolean(KEY_ANALYSIS_READY, false),
                p.getInt(KEY_ANALYSIS_REVISION, 0),
                p.getInt(KEY_SKIPPED, 0),
                p.getInt(KEY_CACHE_HITS, 0),
                p.getString(KEY_RESULT_TEXT, ""),
                p.getBoolean(KEY_PLAYLIST_READY, false),
                p.getLong(KEY_LAST_DURATION_MS, 0L),
                p.getBoolean(KEY_METADATA_RESULTS_READY, false),
                p.getInt(KEY_METADATA_RESULTS_REVISION, 0),
                p.getString(KEY_METADATA_FIELD, ""),
                p.getBoolean(KEY_METADATA_EXISTING_GENRE, false)
        );
    }

    public static final class State {
        public final boolean busy;
        public final String status;
        public final int progress;
        public final String taskType;
        public final boolean analysisReady;
        public final int analysisRevision;
        public final int skipped;
        public final int cacheHits;
        public final String resultText;
        public final boolean playlistReady;
        public final long lastDurationMs;
        public final boolean metadataResultsReady;
        public final int metadataResultsRevision;
        public final String metadataField;
        public final boolean metadataCheckingExistingGenre;

        State(boolean busy, String status, int progress, String taskType, boolean analysisReady,
              int analysisRevision, int skipped, int cacheHits, String resultText, boolean playlistReady,
              long lastDurationMs, boolean metadataResultsReady, int metadataResultsRevision,
              String metadataField, boolean metadataCheckingExistingGenre) {
            this.busy = busy;
            this.status = status == null ? "" : status;
            this.progress = Math.max(0, Math.min(100, progress));
            this.taskType = taskType == null ? "" : taskType;
            this.analysisReady = analysisReady;
            this.analysisRevision = analysisRevision;
            this.skipped = skipped;
            this.cacheHits = cacheHits;
            this.resultText = resultText == null ? "" : resultText;
            this.playlistReady = playlistReady;
            this.lastDurationMs = Math.max(0L, lastDurationMs);
            this.metadataResultsReady = metadataResultsReady;
            this.metadataResultsRevision = metadataResultsRevision;
            this.metadataField = metadataField == null ? "" : metadataField;
            this.metadataCheckingExistingGenre = metadataCheckingExistingGenre;
        }
    }

    public static final class MetadataLookupResultItem {
        public final int songIndex;
        public final MetadataOnlineLookup.Result result;
        public final String error;

        MetadataLookupResultItem(int songIndex, MetadataOnlineLookup.Result result, String error) {
            this.songIndex = songIndex;
            this.result = result;
            this.error = error == null ? "" : error;
        }
    }

    public static List<MetadataLookupResultItem> getMetadataLookupResults(Context context) {
        List<MetadataLookupResultItem> out = new ArrayList<>();
        try {
            JSONObject task = readMetadataTaskFile(context.getApplicationContext());
            if (task == null) return out;
            JSONArray arr = task.optJSONArray("results");
            if (arr == null) return out;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject item = arr.optJSONObject(i);
                if (item == null) continue;
                int songIndex = item.optInt("songIndex", -1);
                String error = jsonNullToString(item, "error");
                MetadataOnlineLookup.Result result = null;
                JSONObject resultJson = item.optJSONObject("result");
                if (resultJson != null) result = metadataResultFromJson(resultJson);
                out.add(new MetadataLookupResultItem(songIndex, result, error));
            }
        } catch (Exception ignored) {
            out.clear();
        }
        return out;
    }

    public static void dismissMetadataLookupResults(Context context, int revision) {
        Context app = context.getApplicationContext();
        SharedPreferences p = prefs(app);
        if (revision > 0 && p.getInt(KEY_METADATA_RESULTS_REVISION, 0) != revision) return;
        p.edit().putBoolean(KEY_METADATA_RESULTS_READY, false).commit();
    }

    public static void setAnalysisSnapshot(Context context, List<MainActivity.Song> songs, int skipped, int cacheHits) {
        Context app = context.getApplicationContext();
        synchronized (SNAPSHOT_GUARD) {
            snapshotCache = cloneSongs(songs);
            snapshotLoaded = true;
            writeSnapshotFile(app, snapshotCache);
        }
        SharedPreferences p = prefs(app);
        int revision = p.getInt(KEY_ANALYSIS_REVISION, 0) + 1;
        p.edit()
                .putBoolean(KEY_ANALYSIS_READY, songs != null && songs.size() >= 2)
                .putInt(KEY_ANALYSIS_REVISION, revision)
                .putInt(KEY_SKIPPED, skipped)
                .putInt(KEY_CACHE_HITS, cacheHits)
                .commit();
    }

    public static List<MainActivity.Song> getAnalysisSnapshot(Context context) {
        Context app = context.getApplicationContext();
        synchronized (SNAPSHOT_GUARD) {
            if (!snapshotLoaded) {
                snapshotCache = readSnapshotFile(app);
                snapshotLoaded = true;
            }
            return cloneSongs(snapshotCache);
        }
    }

    public static void clearAnalysisSnapshot(Context context) {
        Context app = context.getApplicationContext();
        synchronized (SNAPSHOT_GUARD) {
            snapshotCache = new ArrayList<>();
            snapshotLoaded = true;
            File f = new File(app.getFilesDir(), SNAPSHOT_FILE);
            if (f.exists()) f.delete();
            File metadataTask = new File(app.getFilesDir(), METADATA_TASK_FILE);
            if (metadataTask.exists()) metadataTask.delete();
        }
        SharedPreferences p = prefs(app);
        p.edit()
                .putBoolean(KEY_BUSY, false)
                .putString(KEY_STATUS, AppLanguage.text(context, "מוכן לסריקה.", "Ready to scan."))
                .putInt(KEY_PROGRESS, 0)
                .putString(KEY_TASK_TYPE, "")
                .putBoolean(KEY_ANALYSIS_READY, false)
                .putBoolean(KEY_PLAYLIST_READY, false)
                .putBoolean(KEY_METADATA_RESULTS_READY, false)
                .putString(KEY_RESULT_TEXT, "")
                .putLong(KEY_LAST_DURATION_MS, 0L)
                .putInt(KEY_ANALYSIS_REVISION, p.getInt(KEY_ANALYSIS_REVISION, 0) + 1)
                .commit();
    }

    private static void writeMetadataTaskFile(Context context, JSONObject task) throws Exception {
        File target = new File(context.getFilesDir(), METADATA_TASK_FILE);
        File temp = new File(context.getFilesDir(), METADATA_TASK_FILE + ".tmp");
        try (FileWriter writer = new FileWriter(temp, false)) {
            writer.write(task.toString());
            writer.flush();
        }
        if (target.exists() && !target.delete()) {
            throw new IllegalStateException("Could not replace metadata task file.");
        }
        if (!temp.renameTo(target)) {
            try (FileWriter writer = new FileWriter(target, false)) {
                writer.write(task.toString());
                writer.flush();
            }
            temp.delete();
        }
    }

    private static JSONObject readMetadataTaskFile(Context context) {
        File file = new File(context.getFilesDir(), METADATA_TASK_FILE);
        if (!file.exists()) return null;
        try {
            StringBuilder text = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) text.append(line);
            }
            return new JSONObject(text.toString());
        } catch (Exception e) {
            return null;
        }
    }

    private static JSONObject metadataResultToJson(MetadataOnlineLookup.Result result) throws Exception {
        JSONObject o = new JSONObject();
        if (result == null) return o;
        putNullable(o, "field", result.field);
        putNullable(o, "suggestedValue", result.suggestedValue);
        o.put("confidence", result.confidence);
        o.put("genreSupported", result.genreSupported);
        putNullable(o, "matchedTitle", result.matchedTitle);
        putNullable(o, "matchedArtist", result.matchedArtist);
        putNullable(o, "matchedAlbum", result.matchedAlbum);
        putNullable(o, "matchedYear", result.matchedYear);
        putNullable(o, "detail", result.detail);
        JSONArray genres = new JSONArray();
        if (result.genreCandidates != null) {
            for (String genre : result.genreCandidates) if (genre != null) genres.put(genre);
        }
        o.put("genreCandidates", genres);
        return o;
    }

    private static MetadataOnlineLookup.Result metadataResultFromJson(JSONObject o) {
        if (o == null) return null;
        List<String> genres = new ArrayList<>();
        JSONArray arr = o.optJSONArray("genreCandidates");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                String value = arr.optString(i, null);
                if (value != null && !value.trim().isEmpty()) genres.add(value);
            }
        }
        return new MetadataOnlineLookup.Result(
                jsonNullToString(o, "field"),
                jsonNullToString(o, "suggestedValue"),
                o.optInt("confidence", 0),
                o.optBoolean("genreSupported", false),
                jsonNullToString(o, "matchedTitle"),
                jsonNullToString(o, "matchedArtist"),
                jsonNullToString(o, "matchedAlbum"),
                jsonNullToString(o, "matchedYear"),
                genres,
                jsonNullToString(o, "detail"));
    }

    private static void writeSnapshotFile(Context context, List<MainActivity.Song> songs) {
        File target = new File(context.getFilesDir(), SNAPSHOT_FILE);
        File temp = new File(context.getFilesDir(), SNAPSHOT_FILE + ".tmp");
        try {
            JSONArray arr = new JSONArray();
            if (songs != null) {
                for (MainActivity.Song s : songs) {
                    JSONObject o = new JSONObject();
                    o.put("name", s.name);
                    o.put("relativePath", s.relativePath);
                    o.put("documentId", s.documentId);
                    o.put("uri", s.uri.toString());
                    o.put("size", s.size);
                    o.put("lastModified", s.lastModified);
                    o.put("analyzed", s.analyzed);
                    o.put("rmsDb", s.rmsDb);
                    o.put("bpm", s.bpm);
                    o.put("activity", s.activity);
                    o.put("energy", s.energy);
                    putNullable(o, "title", s.title);
                    putNullable(o, "artist", s.artist);
                    putNullable(o, "albumArtist", s.albumArtist);
                    putNullable(o, "album", s.album);
                    putNullable(o, "genre", s.genre);
                    if (s.yearMetadataLoaded) {
                        if (s.year > 0) o.put("year", s.year); else o.put("year", JSONObject.NULL);
                    }
                    putNullable(o, "genreSource", s.genreSource);
                    putNullable(o, "artistSource", s.artistSource);
                    o.put("embeddedPresenceLoaded", s.embeddedMetadataPresenceLoaded);
                    if (s.embeddedMetadataPresenceLoaded) {
                        o.put("embeddedArtist", s.embeddedArtist);
                        o.put("embeddedAlbumArtist", s.embeddedAlbumArtist);
                        o.put("embeddedTitle", s.embeddedTitle);
                        o.put("embeddedAlbum", s.embeddedAlbum);
                        o.put("embeddedYear", s.embeddedYear);
                        o.put("embeddedGenre", s.embeddedGenre);
                    }
                    o.put("overrideArtistSet", s.overrideArtistSet);
                    o.put("overrideAlbumArtistSet", s.overrideAlbumArtistSet);
                    o.put("overrideTitleSet", s.overrideTitleSet);
                    o.put("overrideAlbumSet", s.overrideAlbumSet);
                    o.put("overrideYearSet", s.overrideYearSet);
                    o.put("overrideGenreSet", s.overrideGenreSet);
                    arr.put(o);
                }
            }
            try (FileWriter writer = new FileWriter(temp, false)) {
                writer.write(arr.toString());
                writer.flush();
            }
            if (target.exists()) target.delete();
            if (!temp.renameTo(target)) {
                try (FileWriter writer = new FileWriter(target, false)) {
                    writer.write(arr.toString());
                }
                temp.delete();
            }
        } catch (Exception ignored) {
            temp.delete();
        }
    }

    private static List<MainActivity.Song> readSnapshotFile(Context context) {
        List<MainActivity.Song> out = new ArrayList<>();
        File f = new File(context.getFilesDir(), SNAPSHOT_FILE);
        if (!f.exists()) return out;
        try {
            StringBuilder text = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(f))) {
                String line;
                while ((line = reader.readLine()) != null) text.append(line);
            }
            JSONArray arr = new JSONArray(text.toString());
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                MainActivity.Song s = new MainActivity.Song(
                        o.getString("name"), o.getString("relativePath"), o.getString("documentId"),
                        Uri.parse(o.getString("uri")), o.optLong("size", 0), o.optLong("lastModified", 0));
                s.analyzed = o.optBoolean("analyzed", true);
                s.rmsDb = o.optDouble("rmsDb", 0);
                s.bpm = o.optDouble("bpm", 0);
                s.activity = o.optDouble("activity", 0);
                s.energy = o.optDouble("energy", 0.5);
                s.title = jsonNullToString(o, "title");
                s.artist = jsonNullToString(o, "artist");
                s.albumArtist = jsonNullToString(o, "albumArtist");
                s.album = jsonNullToString(o, "album");
                s.genre = jsonNullToString(o, "genre");
                s.yearMetadataLoaded = o.has("year");
                s.year = s.yearMetadataLoaded ? o.optInt("year", 0) : 0;
                s.genreSource = jsonNullToString(o, "genreSource");
                s.artistSource = jsonNullToString(o, "artistSource");
                s.embeddedMetadataPresenceLoaded = o.optBoolean("embeddedPresenceLoaded", false);
                if (s.embeddedMetadataPresenceLoaded) {
                    s.embeddedArtist = o.optBoolean("embeddedArtist", false);
                    s.embeddedAlbumArtist = o.optBoolean("embeddedAlbumArtist", false);
                    s.embeddedTitle = o.optBoolean("embeddedTitle", false);
                    s.embeddedAlbum = o.optBoolean("embeddedAlbum", false);
                    s.embeddedYear = o.optBoolean("embeddedYear", false);
                    s.embeddedGenre = o.optBoolean("embeddedGenre", false);
                }
                s.overrideArtistSet = o.optBoolean("overrideArtistSet", false);
                s.overrideAlbumArtistSet = o.optBoolean("overrideAlbumArtistSet", false);
                s.overrideTitleSet = o.optBoolean("overrideTitleSet", false);
                s.overrideAlbumSet = o.optBoolean("overrideAlbumSet", false);
                s.overrideYearSet = o.optBoolean("overrideYearSet", false);
                s.overrideGenreSet = o.optBoolean("overrideGenreSet", false);
                s.invalidateScheduleKeys();
                out.add(s);
            }
        } catch (Exception ignored) {
            out.clear();
        }
        return out;
    }

    private static List<MainActivity.Song> cloneSongs(List<MainActivity.Song> source) {
        List<MainActivity.Song> out = new ArrayList<>();
        if (source == null) return out;
        for (MainActivity.Song original : source) {
            MainActivity.Song s = new MainActivity.Song(original.name, original.relativePath,
                    original.documentId, original.uri, original.size, original.lastModified);
            s.analyzed = original.analyzed;
            s.fromCache = original.fromCache;
            s.rmsDb = original.rmsDb;
            s.bpm = original.bpm;
            s.activity = original.activity;
            s.energy = original.energy;
            s.title = original.title;
            s.artist = original.artist;
            s.albumArtist = original.albumArtist;
            s.album = original.album;
            s.genre = original.genre;
            s.year = original.year;
            s.yearMetadataLoaded = original.yearMetadataLoaded;
            s.genreSource = original.genreSource;
            s.artistSource = original.artistSource;
            s.embeddedMetadataPresenceLoaded = original.embeddedMetadataPresenceLoaded;
            s.embeddedArtist = original.embeddedArtist;
            s.embeddedAlbumArtist = original.embeddedAlbumArtist;
            s.embeddedTitle = original.embeddedTitle;
            s.embeddedAlbum = original.embeddedAlbum;
            s.embeddedYear = original.embeddedYear;
            s.embeddedGenre = original.embeddedGenre;
            s.overrideArtistSet = original.overrideArtistSet;
            s.overrideAlbumArtistSet = original.overrideAlbumArtistSet;
            s.overrideTitleSet = original.overrideTitleSet;
            s.overrideAlbumSet = original.overrideAlbumSet;
            s.overrideYearSet = original.overrideYearSet;
            s.overrideGenreSet = original.overrideGenreSet;
            s.invalidateScheduleKeys();
            out.add(s);
        }
        return out;
    }

    private static void putNullable(JSONObject o, String key, String value) throws Exception {
        if (value == null) o.put(key, JSONObject.NULL);
        else o.put(key, value);
    }

    private static String jsonNullToString(JSONObject o, String key) {
        if (!o.has(key) || o.isNull(key)) return null;
        String value = o.optString(key, null);
        return value == null || value.trim().isEmpty() ? null : value;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE);
    }

    private static void ensureWakeLock(Context context) {
        synchronized (WAKE_LOCK_GUARD) {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                if (pm == null) return;
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        "PowerampAlternator:BackgroundProcessing");
                wakeLock.setReferenceCounted(false);
            }
            if (!wakeLock.isHeld()) wakeLock.acquire(6L * 60L * 60L * 1000L);
        }
    }

    private static void releaseWakeLock() {
        synchronized (WAKE_LOCK_GUARD) {
            if (wakeLock != null && wakeLock.isHeld()) {
                try { wakeLock.release(); } catch (RuntimeException ignored) {}
            }
        }
    }

    private static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel workChannel = new NotificationChannel(
                CHANNEL_ID, AppLanguage.text(context, "עבודה ברקע", "Background work"), NotificationManager.IMPORTANCE_LOW);
        workChannel.setDescription(AppLanguage.text(context, "מציג התקדמות בזמן ניתוח, בניית פלייליסט ובדיקת metadata", "Shows progress during analysis, playlist creation and metadata lookup"));
        manager.createNotificationChannel(workChannel);

        NotificationChannel resultChannel = new NotificationChannel(
                RESULT_CHANNEL_ID, AppLanguage.text(context, "תוצאות וסיום", "Results and completion"), NotificationManager.IMPORTANCE_DEFAULT);
        resultChannel.setDescription(AppLanguage.text(context, "מודיע כאשר ניתוח, בניית פלייליסט או בדיקת metadata הסתיימו", "Notifies when analysis, playlist creation or metadata lookup completes"));
        manager.createNotificationChannel(resultChannel);
    }

    private static void cancelResultNotification(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.cancel(RESULT_NOTIFICATION_ID);
    }

    private static void showResultNotification(Context context, String title, String text, boolean error) {
        ensureChannel(context);
        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) piFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 1, openApp, piFlags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, RESULT_CHANNEL_ID)
                : new Notification.Builder(context);
        builder.setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(error ? android.R.drawable.stat_notify_error : android.R.drawable.stat_sys_download_done)
                .setAutoCancel(true)
                .setOngoing(false)
                .setContentIntent(pendingIntent)
                .setCategory(error ? Notification.CATEGORY_ERROR : Notification.CATEGORY_STATUS);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(RESULT_NOTIFICATION_ID, builder.build());
    }

    private static Notification buildNotification(Context context, String text, int progress, boolean indeterminate) {
        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) piFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, openApp, piFlags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        builder.setContentTitle("Playlist Maker")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(progress < 100)
                .setOnlyAlertOnce(true)
                .setContentIntent(pendingIntent)
                .setCategory(Notification.CATEGORY_PROGRESS);
        if (indeterminate) builder.setProgress(0, 0, true);
        else builder.setProgress(100, Math.max(0, Math.min(100, progress)), false);
        return builder.build();
    }
}
