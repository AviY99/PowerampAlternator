package com.example.powerampalternator;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Main screen and playlist engine.
 *
 * EN: Owns the programmatic GUI, music scan/analysis helpers, metadata cache and the
 * deterministic Smart/Direct playlist ordering engines. Long-running work itself is executed by
 * BackgroundWorkService so the Activity may leave the foreground safely.
 * HE: מנהל את ממשק המשתמש, סריקה/ניתוח, מטמון metadata ואת מנוע סידור הפלייליסט
 * הדטרמיניסטיים של Smart/Direct. העבודה הארוכה מתבצעת בשירות הרקע כדי שהמסך יוכל להיסגר בבטחה.
 */
public class MainActivity extends Activity {
    private static final int PICK_TREE = 1001;
    private static final int PICK_OUTPUT_TREE = 1002;
    private static final String PREFS = "prefs";
    private static final String PREF_TREE_URI = "tree_uri";
    // 3.4.5: persisted list of music-library roots. The legacy single tree URI is still kept
    // as the first selected root for output-folder compatibility and seamless upgrades.
    private static final String PREF_LIBRARY_SELECTIONS = "library_selections_v1";
    private static final String PREF_OUTPUT_TREE_URI = "output_tree_uri";
    private static final String PREF_MODE = "mode_index";
    private static final String PREF_PLAYLIST_NAME = "playlist_name";
    private static final String PREF_ANALYSIS_REPORT = "analysis_report_enabled";
    private static final String PREF_FILTER_MODE = "filter_mode";
    private static final String PREF_FILTER_ARTIST = "filter_artist";
    private static final String PREF_FILTER_GENRE = "filter_genre";
    private static final String PREF_SORT_STRATEGY = "sort_strategy";
    private static final String PREF_DIRECT_SORT_CRITERIA = "direct_sort_criteria";
    private static final String PREF_DIRECT_FIELD_ORDER = "direct_field_order";
    private static final String CACHE_PREFIX = "cache_song_";
    private static final String OVERRIDE_PREFIX = "override_song_";
    private static final int CACHE_VERSION = 2;
    static final double BALANCED_ENERGY_THRESHOLD = 0.50;
    private static final String DEFAULT_PLAYLIST_NAME = "Playlist_Maker.m3u8";

    // ================== CHANGES & CORRECTIONS 3.4.x - START ==================
    // EN: Missing-field detection uses actual embedded tags unless an internal user-approved
    // override exists. Filename fallback and the conservative legacy artist->Genre map remain
    // useful for playlist behavior, but do not hide a genuinely missing file tag here.
    // HE: איתור שדות חסרים מבוסס על תגיות הקובץ בפועל, אלא אם קיים override פנימי
    // שאושר על ידי המשתמש. fallback משם הקובץ ומפת Genre הישנה אינם מסתירים תגית חסרה.
    static final String META_FIELD_ARTIST = "artist";
    static final String META_FIELD_ALBUM_ARTIST = "albumArtist";
    static final String META_FIELD_TITLE = "title";
    static final String META_FIELD_ALBUM = "album";
    static final String META_FIELD_YEAR = "year";
    static final String META_FIELD_GENRE = "genre";
    private static final List<String> METADATA_FIELDS = Arrays.asList(
            META_FIELD_ARTIST, META_FIELD_ALBUM_ARTIST, META_FIELD_TITLE,
            META_FIELD_ALBUM, META_FIELD_YEAR, META_FIELD_GENRE);
    // =================== CHANGES & CORRECTIONS 3.4.x - END ===================

    // 3.4.x visual system: dark cards with a restrained violet accent and explicit press feedback.
    // The app is a playlist builder, not a player; no playback controls are introduced.
    private static final int UI_BG = Color.rgb(7, 8, 12);
    private static final int UI_CARD = Color.rgb(20, 21, 27);
    private static final int UI_SURFACE = Color.rgb(27, 28, 36);
    private static final int UI_BORDER = Color.rgb(43, 44, 55);
    private static final int UI_TEXT = Color.rgb(247, 247, 250);
    private static final int UI_MUTED = Color.rgb(166, 166, 178);
    private static final int UI_ACCENT = Color.rgb(124, 116, 255);
    private static final int UI_ACCENT_SOFT = Color.rgb(74, 69, 145);
    private static final int CONFIDENCE_GREEN = Color.rgb(110, 220, 145);
    private static final int CONFIDENCE_YELLOW = Color.rgb(242, 205, 92);
    private static final int CONFIDENCE_RED = Color.rgb(242, 112, 112);
    private static final int CONFIDENCE_NONE = -1;
    private static final int CONFIDENCE_LOW = 0;
    private static final int CONFIDENCE_MEDIUM = 1;
    private static final int CONFIDENCE_HIGH = 2;

    static final int FILTER_ALL = 0;
    static final int FILTER_ARTIST = 1;
    static final int FILTER_GENRE = 2;
    // Legacy-only compatibility for a 3.1.0/3.1.1 task that was already persisted.
    // 3.2.1 continues not to expose this combined mode in the GUI.
    static final int FILTER_ARTIST_GENRE = 3;

    // ======================== SORT STRATEGY - START ========================
    // EN: Smart Sort is the existing deterministic artist/flow scheduler. Direct Sort is a
    // strict lexicographic sort by one or more user-selected metadata fields and never uses
    // energy/BPM or artist spacing. Filtering is shared and always happens first.
    // HE: Smart Sort הוא האלגוריתם החכם הקיים. Direct Sort הוא מיון קשיח לפי פרמטר
    // אחד או יותר ואינו משתמש בקצב/אופי או בפיזור אמנים. הסינון תמיד מתבצע קודם.
    static final int SORT_SMART = 0;
    static final int SORT_DIRECT = 1;
    static final String DIRECT_FIELD_ARTIST = "artist";
    static final String DIRECT_FIELD_GENRE = "genre";
    static final String DIRECT_FIELD_YEAR = "year";
    static final String DIRECT_FIELD_ALBUM = "album";
    static final String DIRECT_FIELD_TITLE = "title";
    private static final List<String> DIRECT_FIELDS = Arrays.asList(
            DIRECT_FIELD_ARTIST, DIRECT_FIELD_GENRE, DIRECT_FIELD_YEAR, DIRECT_FIELD_ALBUM, DIRECT_FIELD_TITLE);
    // ========================= SORT STRATEGY - END =========================

    private String tr(String he, String en) {
        return AppLanguage.text(this, he, en);
    }

    private static String tr(Context context, String he, String en) {
        return AppLanguage.text(context, he, en);
    }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService correctionsWorker = Executors.newSingleThreadExecutor();

    private static volatile boolean sharedBusy = false;
    private static volatile int sharedProgress = 0;
    private static volatile String sharedStatus = "";

    // treeUri remains the primary (first checked) source for backward-compatible output fallback.
    // Actual analysis uses every checked LibrarySelection below.
    private Uri treeUri;
    private final List<LibrarySelection> librarySelections = new ArrayList<>();
    private Uri outputTreeUri;
    private TextView folderText;
    private TextView outputFolderText;
    private TextView statusText;
    private TextView resultText;
    private TextView flowHelpText;
    private ProgressBar progressBar;
    private Button analyzeButton;
    private Button createButton;
    private Button missingMetadataButton;
    private Button genreCheckButton;
    private Button manualMetadataButton;
    private TextView correctionsSummaryText;
    private TextView correctionsWorkText;
    private ProgressBar correctionsProgressBar;

    // 3.4.4: while any long-running service task is active, all interactive controls on the
    // main screen are visually disabled and inaccessible. The service remains the single owner
    // of the work; this lock is UI-only and is released automatically when persisted busy state
    // becomes false. Previous enabled states are restored before normal state-refresh methods run.
    private View busyUiRoot;
    private final Map<View, Boolean> busyEnabledSnapshot = new IdentityHashMap<>();
    private boolean busyUiLocked = false;

    private CheckBox analysisReportCheckBox;
    private Spinner modeSpinner;
    private EditText playlistNameEdit;

    // ======================= SORT STRATEGY GUI - START =======================
    private int selectedSortStrategy = SORT_SMART;
    private Spinner sortStrategySpinner;
    private LinearLayout smartFlowContainer;
    private LinearLayout directSortContainer;
    private LinearLayout directCriteriaContainer;
    private boolean directSortUiUpdating = false;
    private boolean settingsInitialized = false;
    private final List<DirectSortCriterion> directSortCriteria = new ArrayList<>();
    // 3.3.2 keeps a full five-row visual order. Checked rows are the active sort criteria.
    // At least one row is always selected; the ≡ handle uses a vertical-only in-place drag so
    // the row never floats sideways while priority is changed.
    private final List<String> directFieldOrder = new ArrayList<>();
    private String directVerticalDragField = null;
    private View directVerticalDragRow = null;
    private float directVerticalDragDownRawY = 0f;
    private boolean directVerticalDragActive = false;
    private Runnable directVerticalDragArm = null;
    // ======================== SORT STRATEGY GUI - END ========================

    // ======================== FILTER GUI - START ========================
    // EN: Filtering is shared by Smart Sort and Direct Sort and is applied before either
    // ordering engine. The approved Smart Sort scheduler itself remains unchanged.
    // HE: הסינון משותף ל-Smart Sort ול-Direct Sort ומתבצע לפני מנוע הסידור שנבחר.
    // אלגוריתם Smart Sort המאושר עצמו נשאר ללא שינוי.
    private int selectedFilterMode = FILTER_ALL;
    private Spinner filterModeSpinner;
    private LinearLayout artistFilterContainer;
    private LinearLayout genreFilterContainer;
    private Button artistFilterButton;
    private Button genreFilterButton;
    private TextView filterCountText;
    private boolean filterOptionsUpdating = false;
    private final List<String> artistFilterOptions = new ArrayList<>();
    private final List<String> genreFilterOptions = new ArrayList<>();
    private final List<String> selectedArtistFilters = new ArrayList<>();
    private final List<String> selectedGenreFilters = new ArrayList<>();

    // GUI performance cache. The filter count is derived data and should not be rebuilt
    // every 500 ms by the foreground-state poller. Invalidated only when the library or
    // filter selection changes.
    private int cachedFilterCount = -1;
    private int cachedFilterMode = -1;
    private int cachedFilterSourceSize = -1;
    private String cachedFilterArtist = null;
    private String cachedFilterGenre = null;
    // ========================= FILTER GUI - END =========================

    private static final List<Song> analyzedSongs = new ArrayList<>();
    private static int lastSkipped = 0;
    private static int lastCacheHits = 0;
    private static int lastAppliedAnalysisRevision = -1;
    private static long lastOperationDurationMs = 0L;
    private int lastPresentedMetadataRevision = -1;
    private boolean metadataResultsDialogShowing = false;

    private final Runnable uiStatePoller = new Runnable() {
        @Override public void run() {
            syncUiFromSharedState();
            main.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(UI_BG);
        getWindow().setNavigationBarColor(UI_BG);
        buildUi();
        restoreSettings();
        restoreFolder();
        restoreOutputFolder();
        refreshFilterOptions();
        syncUiFromSharedState();
    }

    @Override
    protected void onResume() {
        super.onResume();
        main.removeCallbacks(uiStatePoller);
        main.post(uiStatePoller);
    }

    @Override
    protected void onPause() {
        main.removeCallbacks(uiStatePoller);
        super.onPause();
    }

    private void syncUiFromSharedState() {
        if (statusText == null || progressBar == null) return;

        BackgroundWorkService.State serviceState = BackgroundWorkService.getState(getApplicationContext());
        sharedBusy = serviceState.busy;
        sharedProgress = serviceState.progress;
        lastOperationDurationMs = serviceState.lastDurationMs;
        if (!serviceState.status.isEmpty()) sharedStatus = serviceState.status;

        // Lock before any task-completion refreshes below. On unlock the old enabled state is
        // restored first, then refreshFilterOptions()/setCorrectionsEnabled()/createButton state
        // in this same method can apply the newly completed task state.
        setBusyUiLocked(sharedBusy);

        if (serviceState.analysisReady && serviceState.analysisRevision != lastAppliedAnalysisRevision) {
            List<Song> restored = BackgroundWorkService.getAnalysisSnapshot(getApplicationContext());
            if (restored.size() >= 2) {
                // Re-apply persisted internal overrides so an older snapshot cannot hide a
                // correction that still exists in SharedPreferences. No audio file is touched.
                for (Song song : restored) applyManualOverride(getApplicationContext(), song);
                analyzedSongs.clear();
                analyzedSongs.addAll(restored);
                lastSkipped = serviceState.skipped;
                lastCacheHits = serviceState.cacheHits;
                lastAppliedAnalysisRevision = serviceState.analysisRevision;
                refreshFilterOptions();
                updateCorrectionsSummary();
                if (!sharedBusy && resultText != null && serviceState.resultText.isEmpty()) {
                    showAnalysisSummary();
                }
            }
        }

        if (!sharedBusy && serviceState.metadataResultsReady
                && serviceState.metadataResultsRevision != lastPresentedMetadataRevision
                && !metadataResultsDialogShowing) {
            List<BackgroundWorkService.MetadataLookupResultItem> stored =
                    BackgroundWorkService.getMetadataLookupResults(getApplicationContext());
            if (!stored.isEmpty()) {
                List<OnlineBatchItem> converted = new ArrayList<>();
                for (BackgroundWorkService.MetadataLookupResultItem item : stored) {
                    Exception error = item.error.isEmpty() ? null : new IllegalStateException(item.error);
                    converted.add(new OnlineBatchItem(item.songIndex, item.result, error));
                }
                lastPresentedMetadataRevision = serviceState.metadataResultsRevision;
                showOnlineBatchResults(serviceState.metadataField,
                        serviceState.metadataCheckingExistingGenre, converted,
                        serviceState.metadataResultsRevision);
            }
        }

        if (!sharedStatus.isEmpty()) statusText.setText(sharedStatus);
        if (resultText != null && !serviceState.resultText.isEmpty()) {
            resultText.setText(serviceState.resultText);
        }
        if (sharedBusy) {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(sharedProgress);
        } else {
            progressBar.setVisibility(View.GONE);
        }

        // The global progress bar lives near the analysis controls and may be off-screen while
        // the user is working in Changes & corrections. Mirror metadata lookup progress inside
        // that card so an open Activity never looks frozen. The same service continues when the
        // Activity is paused/stopped, and onResume the 500 ms poller immediately re-attaches.
        boolean metadataLookupBusy = sharedBusy && "METADATA_LOOKUP".equals(serviceState.taskType);
        if (correctionsWorkText != null && correctionsProgressBar != null) {
            if (metadataLookupBusy) {
                String detail = serviceState.status == null || serviceState.status.trim().isEmpty()
                        ? tr("בודק metadata ברשת…", "Checking online metadata…")
                        : serviceState.status;
                correctionsWorkText.setText("⏳ " + detail + "\n" + tr(
                        "אפשר להשאיר את האפליקציה פתוחה; אם תצא, הבדיקה תמשיך ברקע ותחזור לאותו חיווי כשתשוב.",
                        "You can keep the app open; if you leave, the check continues in the background and this live status returns when you come back."));
                correctionsWorkText.setVisibility(View.VISIBLE);
                correctionsProgressBar.setVisibility(View.VISIBLE);
                correctionsProgressBar.setIndeterminate(sharedProgress <= 0);
                if (sharedProgress > 0) correctionsProgressBar.setProgress(sharedProgress);
            } else {
                correctionsWorkText.setVisibility(View.GONE);
                correctionsProgressBar.setVisibility(View.GONE);
                correctionsProgressBar.setIndeterminate(false);
            }
        }
        if (analyzeButton != null) analyzeButton.setEnabled(!sharedBusy && treeUri != null);
        if (createButton != null) createButton.setEnabled(!sharedBusy && canCreatePlaylist());
        setCorrectionsEnabled(!sharedBusy && !analyzedSongs.isEmpty());
    }

    // ========================= GUI BUILD - START =========================
    // EN: 3.4.x keeps the application focused on playlist creation and adds a dedicated metadata-corrections area. The visual language is
    // inspired by modern dark audio software (rounded cards, clear hierarchy, violet accent)
    // but it does not copy a player screen and intentionally contains no playback controls.
    // HE: גרסאות 3.4.x משאירות את האפליקציה ככלי ליצירת פלייליסטים ומוסיפה אזור ייעודי לתיקוני metadata. השפה הגרפית
    // משתמשת בכרטיסים כהים, היררכיה ברורה והדגשה סגולה, ללא מסכי נגן או פקדי נגינה.
    private void buildUi() {
        settingsInitialized = false;
        final boolean hebrewUi = AppLanguage.isHebrew(this);
        final int uiDirection = hebrewUi ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR;

        // 3.4.13: visually separate the two nested vertical scrollbars. Keep the app-level
        // scrollbar on the natural side for the UI direction, put Results on the opposite
        // side, and make both bars twice the Android system scrollbar size. Touch ownership
        // remains exactly as in 3.4.12.
        final int doubledScrollBarSize = Math.max(dp(2),
                ViewConfiguration.get(this).getScaledScrollBarSize() * 2);
        final int outerScrollBarPosition = hebrewUi
                ? View.SCROLLBAR_POSITION_LEFT : View.SCROLLBAR_POSITION_RIGHT;
        final int resultsScrollBarPosition = hebrewUi
                ? View.SCROLLBAR_POSITION_RIGHT : View.SCROLLBAR_POSITION_LEFT;

        // 3.4.12: arbitrate touch ownership at the outer ScrollView too.
        // If a new gesture starts inside Results, the inner Results ScrollView must get the
        // ACTION_DOWN even when the app-level ScrollView is still settling/flinging. Without
        // this, once the outer scroll takes over at an inner edge it can keep stealing later
        // gestures before Results has a chance to request ownership again.
        final ScrollView[] resultsScrollHolder = new ScrollView[1];
        ScrollView scroll = new ScrollView(this) {
            private boolean gestureStartedInResults = false;

            private boolean isInsideResults(MotionEvent event) {
                ScrollView inner = resultsScrollHolder[0];
                if (inner == null || inner.getVisibility() != View.VISIBLE) return false;
                int[] location = new int[2];
                inner.getLocationOnScreen(location);
                float x = event.getRawX();
                float y = event.getRawY();
                return x >= location[0] && x < location[0] + inner.getWidth()
                        && y >= location[1] && y < location[1] + inner.getHeight();
            }

            @Override
            public boolean onInterceptTouchEvent(MotionEvent event) {
                int action = event.getActionMasked();
                if (action == MotionEvent.ACTION_DOWN) {
                    gestureStartedInResults = isInsideResults(event);
                    // Let ScrollView initialize its own gesture state, but never consume the
                    // initial DOWN when it landed inside Results. This also defeats an outer
                    // fling that would otherwise steal the next Results gesture.
                    boolean outerWouldIntercept = super.onInterceptTouchEvent(event);
                    return gestureStartedInResults ? false : outerWouldIntercept;
                }
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    gestureStartedInResults = false;
                }
                return super.onInterceptTouchEvent(event);
            }
        };
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI_BG);
        scroll.setLayoutDirection(uiDirection);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setVerticalScrollbarPosition(outerScrollBarPosition);
        scroll.setScrollBarSize(doubledScrollBarSize);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        // Base padding is combined with system-bar insets below. Android 15+ uses
        // edge-to-edge by default for targetSdk 35, so relying on a fixed top margin
        // can place the title under the status bar on some phones.
        root.setPadding(dp(18), dp(10), dp(18), dp(24));
        root.setLayoutDirection(uiDirection);
        root.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        root.setBackgroundColor(UI_BG);
        busyUiRoot = root;
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        // ================= SYSTEM BAR SAFE AREA - START =================
        // EN: Keep the top title and the final controls outside the status/navigation bars.
        // HE: שומר את הכותרת ואת הפקדים התחתונים מחוץ לאזורי שורת המצב/הניווט.
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(UI_BG);
            getWindow().setNavigationBarColor(UI_BG);
        }
        if (Build.VERSION.SDK_INT >= 20) {
            scroll.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                root.setPadding(dp(18), dp(10) + top, dp(18), dp(24) + bottom);
                return insets;
            });
            scroll.requestApplyInsets();
        }
        // ================== SYSTEM BAR SAFE AREA - END ==================

        // Header: fixed single-line product name and truly compact language selector.
        // Keeping the product title on one row prevents wrapping on narrow phones.
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        // Product name is Latin text; keep the top bar geometrically stable in both languages.
        header.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        TextView title = makeInfoText("Playlist Maker", 25);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(UI_TEXT);
        title.setSingleLine(true);
        title.setMaxLines(1);
        title.setHorizontallyScrolling(false);
        title.setTextDirection(View.TEXT_DIRECTION_LTR);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout languageBox = new LinearLayout(this);
        languageBox.setOrientation(LinearLayout.HORIZONTAL);
        languageBox.setGravity(Gravity.CENTER_VERTICAL);
        languageBox.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        Button heButton = makePillButton("עב", hebrewUi);
        Button enButton = makePillButton("EN", !hebrewUi);
        heButton.setContentDescription("עברית");
        enButton.setContentDescription("English");
        heButton.setOnClickListener(v -> switchUiLanguage(AppLanguage.HEBREW));
        enButton.setOnClickListener(v -> switchUiLanguage(AppLanguage.ENGLISH));
        languageBox.addView(heButton, compactLanguageButtonParams());
        LinearLayout.LayoutParams enLp = compactLanguageButtonParams();
        enLp.setMarginStart(dp(5));
        languageBox.addView(enButton, enLp);
        header.addView(languageBox, new LinearLayout.LayoutParams(-2, -2));

        LinearLayout.LayoutParams headerLp = new LinearLayout.LayoutParams(-1, -2);
        headerLp.bottomMargin = dp(4);
        root.addView(header, headerLp);

        TextView subtitle = makeInfoText(tr("בניית פלייליסטים חכמה או מיון ישיר מספריות המוזיקה המקומיות",
                "Smart or direct playlist building from your local music libraries"), 12);
        subtitle.setTextColor(UI_MUTED);
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(-1, -2);
        subtitleLp.bottomMargin = dp(16);
        root.addView(subtitle, subtitleLp);

        // Step 1 — Library source.
        LinearLayout libraryCard = makeCard();
        addStepHeader(libraryCard, "1", tr("ספריות מוזיקה", "Music libraries"),
                tr("בחר ספרייה אחת או יותר; לכל ספרייה ניתן לבחור אם לסרוק גם את תתי-הספריות",
                        "Choose one or more libraries; each library can optionally include all subfolders"));
        Button folderButton = makeButton(tr("▣  בחר ספריות מוזיקה", "▣  Choose music libraries"));
        folderButton.setOnClickListener(v -> chooseFolder());
        libraryCard.addView(folderButton, buttonParams(10));
        folderText = makeInfoText(tr("לא נבחרו ספריות", "No libraries selected"), 13);
        folderText.setTextColor(UI_MUTED);
        folderText.setBackground(roundedDrawable(UI_SURFACE, 14, UI_BORDER, 1));
        folderText.setPadding(dp(13), dp(11), dp(13), dp(11));
        libraryCard.addView(folderText, buttonParams(8));
        root.addView(libraryCard, cardParams());

        // Step 2 — Analysis.
        LinearLayout analysisCard = makeCard();
        addStepHeader(analysisCard, "2", tr("ניתוח הספריות", "Library analysis"),
                tr("קורא תגיות ומנתח קצב, עוצמה ואופי. העבודה ממשיכה ברקע.",
                        "Reads tags and analyzes tempo, loudness and character. Work continues in background."));
        analyzeButton = makeButton(tr("✦  סרוק ונתח את הספריות", "✦  Scan and analyze libraries"));
        analyzeButton.setEnabled(false);
        analyzeButton.setOnClickListener(v -> analyzeLibrary());
        analysisCard.addView(analyzeButton, buttonParams(10));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        if (Build.VERSION.SDK_INT >= 21) {
            progressBar.setProgressTintList(ColorStateList.valueOf(UI_ACCENT));
            progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(UI_BORDER));
        }
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-1, dp(6));
        progressLp.topMargin = dp(12);
        analysisCard.addView(progressBar, progressLp);

        statusText = makeInfoText(tr("מוכן. בחר ספרייה אחת או יותר והתחל ניתוח.",
                "Ready. Choose one or more libraries and start analysis."), 13);
        statusText.setTextColor(UI_MUTED);
        statusText.setBackground(roundedDrawable(UI_SURFACE, 14, UI_BORDER, 1));
        statusText.setPadding(dp(13), dp(11), dp(13), dp(11));
        analysisCard.addView(statusText, buttonParams(9));
        root.addView(analysisCard, cardParams());

        // Step 3 — Filter before scheduling.
        LinearLayout filterCard = makeCard();
        addStepHeader(filterCard, "3", tr("סינון הפלייליסט", "Playlist filter"),
                tr("בחר את כל השירים, אמנים מסוימים או Genres מסוימים לפני הסידור.",
                        "Choose all songs, selected artists, or selected genres before sorting."));

        // 3.2.1 keeps one clear progressive selector; Artist and Genre support multi-selection.
        // The next relevant control appears only after the user chooses a filter type.
        TextView filterTypeLabel = makeLabel(tr("סוג סינון", "Filter type"));
        filterCard.addView(filterTypeLabel, buttonParams(9));
        filterModeSpinner = makeDarkSpinner();
        List<String> filterModes = Arrays.asList(
                tr("כל השירים", "All songs"),
                tr("לפי אמן", "By artist"),
                tr("לפי Genre", "By genre"));
        filterModeSpinner.setAdapter(darkSpinnerAdapter(filterModes));
        filterModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (filterOptionsUpdating) return;
                int newMode = clampInt(position, FILTER_ALL, FILTER_GENRE);
                if (selectedFilterMode != newMode) {
                    selectedFilterMode = newMode;
                    invalidateFilterCountCache();
                    updateFilterUi();
                    saveSettings();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        filterCard.addView(filterModeSpinner, buttonParams(5));

        artistFilterContainer = makeSelectorContainer(tr("אמנים", "Artists"));
        artistFilterButton = makeButton(tr("בחר אמנים", "Choose artists"));
        artistFilterButton.setOnClickListener(v -> showMultiSelectFilterDialog(true));
        artistFilterContainer.addView(artistFilterButton, buttonParams(5));
        TextView artistHint = makeInfoText(tr("ניתן לבחור כמה אמנים. הרשימה נגללת והבחירות מסומנות ✓.",
                "Select multiple artists. The list scrolls and selected items are checked ✓."), 11);
        artistHint.setTextColor(UI_MUTED);
        artistFilterContainer.addView(artistHint, buttonParams(4));
        filterCard.addView(artistFilterContainer, buttonParams(9));

        genreFilterContainer = makeSelectorContainer("Genre");
        genreFilterButton = makeButton(tr("בחר Genres", "Choose genres"));
        genreFilterButton.setOnClickListener(v -> showMultiSelectFilterDialog(false));
        genreFilterContainer.addView(genreFilterButton, buttonParams(5));
        TextView genreHint = makeInfoText(tr("ניתן לבחור כמה סוגי מוזיקה. הרשימה נגללת והבחירות מסומנות ✓.",
                "Select multiple genres. The list scrolls and selected items are checked ✓."), 11);
        genreHint.setTextColor(UI_MUTED);
        genreFilterContainer.addView(genreHint, buttonParams(4));
        filterCard.addView(genreFilterContainer, buttonParams(7));

        filterCountText = makeInfoText(tr("לא נותחה עדיין ספרייה.", "Library has not been analyzed yet."), 12);
        filterCountText.setTextColor(UI_MUTED);
        filterCard.addView(filterCountText, buttonParams(8));
        root.addView(filterCard, cardParams());

        // Step 4 — Sort strategy and playlist output.
        LinearLayout playlistCard = makeCard();
        addStepHeader(playlistCard, "4", tr("סידור ויצירה", "Sort & create"),
                tr("בחר Smart Sort או Direct Sort, שם קובץ ותיקיית שמירה וצור M3U8.",
                        "Choose Smart Sort or Direct Sort, file name and save folder, then create an M3U8."));

        TextView strategyLabel = makeLabel(tr("שיטת סידור", "Sort method"));
        playlistCard.addView(strategyLabel, buttonParams(5));
        sortStrategySpinner = makeDarkSpinner();
        sortStrategySpinner.setAdapter(darkSpinnerAdapter(Arrays.asList("Smart Sort", "Direct Sort")));
        sortStrategySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (directSortUiUpdating) return;
                int newStrategy = clampInt(position, SORT_SMART, SORT_DIRECT);
                if (selectedSortStrategy != newStrategy) {
                    selectedSortStrategy = newStrategy;
                    updateSortStrategyUi();
                    saveSettings();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        playlistCard.addView(sortStrategySpinner, buttonParams(5));

        // Smart Sort owns the existing flow controls. They disappear completely in Direct Sort.
        smartFlowContainer = new LinearLayout(this);
        smartFlowContainer.setOrientation(LinearLayout.VERTICAL);
        TextView modeLabel = makeLabel(tr("זרימת הפלייליסט", "Playlist flow"));
        smartFlowContainer.addView(modeLabel, buttonParams(9));
        modeSpinner = makeDarkSpinner();
        List<String> modes = Arrays.asList(tr("מאוזן", "Balanced"), tr("מתגבר", "Rising"), tr("יורד", "Falling"));
        modeSpinner.setAdapter(darkSpinnerAdapter(modes));
        modeSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(() -> {
            updateFlowHelp();
            saveSettings();
        }));
        smartFlowContainer.addView(modeSpinner, buttonParams(5));
        flowHelpText = makeInfoText("", 12);
        flowHelpText.setTextColor(UI_MUTED);
        smartFlowContainer.addView(flowHelpText, buttonParams(4));
        updateFlowHelp();
        playlistCard.addView(smartFlowContainer, new LinearLayout.LayoutParams(-1, -2));

        // Direct Sort 3.3.2: one fixed list of all metadata fields. At least one field is always
        // checked. Long-press the ≡ handle and move vertically to set priority; the row remains
        // constrained to the list width instead of using Android's free-floating drag shadow.
        // No flow/energy controls are shown because direct sorting is intentionally strict.
        directSortContainer = new LinearLayout(this);
        directSortContainer.setOrientation(LinearLayout.VERTICAL);
        TextView directHelp = makeInfoText(tr(
                "סמן ✓ ליד הפרמטרים הרצויים. לפחות פרמטר אחד חייב להישאר מסומן. סדר השורות מלמעלה למטה הוא העדיפות; לשינוי הסדר לחץ לחיצה ארוכה על ≡ וגרור רק מעלה/מטה.",
                "Check ✓ the fields you want. At least one field must stay checked. Top-to-bottom row order is the priority; long-press ≡ and drag vertically."), 12);
        directHelp.setTextColor(UI_MUTED);
        directSortContainer.addView(directHelp, buttonParams(9));
        directCriteriaContainer = new LinearLayout(this);
        directCriteriaContainer.setOrientation(LinearLayout.VERTICAL);
        directSortContainer.addView(directCriteriaContainer, buttonParams(4));
        playlistCard.addView(directSortContainer, new LinearLayout.LayoutParams(-1, -2));
        updateSortStrategyUi();

        TextView nameLabel = makeLabel(tr("שם הפלייליסט", "Playlist name"));
        playlistCard.addView(nameLabel, buttonParams(11));
        playlistNameEdit = new EditText(this);
        playlistNameEdit.setSingleLine(true);
        playlistNameEdit.setHint(tr("לדוגמה: My Playlist", "Example: My Playlist"));
        playlistNameEdit.setHintTextColor(UI_MUTED);
        playlistNameEdit.setTextColor(UI_TEXT);
        playlistNameEdit.setText(DEFAULT_PLAYLIST_NAME);
        playlistNameEdit.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        playlistNameEdit.setBackground(roundedDrawable(UI_SURFACE, 14, UI_BORDER, 1));
        playlistNameEdit.setPadding(dp(14), dp(11), dp(14), dp(11));
        playlistCard.addView(playlistNameEdit, buttonParams(5));

        // ================= PLAYLIST OUTPUT FOLDER - START =================
        // EN: Playlist output is independent from the analyzed music folder. If no dedicated
        // output tree is selected, the music folder remains the backward-compatible default.
        // HE: תיקיית הפלט של הפלייליסט נפרדת מתיקיית המוזיקה. אם לא נבחרה תיקייה
        // ייעודית, תיקיית המוזיקה נשארת ברירת המחדל לצורך תאימות לאחור.
        TextView outputLabel = makeLabel(tr("תיקיית שמירת הפלייליסט", "Playlist save folder"));
        playlistCard.addView(outputLabel, buttonParams(11));
        outputFolderText = makeInfoText("", 12);
        outputFolderText.setTextColor(UI_MUTED);
        outputFolderText.setBackground(roundedDrawable(UI_SURFACE, 14, UI_BORDER, 1));
        outputFolderText.setPadding(dp(13), dp(11), dp(13), dp(11));
        playlistCard.addView(outputFolderText, buttonParams(5));

        LinearLayout outputTools = new LinearLayout(this);
        outputTools.setOrientation(LinearLayout.HORIZONTAL);
        outputTools.setLayoutDirection(uiDirection);
        Button chooseOutputButton = makeButton(tr("בחר / שנה", "Choose / change"));
        chooseOutputButton.setOnClickListener(v -> chooseOutputFolder());
        outputTools.addView(chooseOutputButton, choiceParams());
        Button resetOutputButton = makeButton(tr("הספרייה הראשונה", "First library"));
        resetOutputButton.setOnClickListener(v -> useMusicFolderForOutput());
        LinearLayout.LayoutParams resetOutputLp = choiceParams();
        resetOutputLp.setMarginStart(dp(8));
        outputTools.addView(resetOutputButton, resetOutputLp);
        playlistCard.addView(outputTools, buttonParams(7));
        updateOutputFolderText();
        // ================== PLAYLIST OUTPUT FOLDER - END ==================

        analysisReportCheckBox = new CheckBox(this);
        analysisReportCheckBox.setText(tr("צור גם קובץ בדיקה analysis.txt", "Also create analysis.txt diagnostic file"));
        analysisReportCheckBox.setChecked(true);
        analysisReportCheckBox.setTextColor(UI_TEXT);
        analysisReportCheckBox.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        if (Build.VERSION.SDK_INT >= 21) analysisReportCheckBox.setButtonTintList(ColorStateList.valueOf(UI_ACCENT));
        analysisReportCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> saveSettings());
        playlistCard.addView(analysisReportCheckBox, buttonParams(8));

        createButton = makePrimaryButton(tr("✦  צור פלייליסט", "✦  Generate playlist"));
        createButton.setEnabled(false);
        createButton.setOnClickListener(v -> createPlaylistFromAnalysis());
        playlistCard.addView(createButton, buttonParams(12));

        Button clearCacheButton = makeButton(tr("נקה מטמון", "Clear cache"));
        clearCacheButton.setOnClickListener(v -> confirmClearCache());
        playlistCard.addView(clearCacheButton, buttonParams(8));

        root.addView(playlistCard, cardParams());

        // Step 5 — Changes & corrections. All metadata repair workflows live here.
        LinearLayout correctionsCard = makeCard();
        addStepHeader(correctionsCard, "5", tr("שינויים ותיקונים", "Changes & corrections"),
                tr("איתור שדות חסרים, בדיקת Genre קיים ותיקון ידני. מידע מהרשת הוא הצעה בלבד.",
                        "Find missing fields, verify existing Genre, or edit manually. Internet data is suggestion-only."));
        correctionsSummaryText = makeInfoText(tr("יש לנתח ספרייה כדי לבדוק metadata.",
                "Analyze a library to inspect metadata."), 12);
        correctionsSummaryText.setTextColor(UI_MUTED);
        correctionsSummaryText.setBackground(roundedDrawable(UI_SURFACE, 14, UI_BORDER, 1));
        correctionsSummaryText.setPadding(dp(13), dp(11), dp(13), dp(11));
        correctionsCard.addView(correctionsSummaryText, buttonParams(9));

        // 3.4.3/3.4.4: metadata lookup remains owned by the resumable service, but while the
        // Activity is visible this card mirrors the live service state. Leaving the screen
        // requires no hand-off; returning simply re-attaches this UI to the same persisted job.
        correctionsWorkText = makeInfoText(tr("בודק metadata…", "Checking metadata…"), 12);
        correctionsWorkText.setTextColor(UI_TEXT);
        correctionsWorkText.setBackground(roundedDrawable(UI_SURFACE, 14, UI_ACCENT, 1));
        correctionsWorkText.setPadding(dp(13), dp(11), dp(13), dp(11));
        correctionsWorkText.setVisibility(View.GONE);
        correctionsCard.addView(correctionsWorkText, buttonParams(5));

        correctionsProgressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        correctionsProgressBar.setMax(100);
        correctionsProgressBar.setVisibility(View.GONE);
        if (Build.VERSION.SDK_INT >= 21) {
            correctionsProgressBar.setProgressTintList(ColorStateList.valueOf(UI_ACCENT));
            correctionsProgressBar.setProgressBackgroundTintList(ColorStateList.valueOf(UI_BORDER));
        }
        LinearLayout.LayoutParams correctionsProgressLp = new LinearLayout.LayoutParams(-1, dp(6));
        correctionsProgressLp.topMargin = dp(3);
        correctionsProgressLp.bottomMargin = dp(8);
        correctionsCard.addView(correctionsProgressBar, correctionsProgressLp);

        missingMetadataButton = makeButton(tr("שדות חסרים", "Missing fields"));
        missingMetadataButton.setEnabled(false);
        missingMetadataButton.setOnClickListener(v -> showMissingFieldsDialog());
        correctionsCard.addView(missingMetadataButton, buttonParams(6));

        genreCheckButton = makeButton(tr("בדיקת Genre קיים", "Check existing Genre"));
        genreCheckButton.setEnabled(false);
        genreCheckButton.setOnClickListener(v -> showExistingGenrePicker());
        correctionsCard.addView(genreCheckButton, buttonParams(6));

        manualMetadataButton = makeButton(tr("הזנה ותיקון ידניים", "Manual metadata edit"));
        manualMetadataButton.setEnabled(false);
        manualMetadataButton.setOnClickListener(v -> showMetadataEditor());
        correctionsCard.addView(manualMetadataButton, buttonParams(7));

        TextView correctionsPolicy = makeInfoText(tr(
                "תיקונים מאושרים נשמרים כ-override פנימי של Playlist Maker. קובצי MP3/FLAC אינם נכתבים מחדש.",
                "Approved corrections are stored as Playlist Maker internal overrides. MP3/FLAC files are not rewritten."), 11);
        correctionsPolicy.setTextColor(UI_MUTED);
        correctionsCard.addView(correctionsPolicy, buttonParams(4));
        root.addView(correctionsCard, cardParams());

        // Step 6 — Results.
        LinearLayout resultsCard = makeCard();
        addStepHeader(resultsCard, "6", tr("תוצאות", "Results"),
                tr("מספר שירים, זמן עבודה וסיכום שיטת הסידור.", "Song count, duration and sort summary."));
        resultText = makeInfoText(tr("עדיין אין תוצאות להצגה.", "No results yet."), 13);
        resultText.setTextIsSelectable(true);
        resultText.setTextColor(UI_TEXT);
        resultText.setPadding(dp(13), dp(12), dp(13), dp(12));

        // 3.4.11: keep Results independently scrollable inside the app-level ScrollView.
        // Use a normal ScrollView around the existing TextView instead of changing TextView's
        // movement method. This gives long results a visible scrollbar while keeping the
        // result rendering and playlist logic untouched.
        ScrollView resultsScroll = new ScrollView(this) {
            private float lastTouchY;

            @Override
            public boolean dispatchTouchEvent(MotionEvent event) {
                ViewParent outerParent = getParent();
                int action = event.getActionMasked();

                if (action == MotionEvent.ACTION_DOWN) {
                    lastTouchY = event.getY();
                    // Receive the gesture here before resultText can become the touch target.
                    // This prevents the main app ScrollView from stealing a Results drag.
                    if (outerParent != null) {
                        outerParent.requestDisallowInterceptTouchEvent(true);
                    }
                } else if (action == MotionEvent.ACTION_MOVE) {
                    float currentY = event.getY();
                    float fingerDelta = currentY - lastTouchY;
                    boolean canConsume;
                    if (fingerDelta > 0f) {
                        // Finger moves down: inner content needs to scroll toward its top.
                        canConsume = canScrollVertically(-1);
                    } else if (fingerDelta < 0f) {
                        // Finger moves up: inner content needs to scroll toward its bottom.
                        canConsume = canScrollVertically(1);
                    } else {
                        canConsume = canScrollVertically(-1) || canScrollVertically(1);
                    }
                    if (outerParent != null) {
                        outerParent.requestDisallowInterceptTouchEvent(canConsume);
                    }
                    lastTouchY = currentY;
                } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    if (outerParent != null) {
                        outerParent.requestDisallowInterceptTouchEvent(false);
                    }
                }

                return super.dispatchTouchEvent(event);
            }
        };
        resultsScrollHolder[0] = resultsScroll;
        resultsScroll.setVerticalScrollBarEnabled(true);
        resultsScroll.setScrollbarFadingEnabled(false);
        resultsScroll.setVerticalScrollbarPosition(resultsScrollBarPosition);
        resultsScroll.setScrollBarSize(doubledScrollBarSize);
        resultsScroll.setScrollBarStyle(View.SCROLLBARS_INSIDE_INSET);
        resultsScroll.setBackground(roundedDrawable(UI_SURFACE, 14, UI_BORDER, 1));
        resultsScroll.setFillViewport(true);
        resultsScroll.addView(resultText, new ScrollView.LayoutParams(-1, -2));
        LinearLayout.LayoutParams resultsScrollLp = new LinearLayout.LayoutParams(-1, dp(260));
        resultsScrollLp.topMargin = dp(7);
        resultsScrollLp.bottomMargin = dp(7);
        resultsCard.addView(resultsScroll, resultsScrollLp);
        root.addView(resultsCard, cardParams());

        // 3.4.6: About/developer identity only. Keep this footer separate from playlist behavior.
        Button aboutButton = makeButton(tr("ⓘ  אודות", "ⓘ  About"));
        aboutButton.setOnClickListener(v -> showAboutDialog());
        LinearLayout.LayoutParams aboutLp = buttonParams(10);
        root.addView(aboutButton, aboutLp);

        TextView version = makeInfoText(tr(
                "גרסה " + BuildConfig.VERSION_NAME + " • פיתוח: Avi Y.",
                "Version " + BuildConfig.VERSION_NAME + " • Developed by Avi Y."), 11);
        version.setTextColor(UI_MUTED);
        version.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams versionLp = new LinearLayout.LayoutParams(-1, -2);
        versionLp.topMargin = dp(6);
        root.addView(version, versionLp);

        setContentView(scroll);
        updateFilterUi();
        updateCorrectionsSummary();
    }
    // ========================== GUI BUILD - END ==========================

    /**
     * 3.4.6 About screen. This is presentation/legal attribution only; it does not touch
     * scanning, metadata, Smart Sort, Direct Sort or any scheduling logic.
     */
    private void showAboutDialog() {
        String message = tr(
                "Playlist Maker\n"
                        + "גרסה " + BuildConfig.VERSION_NAME + "\n"
                        + "פיתוח: Avi Y.\n\n"
                        + "© 2026 Avi Y.\n"
                        + "פותח על ידי Avi Y. בסיוע ChatGPT (OpenAI).",
                "Playlist Maker\n"
                        + "Version " + BuildConfig.VERSION_NAME + "\n"
                        + "Developed by Avi Y.\n\n"
                        + "© 2026 Avi Y.\n"
                        + "Developed by Avi Y. with AI assistance from ChatGPT (OpenAI)."
        );
        new AlertDialog.Builder(this)
                .setTitle(tr("אודות", "About"))
                .setMessage(message)
                .setPositiveButton(tr("סגור", "Close"), null)
                .show();
    }

    private LinearLayout makeCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(16));
        card.setBackground(roundedDrawable(UI_CARD, 22, UI_BORDER, 1));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(2));
        return card;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        return lp;
    }

    private void addStepHeader(LinearLayout card, String step, String title, String subtitle) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(card.getLayoutDirection());

        TextView badge = makeInfoText(step, 13);
        badge.setGravity(Gravity.CENTER);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setTextColor(UI_TEXT);
        badge.setBackground(roundedDrawable(UI_ACCENT_SOFT, 999, UI_ACCENT, 1));
        row.addView(badge, new LinearLayout.LayoutParams(dp(34), dp(34)));

        LinearLayout textBox = new LinearLayout(this);
        textBox.setOrientation(LinearLayout.VERTICAL);
        TextView heading = makeInfoText(title, 19);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setTextColor(UI_TEXT);
        textBox.addView(heading);
        TextView sub = makeInfoText(subtitle, 12);
        sub.setTextColor(UI_MUTED);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(2);
        textBox.addView(sub, subLp);
        LinearLayout.LayoutParams boxLp = new LinearLayout.LayoutParams(0, -2, 1f);
        boxLp.setMarginStart(dp(11));
        row.addView(textBox, boxLp);
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(UI_TEXT);
        b.setTextSize(14);
        b.setMinHeight(dp(48));
        b.setPadding(dp(13), dp(9), dp(13), dp(9));
        // Visible pressed state: a tap briefly changes both fill and border to violet.
        b.setBackground(pressStateDrawable(UI_SURFACE, UI_ACCENT_SOFT, UI_BORDER, UI_ACCENT, 15));
        return b;
    }

    private Button makePrimaryButton(String text) {
        Button b = makeButton(text);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(pressStateDrawable(UI_ACCENT_SOFT, UI_ACCENT, UI_ACCENT, UI_TEXT, 17));
        b.setMinHeight(dp(56));
        return b;
    }

    private Button makePillButton(String text, boolean selected) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setPadding(dp(10), dp(5), dp(10), dp(5));
        b.setTextColor(selected ? UI_TEXT : UI_MUTED);
        int normalFill = selected ? UI_ACCENT_SOFT : UI_SURFACE;
        int normalStroke = selected ? UI_ACCENT : UI_BORDER;
        b.setBackground(pressStateDrawable(normalFill, UI_ACCENT_SOFT, normalStroke, UI_ACCENT, 999));
        return b;
    }

    private LinearLayout.LayoutParams compactLanguageButtonParams() {
        return new LinearLayout.LayoutParams(dp(46), dp(32));
    }

    private void switchUiLanguage(String language) {
        boolean wantHebrew = AppLanguage.HEBREW.equals(language);
        if (AppLanguage.isHebrew(this) == wantHebrew) return;
        saveSettings();
        AppLanguage.setLanguage(this, language);

        // ================= FAST LANGUAGE SWITCH - START =================
        // EN: All strings are created programmatically, so rebuilding only the visible view
        // hierarchy is enough. Avoiding Activity.recreate() prevents a full lifecycle restart
        // and keeps an active foreground task untouched.
        // HE: כל הטקסטים נוצרים בקוד, לכן מספיק לבנות מחדש רק את עץ ה-View. כך נמנע
        // restart מלא של ה-Activity ומשימת רקע פעילה נשארת ללא שינוי.
        buildUi();
        restoreSettings();
        restoreFolder();
        restoreOutputFolder();
        refreshFilterOptions();
        syncUiFromSharedState();
        // ================== FAST LANGUAGE SWITCH - END ==================
    }

    private LinearLayout.LayoutParams choiceParams() {
        return new LinearLayout.LayoutParams(0, -2, 1f);
    }

    private LinearLayout makeSelectorContainer(String labelText) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView label = makeLabel(labelText);
        box.addView(label, new LinearLayout.LayoutParams(-1, -2));
        return box;
    }

    private Spinner makeDarkSpinner() {
        Spinner spinner = new Spinner(this);
        spinner.setPadding(dp(12), dp(4), dp(12), dp(4));
        spinner.setBackground(roundedDrawable(UI_SURFACE, 14, UI_BORDER, 1));
        if (Build.VERSION.SDK_INT >= 16) spinner.setPopupBackgroundDrawable(roundedDrawable(UI_CARD, 12, UI_BORDER, 1));
        return spinner;
    }

    private ArrayAdapter<String> darkSpinnerAdapter(List<String> items) {
        return new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(UI_TEXT);
                v.setTextSize(14);
                v.setPadding(dp(8), dp(8), dp(8), dp(8));
                return v;
            }
            @Override public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getDropDownView(position, convertView, parent);
                v.setTextColor(UI_TEXT);
                v.setBackgroundColor(UI_CARD);
                v.setTextSize(14);
                v.setPadding(dp(14), dp(12), dp(14), dp(12));
                return v;
            }
        };
    }

    private TextView makeInfoText(String text, float sizeSp) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sizeSp);
        view.setTextColor(UI_TEXT);
        view.setGravity(Gravity.START);
        view.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        return view;
    }

    private TextView makeLabel(String text) {
        TextView view = makeInfoText(text, 14);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setTextColor(UI_TEXT);
        return view;
    }

    private LinearLayout.LayoutParams buttonParams(int topMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(topMarginDp);
        return lp;
    }

    private GradientDrawable roundedDrawable(int fillColor, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    // ======================== BUTTON FEEDBACK - START ========================
    // EN: Every programmatic button gets an immediate visual pressed state.
    // HE: כל כפתור שנוצר בקוד מקבל חיווי חזותי מיידי בזמן הלחיצה.
    private StateListDrawable pressStateDrawable(int normalFill, int pressedFill,
                                                 int normalStroke, int pressedStroke,
                                                 int radiusDp) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed},
                roundedDrawable(pressedFill, radiusDp, pressedStroke, 1));
        states.addState(new int[]{android.R.attr.state_focused},
                roundedDrawable(pressedFill, radiusDp, pressedStroke, 1));
        states.addState(new int[]{-android.R.attr.state_enabled},
                roundedDrawable(UI_CARD, radiusDp, UI_BORDER, 1));
        states.addState(new int[]{},
                roundedDrawable(normalFill, radiusDp, normalStroke, 1));
        return states;
    }
    // ========================= BUTTON FEEDBACK - END =========================

    private void updateFilterUi() {
        if (artistFilterContainer == null || genreFilterContainer == null) return;
        if (filterModeSpinner != null && filterModeSpinner.getSelectedItemPosition() != selectedFilterMode) {
            filterOptionsUpdating = true;
            filterModeSpinner.setSelection(selectedFilterMode, false);
            filterOptionsUpdating = false;
        }
        artistFilterContainer.setVisibility(
                selectedFilterMode == FILTER_ARTIST ? View.VISIBLE : View.GONE);
        genreFilterContainer.setVisibility(
                selectedFilterMode == FILTER_GENRE ? View.VISIBLE : View.GONE);
        updateMultiSelectButtonLabels();
        updateFilterCount();
    }

    // ================= MULTI-SELECT FILTERS - START =================
    // EN: Artist and Genre are multi-select controls. The persisted value uses a JSON array
    // while still accepting the old single-string value from 3.2.0 and earlier.
    // HE: בחירת אמן ו-Genre היא מרובה. הערך נשמר כמערך JSON, אך הקוד עדיין קורא
    // ערך יחיד מגרסאות קודמות כדי לא לאבד את בחירת המשתמש לאחר עדכון.
    private void refreshFilterOptions() {
        invalidateFilterCountCache();
        if (artistFilterButton == null || genreFilterButton == null) return;
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        List<String> wantedArtists = decodeFilterSelection(p.getString(PREF_FILTER_ARTIST, ""));
        List<String> wantedGenres = decodeFilterSelection(p.getString(PREF_FILTER_GENRE, ""));

        Map<String, String> artistLabelsByKey = new HashMap<>();
        Map<String, String> genreLabelsByKey = new HashMap<>();
        for (Song song : analyzedSongs) {
            song.refreshScheduleKeys();
            String artistKey = song.artistKey();
            String artistLabel = filterArtistDisplay(song);
            if (!artistKey.isEmpty() && artistLabel != null) {
                String old = artistLabelsByKey.get(artistKey);
                if (old == null || artistLabel.length() < old.length()) artistLabelsByKey.put(artistKey, artistLabel);
            }
            if (isFilterableGenre(song.genre)) {
                String genreKey = song.genreKey();
                if (!genreKey.isEmpty() && !genreLabelsByKey.containsKey(genreKey)) genreLabelsByKey.put(genreKey, song.genre);
            }
        }

        artistFilterOptions.clear();
        artistFilterOptions.addAll(artistLabelsByKey.values());
        genreFilterOptions.clear();
        genreFilterOptions.addAll(genreLabelsByKey.values());
        artistFilterOptions.sort(String.CASE_INSENSITIVE_ORDER);
        genreFilterOptions.sort(String.CASE_INSENSITIVE_ORDER);

        // Before analysis there are no options yet. Keep persisted selections intact so they
        // can be restored once a snapshot is available.
        selectedArtistFilters.clear();
        selectedGenreFilters.clear();
        if (artistFilterOptions.isEmpty()) selectedArtistFilters.addAll(wantedArtists);
        else selectedArtistFilters.addAll(canonicalizeFilterSelection(wantedArtists, artistFilterOptions, true));
        if (genreFilterOptions.isEmpty()) selectedGenreFilters.addAll(wantedGenres);
        else selectedGenreFilters.addAll(canonicalizeFilterSelection(wantedGenres, genreFilterOptions, false));

        updateMultiSelectButtonLabels();
        updateFilterCount();
    }

    private void showMultiSelectFilterDialog(boolean artist) {
        final List<String> options = artist ? artistFilterOptions : genreFilterOptions;
        final List<String> current = artist ? selectedArtistFilters : selectedGenreFilters;
        if (analyzedSongs.isEmpty()) {
            Toast.makeText(this, tr("יש לבצע ניתוח ספרייה תחילה.", "Analyze the library first."), Toast.LENGTH_SHORT).show();
            return;
        }
        if (options.isEmpty()) {
            Toast.makeText(this, artist ? tr("לא נמצאו אמנים לבחירה.", "No artists are available.")
                    : tr("לא נמצאו Genres אמינים לבחירה.", "No reliable genres are available."), Toast.LENGTH_SHORT).show();
            return;
        }

        CharSequence[] labels = options.toArray(new CharSequence[0]);
        boolean[] checked = new boolean[options.size()];
        for (int i = 0; i < options.size(); i++) checked[i] = containsIgnoreCase(current, options.get(i));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(artist ? tr("בחר אמנים", "Choose artists") : tr("בחר Genres", "Choose genres"))
                .setMultiChoiceItems(labels, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setNegativeButton(tr("ביטול", "Cancel"), null)
                .setNeutralButton(tr("נקה בחירה", "Clear"), (d, which) -> {
                    current.clear();
                    invalidateFilterCountCache();
                    saveSettings();
                    updateMultiSelectButtonLabels();
                    updateFilterCount();
                })
                .setPositiveButton(tr("אישור", "Done"), (d, which) -> {
                    current.clear();
                    for (int i = 0; i < options.size(); i++) if (checked[i]) current.add(options.get(i));
                    invalidateFilterCountCache();
                    saveSettings();
                    updateMultiSelectButtonLabels();
                    updateFilterCount();
                })
                .create();
        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(UI_ACCENT);
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(UI_ACCENT);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(UI_MUTED);
        });
        dialog.show();
    }

    private void updateMultiSelectButtonLabels() {
        if (artistFilterButton != null) {
            artistFilterButton.setText(multiSelectButtonText(true, selectedArtistFilters, artistFilterOptions));
            artistFilterButton.setEnabled(!analyzedSongs.isEmpty() && !artistFilterOptions.isEmpty());
        }
        if (genreFilterButton != null) {
            genreFilterButton.setText(multiSelectButtonText(false, selectedGenreFilters, genreFilterOptions));
            genreFilterButton.setEnabled(!analyzedSongs.isEmpty() && !genreFilterOptions.isEmpty());
        }
    }

    private String multiSelectButtonText(boolean artist, List<String> selected, List<String> options) {
        if (analyzedSongs.isEmpty()) return tr("יש לבצע ניתוח תחילה", "Analyze the library first");
        if (options.isEmpty()) return artist ? tr("לא נמצאו אמנים", "No artists found") : tr("לא נמצאו Genres", "No genres found");
        if (selected.isEmpty()) return artist ? tr("בחר אמנים", "Choose artists") : tr("בחר Genres", "Choose genres");
        if (selected.size() == 1) return "✓ " + selected.get(0);
        if (selected.size() == 2) return "✓ " + selected.get(0) + ", " + selected.get(1);
        return "✓ " + selected.size() + (artist ? tr(" אמנים נבחרו", " artists selected") : tr(" Genres נבחרו", " genres selected"));
    }

    private static boolean containsIgnoreCase(List<String> values, String wanted) {
        if (wanted == null) return false;
        for (String value : values) if (wanted.equalsIgnoreCase(value)) return true;
        return false;
    }

    private static List<String> canonicalizeFilterSelection(List<String> wanted, List<String> options, boolean artist) {
        List<String> result = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (String old : wanted) {
            String oldKey = artist ? normalizeArtistKey(old, "") : normalizeGroup(old);
            if (oldKey.isEmpty() || seen.contains(oldKey)) continue;
            for (String option : options) {
                String optionKey = artist ? normalizeArtistKey(option, "") : normalizeGroup(option);
                if (oldKey.equals(optionKey)) {
                    result.add(option);
                    seen.add(oldKey);
                    break;
                }
            }
        }
        return result;
    }

    private static String encodeFilterSelection(List<String> values) {
        JSONArray array = new JSONArray();
        if (values != null) for (String value : values) if (value != null && !value.trim().isEmpty()) array.put(value);
        return array.toString();
    }

    private static List<String> decodeFilterSelection(String stored) {
        List<String> result = new ArrayList<>();
        String value = stored == null ? "" : stored.trim();
        if (value.isEmpty()) return result;
        if (value.startsWith("[")) {
            try {
                JSONArray array = new JSONArray(value);
                for (int i = 0; i < array.length(); i++) {
                    String item = trimToNull(array.optString(i, ""));
                    if (item != null && !containsIgnoreCase(result, item)) result.add(item);
                }
                return result;
            } catch (Exception ignored) {
                // Fall through to legacy single-value parsing.
            }
        }
        result.add(value);
        return result;
    }

    private static Set<String> selectedFilterKeys(String stored, boolean artist) {
        Set<String> keys = new LinkedHashSet<>();
        for (String value : decodeFilterSelection(stored)) {
            String key = artist ? normalizeArtistKey(value, "") : normalizeGroup(value);
            if (!key.isEmpty()) keys.add(key);
        }
        return keys;
    }

    private static String readableFilterSelection(String stored, Context context, boolean artist) {
        List<String> values = decodeFilterSelection(stored);
        if (values.isEmpty()) return artist
                ? tr(context, "לא נבחרו אמנים", "No artists selected")
                : tr(context, "לא נבחרו Genres", "No genres selected");
        return String.join(", ", values);
    }

    private static String filterArtistDisplay(Song song) {
        String identity = trimToNull(song.artistIdentity());
        String titlePrefix = titleArtistPrefix(song.displayTitle());
        if (titlePrefix != null && normalizeArtistKey(titlePrefix, "").equals(song.artistKey())) return titlePrefix;
        return identity;
    }

    private static boolean isFilterableGenre(String genre) {
        String key = normalizeGroup(genre);
        if (key.isEmpty()) return false;
        return !key.equals("unknown") && !key.equals("music") && !key.equals("people blogs")
                && !key.equals("people & blogs");
    }

    private String selectedArtistFilter() {
        return encodeFilterSelection(selectedArtistFilters);
    }

    private String selectedGenreFilter() {
        return encodeFilterSelection(selectedGenreFilters);
    }
    // ================== MULTI-SELECT FILTERS - END ==================

    private void invalidateFilterCountCache() {
        cachedFilterCount = -1;
        cachedFilterMode = -1;
        cachedFilterSourceSize = -1;
        cachedFilterArtist = null;
        cachedFilterGenre = null;
    }

    private int filteredSongCount() {
        String artist = selectedArtistFilter();
        String genre = selectedGenreFilter();
        if (cachedFilterCount >= 0
                && cachedFilterMode == selectedFilterMode
                && cachedFilterSourceSize == analyzedSongs.size()
                && safeEquals(cachedFilterArtist, artist)
                && safeEquals(cachedFilterGenre, genre)) {
            return cachedFilterCount;
        }
        int count = countFilteredSongs(analyzedSongs, selectedFilterMode, artist, genre);
        cachedFilterCount = count;
        cachedFilterMode = selectedFilterMode;
        cachedFilterSourceSize = analyzedSongs.size();
        cachedFilterArtist = artist;
        cachedFilterGenre = genre;
        return count;
    }

    private static boolean safeEquals(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    private static int countFilteredSongs(List<Song> source, int filterMode,
                                          String artistFilter, String genreFilter) {
        if (source == null || source.isEmpty()) return 0;
        int mode = clampInt(filterMode, FILTER_ALL, FILTER_ARTIST_GENRE);
        if (mode == FILTER_ALL) return source.size();
        Set<String> wantedArtists = selectedFilterKeys(artistFilter, true);
        Set<String> wantedGenres = selectedFilterKeys(genreFilter, false);
        int count = 0;
        for (Song song : source) {
            boolean artistOk = mode != FILTER_ARTIST && mode != FILTER_ARTIST_GENRE
                    || (!wantedArtists.isEmpty() && wantedArtists.contains(song.artistKey()));
            boolean genreOk = mode != FILTER_GENRE && mode != FILTER_ARTIST_GENRE
                    || (!wantedGenres.isEmpty() && wantedGenres.contains(song.genreKey()));
            if (artistOk && genreOk) count++;
        }
        return count;
    }

    private boolean canCreatePlaylist() {
        boolean sortReady = selectedSortStrategy == SORT_SMART || !directSortCriteria.isEmpty();
        return treeUri != null && analyzedSongs.size() >= 2 && filteredSongCount() >= 2 && sortReady;
    }

    private void updateFilterCount() {
        if (filterCountText == null) return;
        if (analyzedSongs.isEmpty()) {
            filterCountText.setText(tr("לא נותחה עדיין ספרייה.", "Library has not been analyzed yet."));
        } else {
            int count = filteredSongCount();
            filterCountText.setText(tr("תוצאת הסינון: ", "Filter result: ") + count
                    + tr(" שירים מתוך ", " songs out of ") + analyzedSongs.size());
        }
        if (createButton != null) {
            BackgroundWorkService.State state = BackgroundWorkService.getState(getApplicationContext());
            createButton.setEnabled(!state.busy && canCreatePlaylist());
        }
    }

    // ======================== FILTER PIPELINE - START ========================
    // EN: Returns a new list containing only songs selected by the user. Data path:
    // FILTER -> selected ordering engine (Smart Sort or Direct Sort). Artist matching supports
    // one or more normalized scheduling keys; Genre uses reliable stored metadata only.
    // HE: מחזיר רשימה חדשה המכילה רק את השירים שנבחרו. נתיב הנתונים הוא:
    // סינון -> מנוע הסידור שנבחר (Smart Sort או Direct Sort). אמן ו-Genre תומכים
    // בבחירה מרובה, ו-Genre אינו מנוחש מהאודיו.
    static List<Song> filterSongsForPlaylist(List<Song> source, int filterMode,
                                             String artistFilter, String genreFilter) {
        List<Song> result = new ArrayList<>();
        if (source == null) return result;
        int mode = clampInt(filterMode, FILTER_ALL, FILTER_ARTIST_GENRE);
        Set<String> wantedArtists = selectedFilterKeys(artistFilter, true);
        Set<String> wantedGenres = selectedFilterKeys(genreFilter, false);
        for (Song song : source) {
            song.refreshScheduleKeys();
            boolean artistOk = mode != FILTER_ARTIST && mode != FILTER_ARTIST_GENRE
                    || (!wantedArtists.isEmpty() && wantedArtists.contains(song.artistKey()));
            boolean genreOk = mode != FILTER_GENRE && mode != FILTER_ARTIST_GENRE
                    || (!wantedGenres.isEmpty() && wantedGenres.contains(song.genreKey()));
            if (artistOk && genreOk) result.add(song);
        }
        return result;
    }

    static String filterDescription(Context context, int filterMode, String artistFilter, String genreFilter) {
        int mode = clampInt(filterMode, FILTER_ALL, FILTER_ARTIST_GENRE);
        if (mode == FILTER_ARTIST) {
            return tr(context, "אמנים: ", "Artists: ") + readableFilterSelection(artistFilter, context, true);
        } else if (mode == FILTER_GENRE) {
            return "Genres: " + readableFilterSelection(genreFilter, context, false);
        } else if (mode == FILTER_ARTIST_GENRE) {
            return tr(context, "אמנים: ", "Artists: ") + readableFilterSelection(artistFilter, context, true)
                    + " | Genres: " + readableFilterSelection(genreFilter, context, false);
        }
        return tr(context, "כל השירים", "All songs");
    }
    // ========================= FILTER PIPELINE - END =========================

    // ======================== DIRECT SORT GUI - START ========================
    static final class DirectSortCriterion {
        String field;
        boolean descending;

        DirectSortCriterion(String field, boolean descending) {
            this.field = isValidDirectField(field) ? field : DIRECT_FIELD_TITLE;
            this.descending = descending;
        }
    }

    private void updateSortStrategyUi() {
        if (sortStrategySpinner != null && sortStrategySpinner.getSelectedItemPosition() != selectedSortStrategy) {
            directSortUiUpdating = true;
            sortStrategySpinner.setSelection(selectedSortStrategy, false);
            directSortUiUpdating = false;
        }
        ensureDirectFieldOrder();
        if (selectedSortStrategy == SORT_DIRECT) ensureAtLeastOneDirectCriterion();
        if (smartFlowContainer != null) {
            smartFlowContainer.setVisibility(selectedSortStrategy == SORT_SMART ? View.VISIBLE : View.GONE);
        }
        if (directSortContainer != null) {
            directSortContainer.setVisibility(selectedSortStrategy == SORT_DIRECT ? View.VISIBLE : View.GONE);
        }
        rebuildDirectCriteriaUi();
        if (createButton != null) {
            BackgroundWorkService.State state = BackgroundWorkService.getState(getApplicationContext());
            createButton.setEnabled(!state.busy && canCreatePlaylist());
        }
    }

    private void ensureDirectFieldOrder() {
        LinkedHashSet<String> cleaned = new LinkedHashSet<>();
        for (String field : directFieldOrder) if (isValidDirectField(field)) cleaned.add(field);
        for (DirectSortCriterion criterion : directSortCriteria) {
            if (criterion != null && isValidDirectField(criterion.field)) cleaned.add(criterion.field);
        }
        for (String field : DIRECT_FIELDS) cleaned.add(field);
        directFieldOrder.clear();
        directFieldOrder.addAll(cleaned);
    }

    private DirectSortCriterion findDirectCriterion(String field) {
        for (DirectSortCriterion criterion : directSortCriteria) {
            if (criterion != null && field.equals(criterion.field)) return criterion;
        }
        return null;
    }

    private void rebuildDirectCriteriaUi() {
        if (directCriteriaContainer == null) return;
        ensureDirectFieldOrder();
        syncDirectCriteriaToFieldOrder();
        directSortUiUpdating = true;
        directCriteriaContainer.removeAllViews();

        for (int i = 0; i < directFieldOrder.size(); i++) {
            final String field = directFieldOrder.get(i);
            final DirectSortCriterion criterion = findDirectCriterion(field);
            final boolean checked = criterion != null;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(9), dp(7), dp(8), dp(7));
            row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            row.setBackground(roundedDrawable(checked ? UI_ACCENT_SOFT : UI_SURFACE,
                    14, checked ? UI_ACCENT : UI_BORDER, 1));

            CheckBox select = new CheckBox(this);
            select.setText(directFieldLabel(this, field));
            select.setTextSize(14);
            select.setTextColor(checked ? UI_TEXT : UI_MUTED);
            select.setGravity(Gravity.CENTER_VERTICAL);
            select.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
            if (Build.VERSION.SDK_INT >= 21) select.setButtonTintList(ColorStateList.valueOf(UI_ACCENT));
            select.setChecked(checked);
            select.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (directSortUiUpdating) return;
                setDirectFieldChecked(field, isChecked);
            });
            row.addView(select, new LinearLayout.LayoutParams(0, -2, 1f));

            Button direction = makeButton(directDirectionLabel(field, checked && criterion.descending));
            direction.setTextSize(11);
            direction.setMinHeight(dp(40));
            direction.setMinWidth(0);
            direction.setEnabled(checked);
            direction.setAlpha(checked ? 1f : 0.35f);
            direction.setContentDescription(tr("שנה כיוון מיון", "Change sort direction"));
            direction.setOnClickListener(v -> {
                DirectSortCriterion active = findDirectCriterion(field);
                if (active == null) return;
                active.descending = !active.descending;
                rebuildDirectCriteriaUi();
                saveSettings();
            });
            LinearLayout.LayoutParams directionLp = new LinearLayout.LayoutParams(dp(112), dp(42));
            directionLp.setMarginStart(dp(6));
            row.addView(direction, directionLp);

            TextView dragHandle = makeInfoText("≡", 24);
            dragHandle.setGravity(Gravity.CENTER);
            dragHandle.setTextColor(UI_MUTED);
            dragHandle.setContentDescription(tr("לחיצה ארוכה וגרירה אנכית לשינוי עדיפות", "Long-press and drag vertically to change priority"));
            dragHandle.setPadding(dp(10), 0, dp(6), 0);
            dragHandle.setOnTouchListener((v, event) -> handleDirectVerticalDragTouch(field, row, event));
            LinearLayout.LayoutParams handleLp = new LinearLayout.LayoutParams(dp(46), dp(46));
            handleLp.setMarginStart(dp(4));
            row.addView(dragHandle, handleLp);

            directCriteriaContainer.addView(row, buttonParams(i == 0 ? 2 : 6));
        }
        directSortUiUpdating = false;
    }

    private String directDirectionLabel(String field, boolean descending) {
        if (DIRECT_FIELD_YEAR.equals(field)) {
            return descending ? tr("חדש→ישן", "New→Old") : tr("ישן→חדש", "Old→New");
        }
        return descending ? "Z→A" : "A→Z";
    }

    private void ensureAtLeastOneDirectCriterion() {
        if (!directSortCriteria.isEmpty()) return;
        String fallback = directFieldOrder.contains(DIRECT_FIELD_TITLE)
                ? DIRECT_FIELD_TITLE
                : (directFieldOrder.isEmpty() ? DIRECT_FIELD_TITLE : directFieldOrder.get(0));
        directSortCriteria.add(new DirectSortCriterion(fallback, false));
        syncDirectCriteriaToFieldOrder();
    }

    private void setDirectFieldChecked(String field, boolean checked) {
        DirectSortCriterion existing = findDirectCriterion(field);
        if (checked && existing == null) {
            directSortCriteria.add(new DirectSortCriterion(field, false));
        } else if (!checked && existing != null) {
            if (directSortCriteria.size() <= 1) {
                Toast.makeText(this, tr("Direct Sort חייב לכלול לפחות שדה אחד.",
                        "Direct Sort must keep at least one field selected."), Toast.LENGTH_SHORT).show();
                rebuildDirectCriteriaUi();
                return;
            }
            directSortCriteria.remove(existing);
        }
        syncDirectCriteriaToFieldOrder();
        ensureAtLeastOneDirectCriterion();
        rebuildDirectCriteriaUi();
        saveSettings();
        if (createButton != null) {
            BackgroundWorkService.State state = BackgroundWorkService.getState(getApplicationContext());
            createButton.setEnabled(!state.busy && canCreatePlaylist());
        }
    }

    private void syncDirectCriteriaToFieldOrder() {
        Map<String, DirectSortCriterion> byField = new LinkedHashMap<>();
        for (DirectSortCriterion criterion : directSortCriteria) {
            if (criterion != null && isValidDirectField(criterion.field)) byField.put(criterion.field, criterion);
        }
        directSortCriteria.clear();
        for (String field : directFieldOrder) {
            DirectSortCriterion criterion = byField.get(field);
            if (criterion != null) directSortCriteria.add(criterion);
        }
    }

    /**
     * 3.3.2 vertical-only priority drag. Android's startDragAndDrop() lets the drag shadow
     * wander horizontally across the screen. Here the actual row stays in its list column and
     * only translationY follows the finger. Reordering is committed on release.
     */
    private boolean handleDirectVerticalDragTouch(String field, View row, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                cancelDirectVerticalDragArm();
                directVerticalDragField = field;
                directVerticalDragRow = row;
                directVerticalDragDownRawY = event.getRawY();
                directVerticalDragActive = false;
                directVerticalDragArm = () -> {
                    if (row == directVerticalDragRow && field.equals(directVerticalDragField)) {
                        directVerticalDragActive = true;
                        if (row.getParent() != null) row.getParent().requestDisallowInterceptTouchEvent(true);
                        row.setElevation(dp(10));
                        row.setAlpha(0.94f);
                        row.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    }
                };
                main.postDelayed(directVerticalDragArm, ViewConfiguration.getLongPressTimeout());
                return true;

            case MotionEvent.ACTION_MOVE:
                if (!field.equals(directVerticalDragField) || row != directVerticalDragRow) return true;
                if (!directVerticalDragActive
                        && Math.abs(event.getRawY() - directVerticalDragDownRawY)
                        > ViewConfiguration.get(this).getScaledTouchSlop()) {
                    cancelDirectVerticalDragArm();
                }
                if (directVerticalDragActive) {
                    float wanted = event.getRawY() - directVerticalDragDownRawY;
                    float min = -row.getTop();
                    float max = directCriteriaContainer == null ? wanted
                            : directCriteriaContainer.getHeight() - row.getBottom();
                    row.setTranslationY(Math.max(min, Math.min(max, wanted)));
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                cancelDirectVerticalDragArm();
                if (field.equals(directVerticalDragField) && row == directVerticalDragRow) {
                    if (directVerticalDragActive && event.getActionMasked() == MotionEvent.ACTION_UP) {
                        int targetIndex = directVerticalDropIndex(row);
                        row.setTranslationY(0f);
                        row.setElevation(0f);
                        row.setAlpha(1f);
                        moveDirectFieldToIndex(field, targetIndex);
                    } else {
                        row.setTranslationY(0f);
                        row.setElevation(0f);
                        row.setAlpha(1f);
                    }
                }
                if (row.getParent() != null) row.getParent().requestDisallowInterceptTouchEvent(false);
                directVerticalDragField = null;
                directVerticalDragRow = null;
                directVerticalDragActive = false;
                return true;

            default:
                return true;
        }
    }

    private void cancelDirectVerticalDragArm() {
        if (directVerticalDragArm != null) {
            main.removeCallbacks(directVerticalDragArm);
            directVerticalDragArm = null;
        }
    }

    private int directVerticalDropIndex(View draggedRow) {
        if (directCriteriaContainer == null || draggedRow == null) return 0;
        float center = draggedRow.getTop() + draggedRow.getTranslationY() + draggedRow.getHeight() / 2f;
        int index = 0;
        for (int i = 0; i < directCriteriaContainer.getChildCount(); i++) {
            View child = directCriteriaContainer.getChildAt(i);
            if (child == draggedRow) continue;
            float midpoint = child.getTop() + child.getHeight() / 2f;
            if (center > midpoint) index++;
        }
        return clampInt(index, 0, Math.max(0, directFieldOrder.size() - 1));
    }

    private void moveDirectFieldToIndex(String field, int targetIndex) {
        ensureDirectFieldOrder();
        int from = directFieldOrder.indexOf(field);
        if (from < 0) return;
        targetIndex = clampInt(targetIndex, 0, Math.max(0, directFieldOrder.size() - 1));
        if (from == targetIndex) {
            rebuildDirectCriteriaUi();
            return;
        }
        directFieldOrder.remove(from);
        targetIndex = clampInt(targetIndex, 0, directFieldOrder.size());
        directFieldOrder.add(targetIndex, field);
        syncDirectCriteriaToFieldOrder();
        ensureAtLeastOneDirectCriterion();
        rebuildDirectCriteriaUi();
        saveSettings();
    }

    private static String encodeDirectFieldOrder(List<String> order) {
        JSONArray array = new JSONArray();
        Set<String> seen = new LinkedHashSet<>();
        if (order != null) {
            for (String field : order) {
                if (isValidDirectField(field) && seen.add(field)) array.put(field);
            }
        }
        for (String field : DIRECT_FIELDS) if (seen.add(field)) array.put(field);
        return array.toString();
    }

    private static List<String> decodeDirectFieldOrder(String stored) {
        List<String> result = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        try {
            JSONArray array = new JSONArray(stored == null ? "" : stored);
            for (int i = 0; i < array.length(); i++) {
                String field = array.optString(i, "");
                if (isValidDirectField(field) && seen.add(field)) result.add(field);
            }
        } catch (Exception ignored) {}
        for (String field : DIRECT_FIELDS) if (seen.add(field)) result.add(field);
        return result;
    }

    private List<String> directFieldLabels() {
        List<String> out = new ArrayList<>();
        for (String field : DIRECT_FIELDS) out.add(directFieldLabel(this, field));
        return out;
    }

    private static String directFieldLabel(Context context, String field) {
        if (DIRECT_FIELD_ARTIST.equals(field)) return tr(context, "אמן", "Artist");
        if (DIRECT_FIELD_GENRE.equals(field)) return "Genre";
        if (DIRECT_FIELD_YEAR.equals(field)) return tr(context, "שנה", "Year");
        if (DIRECT_FIELD_ALBUM.equals(field)) return tr(context, "אלבום", "Album");
        return tr(context, "כותרת", "Title");
    }

    private static String directFieldAt(int position) {
        return DIRECT_FIELDS.get(clampInt(position, 0, DIRECT_FIELDS.size() - 1));
    }

    private static int directFieldPosition(String field) {
        int position = DIRECT_FIELDS.indexOf(field);
        return position < 0 ? DIRECT_FIELDS.indexOf(DIRECT_FIELD_TITLE) : position;
    }

    private static boolean isValidDirectField(String field) {
        return field != null && DIRECT_FIELDS.contains(field);
    }

    static String encodeDirectSortCriteria(List<DirectSortCriterion> criteria) {
        JSONArray array = new JSONArray();
        if (criteria != null) {
            Set<String> seen = new LinkedHashSet<>();
            for (DirectSortCriterion criterion : criteria) {
                if (criterion == null || !isValidDirectField(criterion.field) || !seen.add(criterion.field)) continue;
                try {
                    JSONObject o = new JSONObject();
                    o.put("field", criterion.field);
                    o.put("descending", criterion.descending);
                    array.put(o);
                } catch (Exception ignored) {}
            }
        }
        return array.toString();
    }

    static List<DirectSortCriterion> decodeDirectSortCriteria(String stored) {
        List<DirectSortCriterion> result = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        String value = stored == null ? "" : stored.trim();
        if (value.isEmpty()) return result;
        try {
            JSONArray array = new JSONArray(value);
            for (int i = 0; i < array.length() && result.size() < DIRECT_FIELDS.size(); i++) {
                JSONObject o = array.optJSONObject(i);
                if (o == null) continue;
                String field = o.optString("field", "");
                if (!isValidDirectField(field) || !seen.add(field)) continue;
                result.add(new DirectSortCriterion(field, o.optBoolean("descending", false)));
            }
        } catch (Exception ignored) {}
        return result;
    }

    static boolean directSortUsesYear(String storedCriteria) {
        for (DirectSortCriterion c : decodeDirectSortCriteria(storedCriteria)) {
            if (DIRECT_FIELD_YEAR.equals(c.field)) return true;
        }
        return false;
    }

    static String directSortDescription(Context context, String storedCriteria) {
        List<DirectSortCriterion> criteria = decodeDirectSortCriteria(storedCriteria);
        if (criteria.isEmpty()) return tr(context, "לא נבחרו פרמטרים", "No fields selected");
        StringBuilder out = new StringBuilder();
        for (DirectSortCriterion criterion : criteria) {
            if (out.length() > 0) out.append(" → ");
            out.append(directFieldLabel(context, criterion.field));
            if (DIRECT_FIELD_YEAR.equals(criterion.field)) {
                out.append(criterion.descending ? tr(context, " חדש→ישן", " newest→oldest")
                        : tr(context, " ישן→חדש", " oldest→newest"));
            } else {
                out.append(criterion.descending ? " Z→A" : " A→Z");
            }
        }
        return out.toString();
    }
    // ========================= DIRECT SORT GUI - END =========================

    private void updateFlowHelp() {
        if (flowHelpText == null || modeSpinner == null) return;
        int mode = modeSpinner.getSelectedItemPosition();
        if (mode == 1) {
            flowHelpText.setText(tr("מתחיל רגוע והופך בהדרגה לקצבי יותר.", "Starts calm and gradually becomes more energetic."));
        } else if (mode == 2) {
            flowHelpText.setText(tr("מתחיל קצבי והופך בהדרגה לרגוע יותר.", "Starts energetic and gradually becomes calmer."));
        } else {
            flowHelpText.setText(tr("משלב שירים רגועים וקצביים לאורך הרשימה.", "Mixes calm and energetic songs across the playlist."));
        }
    }

    private void restoreSettings() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        modeSpinner.setSelection(clampInt(p.getInt(PREF_MODE, 0), 0, 2));
        playlistNameEdit.setText(p.getString(PREF_PLAYLIST_NAME, DEFAULT_PLAYLIST_NAME));
        analysisReportCheckBox.setChecked(p.getBoolean(PREF_ANALYSIS_REPORT, true));
        int savedFilterMode = p.getInt(PREF_FILTER_MODE, FILTER_ALL);
        // 3.2.1+ keeps the Artist+Genre UI option removed. If an older installation had that
        // mode selected, migrate it safely to All songs rather than showing a hidden state.
        selectedFilterMode = (savedFilterMode >= FILTER_ALL && savedFilterMode <= FILTER_GENRE)
                ? savedFilterMode : FILTER_ALL;

        selectedSortStrategy = clampInt(p.getInt(PREF_SORT_STRATEGY, SORT_SMART), SORT_SMART, SORT_DIRECT);
        directSortCriteria.clear();
        directSortCriteria.addAll(decodeDirectSortCriteria(p.getString(PREF_DIRECT_SORT_CRITERIA, "")));
        // 3.3.2: Direct Sort is never allowed to have zero criteria. Existing installs that
        // saved an empty 3.3.1 selection are migrated to Title A→Z automatically.
        if (directSortCriteria.isEmpty()) {
            directSortCriteria.add(new DirectSortCriterion(DIRECT_FIELD_TITLE, false));
        }
        directFieldOrder.clear();
        String storedFieldOrder = p.getString(PREF_DIRECT_FIELD_ORDER, "");
        if (storedFieldOrder == null || storedFieldOrder.trim().isEmpty()) {
            // Migration from 3.3.0: preserve the old selected-priority order, then append unused rows.
            for (DirectSortCriterion criterion : directSortCriteria) directFieldOrder.add(criterion.field);
            for (String field : DIRECT_FIELDS) if (!directFieldOrder.contains(field)) directFieldOrder.add(field);
        } else {
            directFieldOrder.addAll(decodeDirectFieldOrder(storedFieldOrder));
        }
        ensureDirectFieldOrder();
        syncDirectCriteriaToFieldOrder();

        invalidateFilterCountCache();
        if (filterModeSpinner != null) {
            filterOptionsUpdating = true;
            filterModeSpinner.setSelection(selectedFilterMode, false);
            filterOptionsUpdating = false;
        }
        if (sortStrategySpinner != null) {
            directSortUiUpdating = true;
            sortStrategySpinner.setSelection(selectedSortStrategy, false);
            directSortUiUpdating = false;
        }
        updateFilterUi();
        updateSortStrategyUi();
        settingsInitialized = true;
    }

    private void saveSettings() {
        if (!settingsInitialized || modeSpinner == null || playlistNameEdit == null) return;
        SharedPreferences.Editor editor = getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt(PREF_MODE, modeSpinner.getSelectedItemPosition())
                .putString(PREF_PLAYLIST_NAME, playlistNameEdit.getText().toString())
                .putInt(PREF_FILTER_MODE, selectedFilterMode)
                .putInt(PREF_SORT_STRATEGY, selectedSortStrategy)
                .putString(PREF_DIRECT_SORT_CRITERIA, encodeDirectSortCriteria(directSortCriteria))
                .putString(PREF_DIRECT_FIELD_ORDER, encodeDirectFieldOrder(directFieldOrder));
        if (artistFilterButton != null) editor.putString(PREF_FILTER_ARTIST, selectedArtistFilter());
        if (genreFilterButton != null) editor.putString(PREF_FILTER_GENRE, selectedGenreFilter());
        if (analysisReportCheckBox != null) {
            editor.putBoolean(PREF_ANALYSIS_REPORT, analysisReportCheckBox.isChecked());
        }
        editor.apply();
    }

    // ================= MULTI-LIBRARY SOURCE SELECTION 3.4.5 - START =================
    // Android SAF chooses one directory per picker invocation. Playlist Maker therefore keeps
    // a persistent list of granted roots and presents that list as a multi-choice dialog with
    // check marks. Adding a root immediately asks whether that specific root should recurse into
    // all subdirectories. Re-selecting a previously unchecked root asks again, so the user can
    // change that choice without losing the stored SAF permission.
    private void restoreFolder() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        librarySelections.clear();

        String encoded = prefs.getString(PREF_LIBRARY_SELECTIONS, null);
        if (encoded != null) {
            librarySelections.addAll(decodeLibrarySelections(encoded));
        } else {
            // Seamless migration from 3.4.4 and earlier: the old scanner was always recursive.
            String saved = prefs.getString(PREF_TREE_URI, null);
            if (saved != null && !saved.trim().isEmpty()) {
                librarySelections.add(new LibrarySelection(Uri.parse(saved), true, true));
            }
        }

        boolean pruned = false;
        for (int i = librarySelections.size() - 1; i >= 0; i--) {
            LibrarySelection selection = librarySelections.get(i);
            if (selection.uri == null || !hasPersistedReadPermission(selection.uri)) {
                librarySelections.remove(i);
                pruned = true;
            }
        }
        if (pruned || encoded == null) saveLibrarySelections();
        updateLibrarySelectionUi(false);
    }

    private boolean hasPersistedReadPermission(Uri candidate) {
        if (candidate == null) return false;
        for (UriPermission permission : getContentResolver().getPersistedUriPermissions()) {
            if (permission.getUri().equals(candidate) && permission.isReadPermission()) return true;
        }
        return false;
    }

    private List<LibrarySelection> activeLibrarySelections() {
        List<LibrarySelection> active = new ArrayList<>();
        for (LibrarySelection selection : librarySelections) {
            if (selection != null && selection.selected && selection.uri != null) {
                active.add(new LibrarySelection(selection.uri, true, selection.includeSubdirectories));
            }
        }
        return active;
    }

    private void saveLibrarySelections() {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(PREF_LIBRARY_SELECTIONS, encodeLibrarySelections(librarySelections));
        Uri primary = null;
        for (LibrarySelection selection : librarySelections) {
            if (selection != null && selection.selected && selection.uri != null) {
                primary = selection.uri;
                break;
            }
        }
        if (primary != null) editor.putString(PREF_TREE_URI, primary.toString());
        else editor.remove(PREF_TREE_URI);
        editor.apply();
    }

    private void updatePrimaryTreeUri() {
        treeUri = null;
        for (LibrarySelection selection : librarySelections) {
            if (selection != null && selection.selected && selection.uri != null) {
                treeUri = selection.uri;
                break;
            }
        }
    }

    private void updateLibrarySelectionUi(boolean invalidateAnalysis) {
        updatePrimaryTreeUri();
        saveLibrarySelections();
        updateLibrarySummaryText();
        updateOutputFolderText();
        if (analyzeButton != null) {
            BackgroundWorkService.State state = BackgroundWorkService.getState(getApplicationContext());
            analyzeButton.setEnabled(!state.busy && treeUri != null);
        }

        if (!invalidateAnalysis) return;
        analyzedSongs.clear();
        BackgroundWorkService.clearAnalysisSnapshot(getApplicationContext());
        lastAppliedAnalysisRevision = -1;
        invalidateFilterCountCache();
        if (createButton != null) createButton.setEnabled(false);
        setCorrectionsEnabled(false);
        if (statusText != null) statusText.setText(treeUri == null
                ? tr("לא נבחרו ספריות לסריקה.", "No libraries are selected for scanning.")
                : tr("מוכן לסריקה של הספריות שנבחרו.", "Ready to scan the selected libraries."));
        if (resultText != null) resultText.setText("");
        refreshFilterOptions();
        updateCorrectionsSummary();
    }

    private void updateLibrarySummaryText() {
        if (folderText == null) return;
        List<LibrarySelection> active = activeLibrarySelections();
        if (active.isEmpty()) {
            folderText.setText(tr("לא נבחרו ספריות", "No libraries selected"));
            return;
        }
        StringBuilder summary = new StringBuilder();
        summary.append(tr("ספריות נבחרות: ", "Selected libraries: ")).append(active.size());
        for (LibrarySelection selection : active) {
            summary.append("\n✓ ").append(friendlyLibraryName(selection.uri)).append(" — ")
                    .append(selection.includeSubdirectories
                            ? tr("כולל תתי-ספריות", "includes subfolders")
                            : tr("ספרייה זו בלבד", "this folder only"));
        }
        folderText.setText(summary.toString());
    }

    private void chooseFolder() {
        showLibrarySelectionDialog();
    }

    private void showLibrarySelectionDialog() {
        if (librarySelections.isEmpty()) {
            launchLibraryFolderPicker();
            return;
        }
        final String[] labels = new String[librarySelections.size()];
        final boolean[] checked = new boolean[librarySelections.size()];
        for (int i = 0; i < librarySelections.size(); i++) {
            LibrarySelection selection = librarySelections.get(i);
            labels[i] = friendlyLibraryName(selection.uri) + "\n" + (selection.includeSubdirectories
                    ? tr("כולל תתי-ספריות", "Includes subfolders")
                    : tr("ספרייה זו בלבד", "This folder only"));
            checked[i] = selection.selected;
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(tr("בחר ספריות לסריקה", "Choose libraries to scan"))
                .setMultiChoiceItems(labels, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton(tr("אישור", "OK"), (d, w) -> applyLibraryChecks(checked))
                .setNeutralButton(tr("הוסף ספרייה", "Add library"), (d, w) -> launchLibraryFolderPicker())
                .setNegativeButton(tr("ביטול", "Cancel"), null)
                .create();
        dialog.setOnShowListener(d -> {
            ListView list = dialog.getListView();
            if (list != null) list.setDividerHeight(1);
        });
        dialog.show();
    }

    private void applyLibraryChecks(boolean[] checked) {
        if (checked == null || checked.length != librarySelections.size()) return;
        List<LibrarySelection> newlySelected = new ArrayList<>();
        boolean changed = false;
        for (int i = 0; i < checked.length; i++) {
            LibrarySelection selection = librarySelections.get(i);
            boolean newValue = checked[i];
            if (selection.selected != newValue) {
                if (newValue) newlySelected.add(selection);
                selection.selected = newValue;
                changed = true;
            }
        }
        if (!changed) return;
        if (newlySelected.isEmpty()) {
            updateLibrarySelectionUi(true);
        } else {
            askSubdirectoriesSequentially(newlySelected, 0, () -> updateLibrarySelectionUi(true));
        }
    }

    private void launchLibraryFolderPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, PICK_TREE);
    }

    private void askSubdirectoriesSequentially(List<LibrarySelection> selections, int index, Runnable finished) {
        if (selections == null || index >= selections.size()) {
            if (finished != null) finished.run();
            return;
        }
        LibrarySelection selection = selections.get(index);
        String name = friendlyLibraryName(selection.uri);
        new AlertDialog.Builder(this)
                .setTitle(tr("תתי-ספריות", "Subfolders"))
                .setMessage(tr("לסרוק גם את כל תתי-הספריות של \"", "Also scan all subfolders of \"")
                        + name + "\"?")
                .setPositiveButton(tr("כן, כולל הכול", "Yes, include all"), (d, w) -> {
                    selection.includeSubdirectories = true;
                    askSubdirectoriesSequentially(selections, index + 1, finished);
                })
                .setNegativeButton(tr("לא, ספרייה זו בלבד", "No, this folder only"), (d, w) -> {
                    selection.includeSubdirectories = false;
                    askSubdirectoriesSequentially(selections, index + 1, finished);
                })
                .setCancelable(false)
                .show();
    }

    static String encodeLibrarySelections(List<LibrarySelection> selections) {
        JSONArray array = new JSONArray();
        if (selections != null) {
            for (LibrarySelection selection : selections) {
                if (selection == null || selection.uri == null) continue;
                try {
                    JSONObject o = new JSONObject();
                    o.put("uri", selection.uri.toString());
                    o.put("selected", selection.selected);
                    o.put("recursive", selection.includeSubdirectories);
                    array.put(o);
                } catch (Exception ignored) {}
            }
        }
        return array.toString();
    }

    static List<LibrarySelection> decodeLibrarySelections(String encoded) {
        List<LibrarySelection> result = new ArrayList<>();
        if (encoded == null || encoded.trim().isEmpty()) return result;
        try {
            JSONArray array = new JSONArray(encoded);
            Set<String> seen = new LinkedHashSet<>();
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.optJSONObject(i);
                if (o == null) continue;
                String uriText = o.optString("uri", "").trim();
                if (uriText.isEmpty() || !seen.add(uriText)) continue;
                result.add(new LibrarySelection(Uri.parse(uriText),
                        o.optBoolean("selected", true), o.optBoolean("recursive", true)));
            }
        } catch (Exception ignored) {}
        return result;
    }
    // ================== MULTI-LIBRARY SOURCE SELECTION 3.4.5 - END ==================

    // ================= PLAYLIST OUTPUT LOCATION - START =================
    // EN: A dedicated SAF tree may be persisted for playlist/report output. With multiple music
    // roots, the first checked library remains the backward-compatible default when no separate
    // output destination is selected.
    // HE: ניתן לשמור URI קבוע נפרד לפלט. כאשר נבחרות כמה ספריות מוזיקה ואין יעד נפרד,
    // הספרייה המסומנת הראשונה משמשת כברירת המחדל לצורך תאימות לאחור.
    private void restoreOutputFolder() {
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_OUTPUT_TREE_URI, null);
        outputTreeUri = null;
        if (saved != null) {
            Uri candidate = Uri.parse(saved);
            for (UriPermission permission : getContentResolver().getPersistedUriPermissions()) {
                if (permission.getUri().equals(candidate) && permission.isWritePermission()) {
                    outputTreeUri = candidate;
                    break;
                }
            }
            if (outputTreeUri == null) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(PREF_OUTPUT_TREE_URI).apply();
            }
        }
        updateOutputFolderText();
    }

    private Uri currentOutputTree() {
        return outputTreeUri != null ? outputTreeUri : treeUri;
    }

    private void updateOutputFolderText() {
        if (outputFolderText == null) return;
        if (outputTreeUri != null) {
            outputFolderText.setText(tr("שמירה קבועה: ", "Fixed save folder: ") + friendlyTreeName(outputTreeUri));
        } else if (treeUri != null) {
            outputFolderText.setText(tr("ברירת מחדל: הספרייה המסומנת הראשונה — ",
                    "Default: first selected library — ") + friendlyTreeName(treeUri));
        } else {
            outputFolderText.setText(tr("ברירת מחדל: הספרייה המסומנת הראשונה (בחר תחילה ספריית מוזיקה)",
                    "Default: first selected library (choose a music library first)"));
        }
    }

    private void chooseOutputFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, PICK_OUTPUT_TREE);
    }

    private void useMusicFolderForOutput() {
        outputTreeUri = null;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(PREF_OUTPUT_TREE_URI).apply();
        updateOutputFolderText();
        Toast.makeText(this, tr("הפלייליסטים יישמרו בספריית המוזיקה המסומנת הראשונה.",
                "Playlists will be saved in the first selected music library."), Toast.LENGTH_SHORT).show();
    }
    // ================== PLAYLIST OUTPUT LOCATION - END ==================

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        if (requestCode != PICK_TREE && requestCode != PICK_OUTPUT_TREE) return;

        Uri chosen = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(chosen, flags); } catch (SecurityException ignored) {}

        if (requestCode == PICK_OUTPUT_TREE) {
            outputTreeUri = chosen;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(PREF_OUTPUT_TREE_URI, chosen.toString()).apply();
            updateOutputFolderText();
            Toast.makeText(this, tr("תיקיית שמירת הפלייליסט עודכנה.",
                    "Playlist save folder updated."), Toast.LENGTH_SHORT).show();
            return;
        }

        LibrarySelection selected = null;
        for (LibrarySelection existing : librarySelections) {
            if (existing.uri != null && existing.uri.equals(chosen)) {
                selected = existing;
                break;
            }
        }
        if (selected == null) {
            selected = new LibrarySelection(chosen, true, true);
            librarySelections.add(selected);
        } else {
            selected.selected = true;
        }
        final LibrarySelection chosenSelection = selected;
        askSubdirectoriesSequentially(Collections.singletonList(chosenSelection), 0, () -> {
            updateLibrarySelectionUi(true);
            main.post(this::showLibrarySelectionDialog);
        });
    }

    static String friendlyLibraryName(Uri uri) {
        try {
            String id = DocumentsContract.getTreeDocumentId(uri);
            int colon = id.indexOf(':');
            if (colon < 0) return id;
            String volume = id.substring(0, colon);
            String path = id.substring(colon + 1);
            String shownPath = path.isEmpty() ? "/" : path;
            return shownPath + " [" + volume + "]";
        } catch (Exception e) {
            return friendlyTreeName(uri);
        }
    }

    static String friendlyTreeName(Uri uri) {
        try {
            String id = DocumentsContract.getTreeDocumentId(uri);
            int colon = id.indexOf(':');
            String path = colon >= 0 ? id.substring(colon + 1) : id;
            return path.isEmpty() ? id : path;
        } catch (Exception e) {
            return uri.toString();
        }
    }

    private void analyzeLibrary() {
        List<LibrarySelection> libraries = activeLibrarySelections();
        if (libraries.isEmpty()) return;
        BackgroundWorkService.State state = BackgroundWorkService.getState(getApplicationContext());
        if (state.busy) return;
        saveSettings();
        resultText.setText("");
        analyzedSongs.clear();
        refreshFilterOptions();
        updateCorrectionsSummary();
        createButton.setEnabled(false);
        setCorrectionsEnabled(false);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2002);
        }
        setBusy(true);
        BackgroundWorkService.startAnalysis(getApplicationContext(), libraries);
        syncUiFromSharedState();
    }

    private void createPlaylistFromAnalysis() {
        if (treeUri == null || analyzedSongs.size() < 2) return;
        BackgroundWorkService.State state = BackgroundWorkService.getState(getApplicationContext());
        if (state.busy) return;
        final String artistFilter = selectedArtistFilter();
        final String genreFilter = selectedGenreFilter();
        List<Song> preview = filterSongsForPlaylist(analyzedSongs, selectedFilterMode, artistFilter, genreFilter);
        if (preview.size() < 2) {
            Toast.makeText(this, tr("הסינון הנוכחי מכיל פחות משני שירים.",
                    "The current filter contains fewer than two songs."), Toast.LENGTH_LONG).show();
            return;
        }
        saveSettings();
        final int mode = modeSpinner.getSelectedItemPosition();
        final int sortStrategy = selectedSortStrategy;
        final String directSortSpec = encodeDirectSortCriteria(directSortCriteria);
        if (sortStrategy == SORT_DIRECT && decodeDirectSortCriteria(directSortSpec).isEmpty()) {
            Toast.makeText(this, tr("יש לבחור לפחות פרמטר מיון אחד.",
                    "Choose at least one Direct Sort field."), Toast.LENGTH_LONG).show();
            return;
        }
        final String playlistName = normalizedPlaylistName(playlistNameEdit.getText().toString());
        playlistNameEdit.setText(playlistName);
        // Keep the FULL analyzed snapshot. The background service persists the filter and
        // sort strategy separately, then applies them immediately before playlist creation.
        BackgroundWorkService.setAnalysisSnapshot(getApplicationContext(), new ArrayList<>(analyzedSongs), lastSkipped, lastCacheHits);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2002);
        }
        setBusy(true);
        boolean reportEnabled = analysisReportCheckBox != null && analysisReportCheckBox.isChecked();
        Uri outputTree = currentOutputTree();
        if (outputTree == null) {
            Toast.makeText(this, tr("יש לבחור לפחות ספריית מוזיקה אחת או תיקיית שמירה.",
                    "Choose at least one music library or a playlist save folder."), Toast.LENGTH_LONG).show();
            setBusy(false);
            return;
        }
        BackgroundWorkService.startPlaylist(getApplicationContext(), treeUri, outputTree, mode, playlistName, reportEnabled,
                selectedFilterMode, artistFilter, genreFilter, sortStrategy, directSortSpec);
        syncUiFromSharedState();
    }

    private void setBusy(boolean busy) {
        sharedBusy = busy;
        setBusyUiLocked(busy);
        analyzeButton.setEnabled(!busy && treeUri != null);
        createButton.setEnabled(!busy && canCreatePlaylist());
        setCorrectionsEnabled(!busy && !analyzedSongs.isEmpty());
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
        if (!busy) progressBar.setProgress(0);
    }

    /**
     * 3.4.4 UI interaction lock.
     *
     * Long-running analysis, playlist creation and metadata lookup all belong to
     * BackgroundWorkService. While its persisted state is busy, every main-screen input control
     * is disabled so a second action cannot be started and settings cannot be changed underneath
     * the running task. The visible progress/status views keep updating normally. When the task
     * ends, each control returns to its previous enabled state; the caller's normal UI refresh
     * then applies any new post-task availability (for example newly discovered Artist/Genre
     * filter choices after an analysis).
     */
    private void setBusyUiLocked(boolean locked) {
        if (busyUiRoot == null) return;
        if (locked) {
            if (busyUiLocked) return;
            busyUiLocked = true;
            busyEnabledSnapshot.clear();
            snapshotAndDisableInteractiveViews(busyUiRoot);
        } else {
            if (!busyUiLocked) return;
            for (Map.Entry<View, Boolean> entry : busyEnabledSnapshot.entrySet()) {
                View view = entry.getKey();
                if (view != null) view.setEnabled(Boolean.TRUE.equals(entry.getValue()));
            }
            busyEnabledSnapshot.clear();
            busyUiLocked = false;
        }
    }

    private void snapshotAndDisableInteractiveViews(View view) {
        if (view == null || view == progressBar || view == correctionsProgressBar) return;
        boolean interactive = view instanceof Button
                || view instanceof Spinner
                || view instanceof EditText
                || view instanceof CheckBox
                // Direct Sort's ≡ drag handle is a TextView with an accessibility description
                // and a touch listener rather than a Button. Disabling that described TextView
                // blocks the gesture without changing Direct Sort's drag/sort implementation.
                || (view instanceof TextView && view.getContentDescription() != null);
        if (interactive) {
            busyEnabledSnapshot.put(view, view.isEnabled());
            view.setEnabled(false);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                snapshotAndDisableInteractiveViews(group.getChildAt(i));
            }
        }
    }

    interface ProgressCallback {
        void onProgress(String text, int percent);
    }

    static final class AnalysisResult {
        final List<Song> songs;
        final int skipped;
        final int cacheHits;
        AnalysisResult(List<Song> songs, int skipped, int cacheHits) {
            this.songs = songs;
            this.skipped = skipped;
            this.cacheHits = cacheHits;
        }
    }

    static final class PlaylistResult {
        final List<Song> playlist;
        final Uri playlistUri;
        final String playlistName;
        final String reportName;
        final String savedAt;
        final String warning;
        final boolean mediaScannerRequested;
        PlaylistResult(List<Song> playlist, Uri playlistUri, String playlistName, String reportName,
                       String savedAt, String warning, boolean mediaScannerRequested) {
            this.playlist = playlist;
            this.playlistUri = playlistUri;
            this.playlistName = playlistName;
            this.reportName = reportName;
            this.savedAt = savedAt;
            this.warning = warning;
            this.mediaScannerRequested = mediaScannerRequested;
        }
    }

    // ======================= LIBRARY ANALYSIS - START =======================
    // EN: Recursively scans the selected tree, reuses unchanged cached tracks, reads metadata,
    //     analyzes audio features for missing/changed files, then normalizes energy scores.
    // HE: סריקה רקורסיבית, שימוש במטמון לשירים שלא השתנו, קריאת metadata, ניתוח אודיו
    //     לקבצים חדשים/שהשתנו ולבסוף נרמול ציוני האופי.
    static AnalysisResult performAnalysis(Context context, Uri selected, ProgressCallback callback) throws Exception {
        return performAnalysis(context, Collections.singletonList(new LibrarySelection(selected, true, true)), callback);
    }

    static AnalysisResult performAnalysis(Context context, List<LibrarySelection> selections,
                                          ProgressCallback callback) throws Exception {
        List<LibrarySelection> active = new ArrayList<>();
        if (selections != null) {
            for (LibrarySelection selection : selections) {
                if (selection != null && selection.selected && selection.uri != null) active.add(selection);
            }
        }
        if (active.isEmpty()) {
            throw new IllegalStateException(tr(context, "לא נבחרו ספריות מוזיקה לסריקה.",
                    "No music libraries are selected for scanning."));
        }

        List<Song> songs = new ArrayList<>();
        Set<String> seenDocuments = new LinkedHashSet<>();
        for (int i = 0; i < active.size(); i++) {
            LibrarySelection selection = active.get(i);
            callback.onProgress(tr(context, "סורק ספרייה ", "Scanning library ") + (i + 1) + "/" + active.size()
                    + ": " + friendlyLibraryName(selection.uri), 1);
            String rootId = DocumentsContract.getTreeDocumentId(selection.uri);
            scanDirectory(context, selection.uri, rootId, "", songs,
                    selection.includeSubdirectories, seenDocuments);
        }
        if (songs.size() < 2) throw new IllegalStateException(tr(context,
                "נדרשים לפחות שני קובצי מוזיקה בספריות שנבחרו.",
                "At least two music files are required in the selected libraries."));

        final int total = songs.size();
        callback.onProgress(tr(context, "נמצאו ", "Found ") + total + tr(context, " שירים. קורא תגיות ומנתח את אופי השירים…", " songs. Reading tags and analyzing song character…"), 2);
        int analyzed = 0;
        int cacheHits = 0;
        for (Song song : songs) {
            try {
                if (loadCachedAnalysis(context, song)) {
                    cacheHits++;
                    // Old 3.2.1 caches have no year field. Read only that metadata once,
                    // preserving the expensive audio-analysis cache.
                    boolean cacheEnriched = false;
                    if (!song.yearMetadataLoaded) {
                        readYearMetadata(context, song);
                        cacheEnriched = true;
                    }
                    if (!song.embeddedMetadataPresenceLoaded) {
                        readEmbeddedMetadataPresence(context, song);
                        cacheEnriched = true;
                    }
                    if (cacheEnriched) saveCachedAnalysis(context, song);
                } else {
                    readMetadata(context, song);
                    AudioFeatures f = analyzeAudio(context, song.uri);
                    song.rmsDb = f.rmsDb;
                    song.bpm = f.bpm;
                    song.activity = f.activity;
                    song.analyzed = true;
                    saveCachedAnalysis(context, song);
                }
                applyManualOverride(context, song);
            } catch (Exception e) {
                song.analyzed = false;
            }
            analyzed++;
            int progress = 2 + (int) (93.0 * analyzed / Math.max(1, total));
            callback.onProgress(tr(context, "מנתח ", "Analyzing ") + analyzed + "/" + total + ": " + song.name + tr(context, "  |  מטמון: ", "  |  cache: ") + cacheHits, progress);
        }

        List<Song> usable = new ArrayList<>();
        for (Song song : songs) if (song.analyzed) usable.add(song);
        if (usable.size() < 2) {
            throw new IllegalStateException(tr(context, "לא הצלחתי לנתח מספיק קובצי אודיו. נסה תיקייה עם MP3/FLAC/M4A רגילים.", "Not enough audio files could be analyzed. Try a folder with standard MP3/FLAC/M4A files."));
        }
        callback.onProgress(tr(context, "מסכם את אופי השירים…", "Finalizing song character scores…"), 97);
        scoreEnergy(usable);
        return new AnalysisResult(usable, songs.size() - usable.size(), cacheHits);
    }
    // ======================== LIBRARY ANALYSIS - END ========================

    // ======================= PLAYLIST CREATION - START =======================
    // EN: Copies the analyzed songs, runs either the unchanged Smart Sort scheduler or the
    //     strict Direct Sort comparator, writes M3U8 to the selected output tree, optionally
    //     writes the diagnostic report, then requests a generic Android media refresh.
    // HE: מעתיק את השירים שנותחו, מפעיל Smart Sort הקיים או Direct Sort קשיח, כותב
    //     M3U8 לתיקיית הפלט, לפי בחירה גם דוח, ואז מבקש רענון מדיה כללי מ-Android.
    static PlaylistResult performPlaylist(Context context, Uri outputTree, List<Song> source, int sortStrategy, int mode,
                                          String directSortSpec, String requestedPlaylistName, boolean reportEnabled,
                                          String filterDescription, ProgressCallback callback) throws Exception {
        if (source == null || source.size() < 2) {
            throw new IllegalStateException(tr(context, "אין ניתוח שמור שממנו ניתן ליצור פלייליסט.", "No saved analysis is available for playlist creation."));
        }
        final int strategy = clampInt(sortStrategy, SORT_SMART, SORT_DIRECT);
        final double threshold = BALANCED_ENERGY_THRESHOLD;
        final String playlistName = normalizedPlaylistName(requestedPlaylistName);
        final String reportName = reportEnabled ? analysisReportName(playlistName) : "";
        List<Song> copy = new ArrayList<>(source);
        for (Song song : copy) song.refreshScheduleKeys();

        final List<Song> playlist;
        if (strategy == SORT_DIRECT) {
            callback.onProgress(tr(context, "ממיין לפי Direct Sort…", "Applying Direct Sort…"), 3);
            playlist = sortDirect(context, copy, directSortSpec);
            callback.onProgress(tr(context, "המיון הישיר הושלם.", "Direct Sort completed."), 94);
        } else {
            callback.onProgress(tr(context, "מכין נתוני פיזור…", "Preparing distribution data…"), 1);
            playlist = scheduleSmart(context, copy, mode, threshold, callback);
        }

        callback.onProgress(tr(context, "כותב ", "Writing ") + playlistName + "…", 96);
        Uri playlistUri = writePlaylist(context, outputTree, playlist, playlistName);

        String warning = null;
        if (reportEnabled) {
            callback.onProgress(tr(context, "יוצר קובץ בדיקה ", "Creating diagnostic file ") + reportName + "…", 98);
            try {
                writeAnalysisReport(context, outputTree, playlist, playlistName, strategy, mode, directSortSpec, threshold, filterDescription);
            } catch (Exception e) {
                warning = tr(context, "הפלייליסט נוצר, אבל קובץ הבדיקה לא נוצר: ", "The playlist was created, but the diagnostic file could not be created: ") + safeMessage(e);
            }
        } else {
            callback.onProgress(tr(context, "מסיים את יצירת הפלייליסט…", "Finishing playlist creation…"), 98);
        }
        callback.onProgress(tr(context, "מבקש רענון מספריית המדיה של Android…", "Requesting Android media-library refresh…"), 99);
        boolean mediaScannerRequested = requestAndroidMediaRefresh(context, playlistUri);
        String savedAt = friendlyTreeName(outputTree) + "/" + playlistName;
        return new PlaylistResult(playlist, playlistUri, playlistName, reportName, savedAt, warning, mediaScannerRequested);
    }

    static void scanDirectory(Context context, Uri tree, String parentDocumentId, String relativeDir,
                              List<Song> out) throws Exception {
        scanDirectory(context, tree, parentDocumentId, relativeDir, out, true, new LinkedHashSet<>());
    }

    static void scanDirectory(Context context, Uri tree, String parentDocumentId, String relativeDir,
                              List<Song> out, boolean includeSubdirectories,
                              Set<String> seenDocuments) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentDocumentId);
        String[] projection = {
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED
        };
        try (Cursor cursor = resolver.query(children, projection, null, null, null)) {
            if (cursor == null) return;
            int idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            int mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE);
            int sizeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
            int modifiedCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);
            while (cursor.moveToNext()) {
                String id = cursor.getString(idCol);
                String name = cursor.getString(nameCol);
                String mime = cursor.getString(mimeCol);
                long size = sizeCol >= 0 && !cursor.isNull(sizeCol) ? cursor.getLong(sizeCol) : 0L;
                long modified = modifiedCol >= 0 && !cursor.isNull(modifiedCol) ? cursor.getLong(modifiedCol) : 0L;
                if (name == null) name = "unknown";
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    if (includeSubdirectories) {
                        String nextRel = relativeDir.isEmpty() ? name : relativeDir + "/" + name;
                        scanDirectory(context, tree, id, nextRel, out, true, seenDocuments);
                    }
                } else if (isAudio(name, mime)) {
                    String authority = tree.getAuthority() == null ? "" : tree.getAuthority();
                    String uniqueDocument = authority + "|" + id;
                    if (seenDocuments != null && !seenDocuments.add(uniqueDocument)) continue;
                    Uri docUri = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                    String rel = relativeDir.isEmpty() ? name : relativeDir + "/" + name;
                    out.add(new Song(name, rel, id, docUri, size, modified));
                }
            }
        }
    }

    static boolean isAudio(String name, String mime) {
        if (mime != null && mime.startsWith("audio/")) return true;
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".mp3") || lower.endsWith(".flac") || lower.endsWith(".m4a")
                || lower.endsWith(".aac") || lower.endsWith(".ogg") || lower.endsWith(".opus")
                || lower.endsWith(".wav") || lower.endsWith(".wma") || lower.endsWith(".ape")
                || lower.endsWith(".alac") || lower.endsWith(".mka");
    }

    static void readMetadata(Context context, Song song) {
        song.title = null;
        song.artist = null;
        song.albumArtist = null;
        song.album = null;
        song.genre = null;
        song.year = 0;
        song.yearMetadataLoaded = true;
        song.genreSource = null;
        song.artistSource = null;
        song.clearOverrideFlags();
        song.embeddedMetadataPresenceLoaded = false;
        song.embeddedTitle = false;
        song.embeddedArtist = false;
        song.embeddedAlbumArtist = false;
        song.embeddedAlbum = false;
        song.embeddedYear = false;
        song.embeddedGenre = false;
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(context, song.uri);
            String rawTitle = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE));
            String rawArtist = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST));
            String rawAlbumArtist = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST));
            String rawAlbum = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM));
            String rawYear = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR));
            String rawGenre = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE));

            song.embeddedTitle = rawTitle != null;
            song.embeddedArtist = rawArtist != null;
            song.embeddedAlbumArtist = rawAlbumArtist != null;
            song.embeddedAlbum = rawAlbum != null;
            song.embeddedYear = parseYear(rawYear) > 0;
            song.embeddedGenre = rawGenre != null;
            song.embeddedMetadataPresenceLoaded = true;

            song.title = rawTitle;
            song.artist = rawArtist;
            song.albumArtist = rawAlbumArtist;
            song.album = rawAlbum;
            song.year = parseYear(rawYear);
            if (rawGenre != null) {
                song.genre = canonicalGenre(rawGenre);
                song.genreSource = "Embedded tag";
            }
        } catch (Exception ignored) {
        } finally {
            try { mmr.release(); } catch (Exception ignored) {}
        }

        parseFilenameFallback(song);
        if (song.genre == null) {
            String trusted = trustedGenreForArtist(song.artistIdentity());
            if (trusted != null) {
                song.genre = trusted;
                song.genreSource = "Conservative artist map";
            }
        }
    }

    // EN: 3.4.0 enriches old 3.3.2 caches with embedded-tag presence only. This is a
    // lightweight MediaMetadataRetriever pass and deliberately does not repeat audio analysis.
    // HE: גרסה 3.4.0 מעשירה cache ישן רק במידע האם תגיות אמיתיות קיימות, ללא ניתוח אודיו מחדש.
    static void readEmbeddedMetadataPresence(Context context, Song song) {
        song.embeddedMetadataPresenceLoaded = false;
        song.embeddedTitle = false;
        song.embeddedArtist = false;
        song.embeddedAlbumArtist = false;
        song.embeddedAlbum = false;
        song.embeddedYear = false;
        song.embeddedGenre = false;
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(context, song.uri);
            song.embeddedTitle = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)) != null;
            song.embeddedArtist = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)) != null;
            song.embeddedAlbumArtist = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)) != null;
            song.embeddedAlbum = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)) != null;
            song.embeddedYear = parseYear(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR)) > 0;
            song.embeddedGenre = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)) != null;
            song.embeddedMetadataPresenceLoaded = true;
        } catch (Exception ignored) {
        } finally {
            try { mmr.release(); } catch (Exception ignored) {}
        }
    }

    // ========================= YEAR METADATA - START =========================
    // EN: Year is used only by Direct Sort. Reading a missing year from an old 3.2.1 cache
    // does not re-run audio analysis; it performs only a lightweight metadata read.
    // HE: שנה משמשת רק ב-Direct Sort. אם snapshot/cache ישן אינו מכיל שנה, נקראת רק
    // תגית ה-metadata ללא ניתוח אודיו מחדש.
    static void readYearMetadata(Context context, Song song) {
        song.year = 0;
        song.yearMetadataLoaded = true;
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(context, song.uri);
            song.year = parseYear(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR));
            if (song.embeddedMetadataPresenceLoaded) song.embeddedYear = song.year > 0;
        } catch (Exception ignored) {
        } finally {
            try { mmr.release(); } catch (Exception ignored) {}
        }
    }

    static int parseYear(String raw) {
        String value = trimToNull(raw);
        if (value == null) return 0;
        for (int i = 0; i + 4 <= value.length(); i++) {
            char c0 = value.charAt(i), c1 = value.charAt(i + 1), c2 = value.charAt(i + 2), c3 = value.charAt(i + 3);
            if (!Character.isDigit(c0) || !Character.isDigit(c1) || !Character.isDigit(c2) || !Character.isDigit(c3)) continue;
            try {
                int year = Integer.parseInt(value.substring(i, i + 4));
                if (year >= 1000 && year <= 2999) return year;
            } catch (Exception ignored) {}
        }
        return 0;
    }
    // ========================== YEAR METADATA - END ==========================

    static void parseFilenameFallback(Song song) {
        String base = stripExtension(song.name);
        if (song.title == null) song.title = base;
        if (song.artist != null) return;
        String[] parts = base.split("\\s+-\\s+");
        if (parts.length == 2 && !parts[0].trim().isEmpty() && !parts[1].trim().isEmpty()) {
            song.artist = parts[0].trim();
            if (song.title == null || song.title.equals(base)) song.title = parts[1].trim();
            song.artistSource = "שם קובץ";
        } else if (parts.length >= 3 && parts[0].trim().matches("\\d{1,3}")) {
            song.artist = parts[1].trim();
            if (!parts[2].trim().isEmpty()) song.title = parts[2].trim();
            song.artistSource = "שם קובץ";
        }
    }

    static String trustedGenreForArtist(String artist) {
        String k = normalizeGroup(artist);
        switch (k) {
            case "glenn miller":
            case "glenn miller orchestra":
            case "benny goodman":
                return "Swing";
            case "miles davis":
            case "john coltrane":
            case "thelonious monk":
            case "dave brubeck":
            case "dave brubeck quartet":
                return "Jazz";
            case "ac dc":
            case "led zeppelin":
            case "deep purple":
            case "rolling stones":
                return "Rock";
            default:
                return null;
        }
    }

    static String canonicalGenre(String raw) {
        if (raw == null) return null;
        String g = raw.toLowerCase(Locale.ROOT);
        if (g.contains("swing")) return "Swing";
        if (g.contains("jazz")) return "Jazz";
        if (g.contains("rock")) return "Rock";
        if (g.contains("blues")) return "Blues";
        if (g.contains("classical") || g.contains("classic")) return "Classical";
        if (g.contains("metal")) return "Metal";
        if (g.contains("country")) return "Country";
        if (g.contains("funk")) return "Funk";
        if (g.contains("soul")) return "Soul";
        if (g.contains("disco")) return "Disco";
        if (g.contains("reggae")) return "Reggae";
        if (g.contains("electro") || g.contains("edm")) return "Electronic";
        if (g.contains("dance")) return "Dance";
        if (g.contains("folk")) return "Folk";
        if (g.contains("hip hop") || g.contains("hip-hop") || g.contains("rap")) return "Hip Hop";
        if (g.contains("pop")) return "Pop";
        String cleaned = raw.trim().replaceAll("\\s+", " ");
        return cleaned.isEmpty() ? null : cleaned;
    }

    static AudioFeatures analyzeAudio(Context context, Uri uri) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec codec = null;
        try {
            extractor.setDataSource(context, uri, null);
            int audioTrack = -1;
            MediaFormat inputFormat = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrack = i;
                    inputFormat = f;
                    break;
                }
            }
            if (audioTrack < 0 || inputFormat == null) throw new IllegalArgumentException(tr(context, "אין ערוץ אודיו", "No audio track found"));

            extractor.selectTrack(audioTrack);
            long durationUs = inputFormat.containsKey(MediaFormat.KEY_DURATION) ? inputFormat.getLong(MediaFormat.KEY_DURATION) : 0L;
            long sampleStartUs = durationUs > 45_000_000L ? Math.min(30_000_000L, durationUs / 5) : 0L;
            long sampleLengthUs = 18_000_000L;
            long sampleEndUs = durationUs > 0 ? Math.min(durationUs, sampleStartUs + sampleLengthUs) : sampleStartUs + sampleLengthUs;
            if (sampleStartUs > 0) extractor.seekTo(sampleStartUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);

            String mime = inputFormat.getString(MediaFormat.KEY_MIME);
            codec = MediaCodec.createDecoderByType(mime);
            codec.configure(inputFormat, null, null, 0);
            codec.start();

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            boolean outputDone = false;
            PcmAnalyzer analyzer = null;
            long wallDeadline = System.currentTimeMillis() + 25_000L;

            while (!outputDone && System.currentTimeMillis() < wallDeadline) {
                if (!inputDone) {
                    int inputIndex = codec.dequeueInputBuffer(10_000);
                    if (inputIndex >= 0) {
                        ByteBuffer inputBuffer = codec.getInputBuffer(inputIndex);
                        if (inputBuffer == null) continue;
                        inputBuffer.clear();
                        long sampleTime = extractor.getSampleTime();
                        if (sampleTime < 0 || sampleTime > sampleEndUs) {
                            codec.queueInputBuffer(inputIndex, 0, 0, Math.max(0, sampleTime), MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            int size = extractor.readSampleData(inputBuffer, 0);
                            if (size < 0) {
                                codec.queueInputBuffer(inputIndex, 0, 0, Math.max(0, sampleTime), MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inputDone = true;
                            } else {
                                codec.queueInputBuffer(inputIndex, 0, size, sampleTime, extractor.getSampleFlags());
                                extractor.advance();
                            }
                        }
                    }
                }

                int outIndex = codec.dequeueOutputBuffer(info, 10_000);
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    analyzer = new PcmAnalyzer(codec.getOutputFormat());
                } else if (outIndex >= 0) {
                    if (analyzer == null) analyzer = new PcmAnalyzer(codec.getOutputFormat());
                    ByteBuffer out = codec.getOutputBuffer(outIndex);
                    if (out != null && info.size > 0) {
                        out.position(info.offset);
                        out.limit(info.offset + info.size);
                        analyzer.consume(out.slice().order(ByteOrder.LITTLE_ENDIAN));
                    }
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true;
                    codec.releaseOutputBuffer(outIndex, false);
                }
            }
            if (analyzer == null || analyzer.sampleCount < 4000) throw new IllegalStateException(tr(context, "אין מספיק PCM", "Not enough PCM audio data"));
            return analyzer.finish();
        } finally {
            try { extractor.release(); } catch (Exception ignored) {}
            if (codec != null) {
                try { codec.stop(); } catch (Exception ignored) {}
                try { codec.release(); } catch (Exception ignored) {}
            }
        }
    }

    private static final class PcmAnalyzer {
        final int sampleRate;
        final int channels;
        final int encoding;
        final int windowSamples;
        final List<Double> envelope = new ArrayList<>();
        double windowSq;
        int windowCount;
        double totalSq;
        long sampleCount;

        PcmAnalyzer(MediaFormat f) {
            sampleRate = f.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? f.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
            channels = f.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? Math.max(1, f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)) : 2;
            int enc = AudioFormat.ENCODING_PCM_16BIT;
            try { if (f.containsKey("pcm-encoding")) enc = f.getInteger("pcm-encoding"); } catch (Exception ignored) {}
            encoding = enc;
            windowSamples = 1024;
        }

        void consume(ByteBuffer b) {
            if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
                while (b.remaining() >= 4 * channels) {
                    double mono = 0;
                    for (int c = 0; c < channels; c++) mono += clamp(b.getFloat());
                    add(mono / channels);
                }
            } else if (encoding == AudioFormat.ENCODING_PCM_8BIT) {
                while (b.remaining() >= channels) {
                    double mono = 0;
                    for (int c = 0; c < channels; c++) mono += ((b.get() & 0xff) - 128) / 128.0;
                    add(mono / channels);
                }
            } else {
                while (b.remaining() >= 2 * channels) {
                    double mono = 0;
                    for (int c = 0; c < channels; c++) mono += b.getShort() / 32768.0;
                    add(mono / channels);
                }
            }
        }

        private static double clamp(float v) {
            if (v > 1f) return 1;
            if (v < -1f) return -1;
            return v;
        }

        private void add(double x) {
            double sq = x * x;
            totalSq += sq;
            sampleCount++;
            windowSq += sq;
            windowCount++;
            if (windowCount >= windowSamples) {
                envelope.add(Math.sqrt(windowSq / windowCount));
                windowSq = 0;
                windowCount = 0;
            }
        }

        AudioFeatures finish() {
            if (windowCount > 0) envelope.add(Math.sqrt(windowSq / windowCount));
            double rms = Math.sqrt(totalSq / Math.max(1, sampleCount));
            double rmsDb = 20.0 * Math.log10(rms + 1e-9);
            if (envelope.size() < 8) return new AudioFeatures(rmsDb, 0, 0);

            double[] onset = new double[envelope.size() - 1];
            double onsetSum = 0;
            for (int i = 1; i < envelope.size(); i++) {
                onset[i - 1] = Math.max(0.0, envelope.get(i) - envelope.get(i - 1));
                onsetSum += onset[i - 1];
            }
            double mean = onsetSum / onset.length;
            double variance = 0;
            for (double v : onset) {
                double d = v - mean;
                variance += d * d;
            }
            double std = Math.sqrt(variance / onset.length);
            double avgEnv = 0;
            for (double v : envelope) avgEnv += v;
            avgEnv /= envelope.size();
            double activity = std / (avgEnv + 1e-7);

            double frameRate = sampleRate / (double) windowSamples;
            int bestLag = -1;
            double best = Double.NEGATIVE_INFINITY;
            int minLag = Math.max(1, (int) Math.floor(frameRate * 60.0 / 180.0));
            int maxLag = Math.min(onset.length / 2, (int) Math.ceil(frameRate * 60.0 / 65.0));
            for (int lag = minLag; lag <= maxLag; lag++) {
                double corr = 0, a2 = 0, b2 = 0;
                for (int i = lag; i < onset.length; i++) {
                    double a = onset[i] - mean;
                    double bb = onset[i - lag] - mean;
                    corr += a * bb;
                    a2 += a * a;
                    b2 += bb * bb;
                }
                double normalized = corr / (Math.sqrt(a2 * b2) + 1e-9);
                if (normalized > best) {
                    best = normalized;
                    bestLag = lag;
                }
            }
            double bpm = bestLag > 0 && best > 0.04 ? 60.0 * frameRate / bestLag : 0.0;
            if (bpm > 0 && bpm < 75) bpm *= 2.0;
            if (bpm > 180) bpm /= 2.0;
            return new AudioFeatures(rmsDb, bpm, activity);
        }
    }

    static void scoreEnergy(List<Song> songs) {
        List<Double> rmsVals = new ArrayList<>();
        List<Double> actVals = new ArrayList<>();
        List<Double> bpmVals = new ArrayList<>();
        for (Song s : songs) {
            rmsVals.add(s.rmsDb);
            actVals.add(s.activity);
            if (s.bpm > 0) bpmVals.add(s.bpm);
        }
        Collections.sort(rmsVals);
        Collections.sort(actVals);
        Collections.sort(bpmVals);
        double rmsLo = percentile(rmsVals, 0.10), rmsHi = percentile(rmsVals, 0.90);
        double actLo = percentile(actVals, 0.10), actHi = percentile(actVals, 0.90);
        double bpmLo = bpmVals.isEmpty() ? 80 : percentile(bpmVals, 0.10);
        double bpmHi = bpmVals.isEmpty() ? 150 : percentile(bpmVals, 0.90);

        for (Song s : songs) {
            double absRms = normRange(s.rmsDb, -32.0, -9.0);
            double absAct = normRange(s.activity, 0.008, 0.16);
            double absBpm = s.bpm > 0 ? normRange(s.bpm, 70.0, 170.0) : 0.42;
            double relRms = normRange(s.rmsDb, rmsLo, rmsHi);
            double relAct = normRange(s.activity, actLo, actHi);
            double relBpm = s.bpm > 0 ? normRange(s.bpm, bpmLo, bpmHi) : 0.42;
            double absolute = 0.45 * absRms + 0.35 * absAct + 0.20 * absBpm;
            double relative = 0.45 * relRms + 0.35 * relAct + 0.20 * relBpm;
            s.energy = clamp01(0.65 * absolute + 0.35 * relative);
        }
    }

    private static double percentile(List<Double> values, double p) {
        if (values.isEmpty()) return 0.0;
        if (values.size() == 1) return values.get(0);
        double idx = p * (values.size() - 1);
        int lo = (int) Math.floor(idx);
        int hi = Math.min(values.size() - 1, lo + 1);
        double frac = idx - lo;
        return values.get(lo) * (1 - frac) + values.get(hi) * frac;
    }

    private static double normRange(double v, double min, double max) {
        if (!Double.isFinite(v) || !Double.isFinite(min) || !Double.isFinite(max) || max - min < 1e-9) return 0.5;
        return clamp01((v - min) / (max - min));
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }

    // =========================== DIRECT SORT - START ===========================
    // EN: Strict lexicographic metadata sorting. Criteria are evaluated in the user-defined
    // priority order. Missing values are always placed after known values, even for descending
    // sorts. A stable relative-path tie-break guarantees deterministic output.
    // HE: מיון metadata קשיח לפי סדר העדיפויות שהמשתמש הגדיר. ערכים חסרים תמיד עוברים
    // לסוף, גם במיון יורד. relativePath משמש שובר שוויון דטרמיניסטי בלבד.
    static List<Song> sortDirect(Context context, List<Song> songs, String storedCriteria) {
        List<DirectSortCriterion> criteria = decodeDirectSortCriteria(storedCriteria);
        if (criteria.isEmpty()) criteria.add(new DirectSortCriterion(DIRECT_FIELD_TITLE, false));
        final List<DirectSortCriterion> effective = criteria;
        List<Song> out = new ArrayList<>();
        if (songs != null) out.addAll(songs);
        for (Song song : out) song.refreshScheduleKeys();

        out.sort((a, b) -> {
            for (DirectSortCriterion criterion : effective) {
                int cmp = compareDirectCriterion(a, b, criterion);
                if (cmp != 0) return cmp;
            }
            int pathCmp = safeText(a.relativePath).compareToIgnoreCase(safeText(b.relativePath));
            if (pathCmp != 0) return pathCmp;
            return safeText(a.relativePath).compareTo(safeText(b.relativePath));
        });
        return out;
    }

    private static int compareDirectCriterion(Song a, Song b, DirectSortCriterion criterion) {
        if (criterion == null) return 0;
        if (DIRECT_FIELD_YEAR.equals(criterion.field)) {
            return compareKnownYear(a.year, b.year, criterion.descending);
        }
        String av;
        String bv;
        if (DIRECT_FIELD_ARTIST.equals(criterion.field)) {
            av = trimToNull(a.artistKey());
            bv = trimToNull(b.artistKey());
        } else if (DIRECT_FIELD_GENRE.equals(criterion.field)) {
            av = trimToNull(a.genreKey());
            bv = trimToNull(b.genreKey());
        } else if (DIRECT_FIELD_ALBUM.equals(criterion.field)) {
            av = trimToNull(a.album);
            bv = trimToNull(b.album);
        } else {
            av = trimToNull(a.displayTitle());
            bv = trimToNull(b.displayTitle());
        }
        return compareKnownText(av, bv, criterion.descending);
    }

    private static int compareKnownYear(int a, int b, boolean descending) {
        boolean aKnown = a > 0;
        boolean bKnown = b > 0;
        if (!aKnown && !bKnown) return 0;
        if (!aKnown) return 1;
        if (!bKnown) return -1;
        int cmp = Integer.compare(a, b);
        return descending ? -cmp : cmp;
    }

    private static int compareKnownText(String a, String b, boolean descending) {
        String aa = trimToNull(a);
        String bb = trimToNull(b);
        if (aa == null && bb == null) return 0;
        if (aa == null) return 1;
        if (bb == null) return -1;
        int cmp = aa.compareToIgnoreCase(bb);
        if (cmp == 0) cmp = aa.compareTo(bb);
        return descending ? -cmp : cmp;
    }

    private static String safeText(String value) {
        return value == null ? "" : value;
    }

    static int ensureYearMetadata(Context context, List<Song> songs) {
        if (songs == null || songs.isEmpty()) return 0;
        int refreshed = 0;
        for (Song song : songs) {
            if (song == null || song.yearMetadataLoaded) continue;
            readYearMetadata(context, song);
            saveCachedAnalysis(context, song);
            refreshed++;
        }
        return refreshed;
    }
    // ============================ DIRECT SORT - END ============================


    // ====================== SMART SCHEDULER - START ======================
    // EN: PRIMARY CONSTRAINT = global artist/band spacing. First an artist skeleton is built
    //     across the full list. Each occurrence may move only +/-1 slot. Inside that hard
    //     window the flow target, genre, album and version influence which song is chosen.
    //     No random numbers are used; deterministic path ordering breaks ties.
    // HE: אילוץ ראשי = פיזור אמן/להקה גלובלי. תחילה נבנה שלד אמנים לכל הרשימה וכל
    //     הופעה רשאית לזוז רק +/-1. בתוך החלון משפיעים זרימה, Genre, אלבום וגרסה.
    //     אין אקראיות; שוויון מוכרע באופן דטרמיניסטי לפי הנתיב.
    static List<Song> scheduleSmart(Context context, List<Song> songs, int mode, double threshold, ProgressCallback callback) {
        List<Song> all = new ArrayList<>(songs);
        for (Song s : all) s.refreshScheduleKeys();
        all.sort(Comparator.comparing((Song s) -> s.relativePath, String.CASE_INSENSITIVE_ORDER));

        int total = all.size();
        ScheduleStats stats = new ScheduleStats(all);

        // Stage 1: create the same global artist/band skeleton that passed the 0.2.3 test.
        // Every occurrence receives an ideal target slot across the full playlist.
        Map<String, List<Song>> pools = new LinkedHashMap<>();
        for (Song s : all) {
            String key = schedulingArtistKey(s);
            if (!pools.containsKey(key)) pools.put(key, new ArrayList<>());
            pools.get(key).add(s);
        }

        Map<String, Integer> schedulingCounts = new HashMap<>();
        List<Song> singletonPool = new ArrayList<>();
        for (Map.Entry<String, List<Song>> entry : pools.entrySet()) {
            int count = entry.getValue().size();
            schedulingCounts.put(entry.getKey(), count);
            if (count == 1) singletonPool.add(entry.getValue().get(0));
        }
        singletonPool.sort(Comparator.comparing((Song s) -> s.relativePath, String.CASE_INSENSITIVE_ORDER));

        List<Map.Entry<String, List<Song>>> buckets = new ArrayList<>(pools.entrySet());
        buckets.sort((a, b) -> {
            int cmp = Integer.compare(b.getValue().size(), a.getValue().size());
            return cmp != 0 ? cmp : a.getKey().compareToIgnoreCase(b.getKey());
        });

        String[] artistPlan = new String[total];
        boolean[] occupied = new boolean[total];
        int assigned = 0;
        for (Map.Entry<String, List<Song>> bucket : buckets) {
            String key = bucket.getKey();
            int count = bucket.getValue().size();
            for (int occurrence = 0; occurrence < count; occurrence++) {
                double ideal = ((occurrence + 0.5) * total / (double) count) - 0.5;
                int slot = nearestFreeSlot(context, ideal, occupied, key, occurrence);
                occupied[slot] = true;
                artistPlan[slot] = key;
                assigned++;
            }
            final int done = assigned;
            if (callback != null) callback.onProgress(tr(context, "מפזר אמנים ולהקות: ", "Spreading artists/bands: ") + done + "/" + total + "…",
                    5 + (int) (30.0 * done / Math.max(1, total)));
        }

        // Balanced means: distribute whichever side is the minority. It does NOT try to
        // manufacture a 50/50 library. Example: 141 calm / 595 energetic -> calm is spread
        // evenly; 600 calm / 136 energetic -> energetic is spread evenly.
        int calmCount = 0;
        for (Song s : all) if (s.energy < threshold) calmCount++;
        int energeticCount = total - calmCount;
        boolean minorityIsCalm = calmCount <= energeticCount;
        int minorityCount = Math.min(calmCount, energeticCount);

        // Rising/falling flow is based on the ACTUAL energy distribution of this library,
        // not on a fixed 0.10..0.90 line. Each position gets a target taken from the
        // library's own sorted energy values. This reserves scarce energetic songs for the
        // end of Rising and scarce calm songs for the end of Falling instead of consuming
        // the minority too early and producing a U/V-shaped playlist. Artist spacing remains
        // the hard primary constraint; these targets only choose the best song inside it.
        double[] directionalFlowTargets = buildDirectionalFlowTargets(all, mode);

        // Stage 2: keep the artist skeleton primary, but allow each planned artist occurrence
        // to move at most one position around its target. This gives genre/album/flow a small
        // amount of freedom without allowing the old large artist clusters to return.
        final int artistWindow = 1;
        boolean[] tokenUsed = new boolean[total];
        ScheduleState state = new ScheduleState();
        List<Song> result = new ArrayList<>(total);
        int minorityUsed = 0;

        for (int pos = 0; pos < total; pos++) {
            List<Integer> eligibleTargets = new ArrayList<>();

            // A token that reaches the left edge of its allowed window becomes mandatory.
            // This guarantees every artist occurrence stays inside +/- artistWindow.
            int overdue = -1;
            int deadline = pos - artistWindow;
            if (deadline >= 0) {
                for (int t = 0; t <= deadline; t++) {
                    if (!tokenUsed[t]) {
                        overdue = t;
                        break;
                    }
                }
            }
            if (overdue >= 0) {
                eligibleTargets.add(overdue);
            } else {
                int from = Math.max(0, pos - artistWindow);
                int to = Math.min(total - 1, pos + artistWindow);
                for (int t = from; t <= to; t++) {
                    if (!tokenUsed[t]) eligibleTargets.add(t);
                }
            }

            if (eligibleTargets.isEmpty()) {
                throw new IllegalStateException(tr(context, "שגיאת חלון פיזור במיקום ", "Distribution window error at position ") + (pos + 1));
            }

            Placement bestPlacement = null;
            double bestScore = Double.NEGATIVE_INFINITY;
            for (int target : eligibleTargets) {
                String key = artistPlan[target];
                boolean singletonTarget = schedulingCounts.getOrDefault(key, 0) == 1;
                // Artists that occur once have no repeat-spacing constraint. Their reserved
                // singleton slots can therefore exchange songs globally, giving the flow
                // engine useful freedom without changing the spacing of any repeated artist.
                List<Song> candidates = singletonTarget ? singletonPool : pools.get(key);
                if (candidates == null || candidates.isEmpty()) continue;

                Song candidate = chooseSongInsideArtist(candidates, pos, total, mode, threshold,
                        stats, state, minorityCount, minorityUsed, minorityIsCalm,
                        directionalFlowTargets, singletonTarget);
                if (candidate == null) continue;

                double flow = flowScore(candidate, pos, total, mode, threshold,
                        minorityCount, minorityUsed, minorityIsCalm, directionalFlowTargets);
                double distribution = secondaryDistributionScore(candidate, pos, total, stats, state);
                double displacementPenalty = Math.abs(target - pos) * 0.75;
                double spacingPenalty = artistSpacingPenalty(candidate, pos, total, stats, state);

                // Artist is already a hard constraint through the +/-1 window. Inside that
                // window flow gets enough weight to hit minority targets; genre/album/version
                // still influence close choices without becoming hard constraints.
                double score = flow + distribution * 0.02 - displacementPenalty + spacingPenalty;

                if (score > bestScore + 1e-9
                        || (Math.abs(score - bestScore) < 1e-9
                        && (bestPlacement == null
                        || target < bestPlacement.target
                        || (target == bestPlacement.target
                        && candidate.relativePath.compareToIgnoreCase(bestPlacement.song.relativePath) < 0)))) {
                    bestScore = score;
                    bestPlacement = new Placement(target, candidate);
                }
            }

            if (bestPlacement == null) {
                throw new IllegalStateException(tr(context, "לא נמצא שיר מתאים במיקום ", "No suitable song found at position ") + (pos + 1));
            }

            String chosenKey = artistPlan[bestPlacement.target];
            boolean chosenSingletonTarget = schedulingCounts.getOrDefault(chosenKey, 0) == 1;
            result.add(bestPlacement.song);
            state.record(bestPlacement.song, pos);
            if (chosenSingletonTarget) {
                singletonPool.remove(bestPlacement.song);
            } else {
                List<Song> chosenPool = pools.get(chosenKey);
                if (chosenPool == null || !chosenPool.remove(bestPlacement.song)) {
                    throw new IllegalStateException(tr(context, "שגיאת מאגר אמן במיקום ", "Artist pool error at position ") + (pos + 1));
                }
            }
            tokenUsed[bestPlacement.target] = true;
            if (mode == 0 && minorityCount > 0) {
                boolean calm = bestPlacement.song.energy < threshold;
                if (calm == minorityIsCalm) minorityUsed++;
            }

            final int done = pos + 1;
            if (callback != null && (done == total || done % 20 == 0)) {
                callback.onProgress(tr(context, "מסדר את זרימת הפלייליסט: ", "Arranging playlist flow: ") + done + "/" + total + "…",
                        35 + (int) (60.0 * done / Math.max(1, total)));
            }
        }
        return result;
    }
    // ======================= SMART SCHEDULER - END =======================

    static String schedulingArtistKey(Song s) {
        String key = s.artistKey();
        if (key != null && !key.isEmpty()) return key;
        // Unknown artists must not be treated as one giant group.
        return "__single__" + sha256(s.relativePath);
    }

    static int nearestFreeSlot(Context context, double ideal, boolean[] occupied, String key, int occurrence) {
        int total = occupied.length;
        int base = clampInt((int) Math.round(ideal), 0, total - 1);
        if (!occupied[base]) return base;

        // Deterministic direction preference prevents systematic drift when two groups
        // want the same ideal slot. It is stable, not random.
        boolean preferRight = ((key.hashCode() + occurrence) & 1) == 0;
        for (int distance = 1; distance < total; distance++) {
            int first = preferRight ? base + distance : base - distance;
            int second = preferRight ? base - distance : base + distance;
            if (first >= 0 && first < total && !occupied[first]) return first;
            if (second >= 0 && second < total && !occupied[second]) return second;
        }
        throw new IllegalStateException(tr(context, "אין מקום פנוי בפיזור", "No free distribution slot is available"));
    }

    static Song chooseSongInsideArtist(List<Song> candidates, int pos, int total, int mode, double threshold,
                                        ScheduleStats stats, ScheduleState state,
                                        int minorityCount, int minorityUsed, boolean minorityIsCalm,
                                        double[] directionalFlowTargets, boolean flowFirst) {
        if (candidates.size() == 1) return candidates.get(0);

        // The shared singleton pool is the safe place to give flow real freedom: each artist
        // appears only once, so choosing a different singleton cannot damage artist spacing.
        if (flowFirst) {
            Song best = null;
            double bestScore = Double.NEGATIVE_INFINITY;
            for (Song s : candidates) {
                double flow = flowScore(s, pos, total, mode, threshold,
                        minorityCount, minorityUsed, minorityIsCalm, directionalFlowTargets);
                double distribution = secondaryDistributionScore(s, pos, total, stats, state);
                double score = flow + distribution * 0.02;
                if (score > bestScore + 1e-9
                        || (Math.abs(score - bestScore) < 1e-9
                        && (best == null || s.relativePath.compareToIgnoreCase(best.relativePath) < 0))) {
                    best = s;
                    bestScore = score;
                }
            }
            return best;
        }

        double bestDistribution = Double.NEGATIVE_INFINITY;
        Map<Song, Double> distributionScores = new HashMap<>();
        for (Song s : candidates) {
            double score = secondaryDistributionScore(s, pos, total, stats, state);
            distributionScores.put(s, score);
            if (score > bestDistribution) bestDistribution = score;
        }

        // Preserve genre/album/version priority inside an artist pool, while allowing flow
        // to decide among distribution choices that are close enough.
        final double distributionTolerance = 12.0;
        Song best = null;
        double bestFlow = Double.NEGATIVE_INFINITY;
        for (Song s : candidates) {
            double distribution = distributionScores.get(s);
            if (distribution < bestDistribution - distributionTolerance) continue;
            double flow = flowScore(s, pos, total, mode, threshold,
                    minorityCount, minorityUsed, minorityIsCalm, directionalFlowTargets);
            if (flow > bestFlow + 1e-9
                    || (Math.abs(flow - bestFlow) < 1e-9
                    && (best == null || s.relativePath.compareToIgnoreCase(best.relativePath) < 0))) {
                best = s;
                bestFlow = flow;
            }
        }
        if (best != null) return best;

        return candidates.stream()
                .max(Comparator.comparingDouble((Song s) -> distributionScores.get(s))
                        .thenComparing(s -> s.relativePath, String.CASE_INSENSITIVE_ORDER.reversed()))
                .orElse(candidates.get(0));
    }

    static double secondaryDistributionScore(Song s, int pos, int total,
                                              ScheduleStats stats, ScheduleState state) {
        double score = 0.0;
        score += groupUrgency(s.genreKey(), pos, total, stats.genreCounts, state.genreUsed, state.genreLast, 190.0, 0.62);
        score += groupUrgency(s.albumKey(), pos, total, stats.albumCounts, state.albumUsed, state.albumLast, 105.0, 0.58);
        score += groupUrgency(s.titleFamilyKey(), pos, total, stats.titleCounts, state.titleUsed, state.titleLast, 175.0, 0.75);
        return score;
    }

    static double artistSpacingPenalty(Song s, int pos, int total,
                                        ScheduleStats stats, ScheduleState state) {
        String key = s.artistKey();
        if (key == null || key.isEmpty()) return 0.0;
        Integer countObj = stats.artistCounts.get(key);
        Integer lastPos = state.artistLast.get(key);
        if (countObj == null || countObj <= 1 || lastPos == null) return 0.0;

        double idealGap = total / (double) countObj;
        double distance = pos - lastPos;
        double safeGap = Math.max(1.0, idealGap * 0.78);
        if (distance >= safeGap) return 0.0;
        return -220.0 * (safeGap - distance) / safeGap;
    }

    static double flowScore(Song s, int pos, int total, int mode, double threshold,
                             int minorityCount, int minorityUsed, boolean minorityIsCalm,
                             double[] directionalFlowTargets) {
        if (mode == 0) {
            if (minorityCount <= 0) return 0.0;

            boolean calm = s.energy < threshold;
            boolean isMinority = calm == minorityIsCalm;

            // The next minority occurrence has a moving ideal position. If an exact ideal
            // position cannot be used because of the artist skeleton, the target moves with
            // the still-unused minority songs instead of being abandoned. This is what keeps
            // the smaller group spread over the whole playlist rather than creating long runs.
            double idealNext = ((minorityUsed + 0.5) * total / (double) minorityCount) - 0.5;
            double delta = pos - idealNext;

            double classScore;
            if (isMinority) {
                // Prefer a minority song close to its next ideal occurrence; overdue minority
                // songs remain attractive so a missed target is corrected immediately after.
                classScore = 50.0 - Math.abs(delta) * 20.0;
            } else {
                // Majority songs are preferred while the next minority occurrence is still
                // comfortably in the future, then quickly lose priority once it is due.
                classScore = delta < -0.5 ? 30.0 : -Math.max(0.0, delta) * 30.0;
            }

            double targetEnergy = isMinority
                    ? (minorityIsCalm ? 0.30 : 0.70)
                    : (minorityIsCalm ? 0.70 : 0.30);
            return classScore - Math.abs(s.energy - targetEnergy) * 4.0;
        }

        // Directional modes use the library-adaptive target prepared by
        // buildDirectionalFlowTargets(). Because the target sequence contains exactly the
        // same energy distribution as the input songs, the scheduler cannot plan for more
        // calm/energetic material than actually exists. This is symmetric: it also protects
        // Rising when energetic songs are the minority.
        double target;
        if (directionalFlowTargets != null && pos >= 0 && pos < directionalFlowTargets.length) {
            target = directionalFlowTargets[pos];
        } else {
            double progress = total <= 1 ? 0.5 : pos / (double) (total - 1);
            target = mode == 1 ? 0.10 + 0.80 * progress : 0.90 - 0.80 * progress;
        }
        return -Math.abs(s.energy - target) * 42.0;
    }

    // =============== ADAPTIVE RISING/FALLING TARGETS - START ===============
    // EN: Uses the library's own sorted energy distribution rather than a fixed artificial
    //     0..1 ramp. This preserves scarce energetic/calm tracks for the part of the list
    //     where Rising/Falling needs them.
    // HE: משתמש בהתפלגות ציוני האופי האמיתית ולא ברמפה מלאכותית קבועה. כך שירים
    //     נדירים מהקבוצה הקצבית/רגועה נשמרים לחלק הנכון במתגבר/יורד.
    static double[] buildDirectionalFlowTargets(List<Song> songs, int mode) {
        if (mode != 1 && mode != 2) return null;
        List<Song> ranked = new ArrayList<>(songs);
        ranked.sort(Comparator
                .comparingDouble((Song s) -> s.energy)
                .thenComparing(s -> s.relativePath, String.CASE_INSENSITIVE_ORDER));

        int n = ranked.size();
        double[] targets = new double[n];
        for (int pos = 0; pos < n; pos++) {
            int source = mode == 1 ? pos : (n - 1 - pos);
            targets[pos] = ranked.get(source).energy;
        }
        return targets;
    }

    // ================ ADAPTIVE RISING/FALLING TARGETS - END ================

    static double groupUrgency(String key, int pos, int total, Map<String, Integer> counts,
                                Map<String, Integer> used, Map<String, Integer> last,
                                double weight, double minGapFactor) {
        if (key == null || key.isEmpty()) return 0;
        int count = counts.containsKey(key) ? counts.get(key) : 0;
        if (count <= 0) return 0;
        int u = used.containsKey(key) ? used.get(key) : 0;
        if (u >= count) return -weight * 50.0;

        double targetGap = total / (double) count;
        double idealNext = (u + 0.5) * targetGap - 0.5;
        double urgency = (pos - idealNext) / Math.max(1.0, targetGap);
        double score = urgency * weight;

        Integer lastPos = last.get(key);
        if (lastPos != null) {
            double distance = pos - lastPos;
            double minGap = Math.max(1.0, targetGap * minGapFactor);
            if (distance < minGap) {
                score -= (minGap - distance) / minGap * weight * 8.0;
            }
            if (distance <= 1.0) score -= weight * 24.0;
        }
        return score;
    }

    static Uri writePlaylist(Context context, Uri tree, List<Song> songs, String playlistName) throws Exception {
        StringBuilder m3u = new StringBuilder("#EXTM3U\n");
        for (Song s : songs) {
            m3u.append("#EXTINF:-1,").append(cleanLine(s.displayTitleWithArtist())).append('\n');
            m3u.append(cleanLine(pathForPlaylist(s))).append('\n');
        }
        return writeTextDocument(context, tree, playlistName, "audio/x-mpegurl", m3u.toString());
    }

    // ==================== ANDROID MEDIA REFRESH - START ====================
    // EN: Keep playlist discovery player-agnostic. ContentResolver observers are notified for
    // every SAF document; for standard primary/removable external storage we also ask Android's
    // MediaScanner to scan the exact M3U8 file. Third-party players may still maintain their own
    // private database and can require their own Rescan. No player-specific API is used here.
    // HE: הרענון אינו תלוי בנגן. נשלחת הודעת שינוי ל-ContentResolver, ובאחסון חיצוני
    // סטנדרטי מתבקש גם MediaScanner לסרוק את קובץ ה-M3U8. אפליקציות שמנהלות בסיס
    // נתונים פרטי עדיין עשויות לדרוש Rescan משלהן. אין כאן API ייעודי לנגן מסוים.
    static boolean requestAndroidMediaRefresh(Context context, Uri documentUri) {
        if (documentUri == null) return false;
        try {
            context.getContentResolver().notifyChange(documentUri, null);
        } catch (Exception ignored) {}

        try {
            String documentId = DocumentsContract.getDocumentId(documentUri);
            String path = absolutePathFromDocumentId(documentId);
            if (path != null && !path.trim().isEmpty()) {
                MediaScannerConnection.scanFile(context, new String[]{path}, null, null);
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }
    // ===================== ANDROID MEDIA REFRESH - END =====================

    static Uri writeAnalysisReport(Context context, Uri tree, List<Song> songs, String playlistName,
                                   int sortStrategy, int mode, String directSortSpec, double threshold,
                                   String filterDescription) throws Exception {
        if (sortStrategy == SORT_DIRECT) {
            return writeDirectAnalysisReport(context, tree, songs, playlistName, directSortSpec, filterDescription);
        }
        String reportName = analysisReportName(playlistName);
        StringBuilder out = new StringBuilder();
        out.append(tr(context, "# קובץ בדיקה אוטומטי של Playlist Maker\n", "# Automatic diagnostic file from Playlist Maker\n"));
        out.append(tr(context, "# מצב זרימה: ", "# Flow mode: ")).append(flowModeName(context, mode)).append('\n');
        if (filterDescription != null && !filterDescription.trim().isEmpty()) {
            out.append(tr(context, "# סינון: ", "# Filter: ")).append(filterDescription.trim()).append('\n');
        }
        out.append(tr(context, "# מספר שירים: ", "# Song count: ")).append(songs.size()).append('\n');
        if (mode == 0) {
            int calm = 0;
            for (Song s : songs) if (s.energy < threshold) calm++;
            int energetic = songs.size() - calm;
            boolean calmMinority = calm <= energetic;
            String minority = calmMinority ? tr(context, "רגועים", "calm") : tr(context, "קצביים", "energetic");
            out.append(tr(context, "# מאוזן: רגועים ", "# Balanced: calm ")).append(calm)
                    .append(tr(context, " | קצביים ", " | energetic ")).append(energetic)
                    .append(tr(context, " | הקבוצה המתפזרת: ", " | distributed minority: ")).append(minority).append('\n');
            double avgGap = averageClassGap(songs, threshold, calmMinority);
            double idealGap = songs.size() / (double) Math.max(1, calmMinority ? calm : energetic);
            out.append(tr(context, "# בדיקת פיזור מיעוט: יעד ~", "# Minority distribution check: target ~"))
                    .append(String.format(Locale.ROOT, "%.2f", idealGap))
                    .append(tr(context, " | מרווח ממוצע ", " | average gap "))
                    .append(String.format(Locale.ROOT, "%.2f", avgGap)).append('\n');
        } else {
            out.append(tr(context, "# בדיקת זרימה מספרית: ", "# Numeric flow check: ")).append(flowDiagnosticsText(context, songs, mode)).append('\n');
        }
        out.append(tr(context, "# הערה: ציון האופי 0-100 הוא מדד פנימי לצורך בדיקה בלבד ואינו משנה את האלגוריתם.\n", "# Note: the 0-100 character score is an internal diagnostic value and does not change the algorithm.\n"));
        out.append(tr(context, "מיקום\tאמן\tכותרת\tציון_אופי_0_100\tאופי\tBPM\tGenre\tקבוצת_פיזור\n", "Position\tArtist\tTitle\tCharacter_score_0_100\tCharacter\tBPM\tGenre\tDistribution_group\n"));
        for (int i = 0; i < songs.size(); i++) {
            Song s = songs.get(i);
            out.append(i + 1).append('\t')
                    .append(cleanField(s.artistIdentity())).append('\t')
                    .append(cleanField(s.displayTitle())).append('\t')
                    .append(Math.round(s.energy * 100.0)).append('\t')
                    .append(s.energy < threshold ? tr(context, "רגוע", "calm") : tr(context, "קצבי", "energetic")).append('\t')
                    .append(s.bpm > 0 ? Math.round(s.bpm) : 0).append('\t')
                    .append(cleanField(s.genre)).append('\t')
                    .append(cleanField(s.artistKey())).append('\n');
        }
        return writeTextDocument(context, tree, reportName, "text/plain", out.toString());
    }

    static Uri writeDirectAnalysisReport(Context context, Uri tree, List<Song> songs, String playlistName,
                                         String directSortSpec, String filterDescription) throws Exception {
        String reportName = analysisReportName(playlistName);
        StringBuilder out = new StringBuilder();
        out.append(tr(context, "# קובץ בדיקה אוטומטי של Playlist Maker\n", "# Automatic diagnostic file from Playlist Maker\n"));
        out.append("# Sort method: Direct Sort\n");
        out.append(tr(context, "# סדר עדיפות: ", "# Sort priority: ")).append(directSortDescription(context, directSortSpec)).append('\n');
        if (filterDescription != null && !filterDescription.trim().isEmpty()) {
            out.append(tr(context, "# סינון: ", "# Filter: ")).append(filterDescription.trim()).append('\n');
        }
        out.append(tr(context, "# מספר שירים: ", "# Song count: ")).append(songs.size()).append('\n');
        out.append(tr(context,
                "# הערה: Direct Sort אינו משתמש בקצב, ציון אופי או פיזור אמנים; ערכים חסרים ממוקמים אחרי ערכים ידועים.\n",
                "# Note: Direct Sort does not use tempo, character score, or artist spacing; missing values are placed after known values.\n"));
        out.append(tr(context, "מיקום\tאמן\tכותרת\tשנה\tאלבום\tGenre\n", "Position\tArtist\tTitle\tYear\tAlbum\tGenre\n"));
        for (int i = 0; i < songs.size(); i++) {
            Song song = songs.get(i);
            out.append(i + 1).append('\t')
                    .append(cleanField(song.artistIdentity())).append('\t')
                    .append(cleanField(song.displayTitle())).append('\t')
                    .append(song.year > 0 ? String.valueOf(song.year) : "").append('\t')
                    .append(cleanField(song.album)).append('\t')
                    .append(cleanField(song.genre)).append('\n');
        }
        return writeTextDocument(context, tree, reportName, "text/plain", out.toString());
    }

    static Uri writeTextDocument(Context context, Uri tree, String fileName, String mimeType, String text) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        String rootId = DocumentsContract.getTreeDocumentId(tree);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, rootId);
        Uri document = null;
        String[] projection = { DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME };
        try (Cursor c = resolver.query(children, projection, null, null, null)) {
            if (c != null) {
                int idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                while (c.moveToNext()) {
                    if (fileName.equalsIgnoreCase(c.getString(nameCol))) {
                        document = DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(idCol));
                        break;
                    }
                }
            }
        }

        if (document == null) {
            Uri rootDoc = DocumentsContract.buildDocumentUriUsingTree(tree, rootId);
            Exception first = null;
            try {
                document = DocumentsContract.createDocument(resolver, rootDoc, mimeType, fileName);
            } catch (Exception e) {
                first = e;
            }
            if (document == null) {
                try {
                    document = DocumentsContract.createDocument(resolver, rootDoc, "application/octet-stream", fileName);
                } catch (Exception e) {
                    if (first != null) e.addSuppressed(first);
                    throw e;
                }
            }
        }
        if (document == null) throw new IllegalStateException(tr(context, "לא ניתן ליצור את הקובץ ", "Could not create file ") + fileName + tr(context, " בתיקייה שנבחרה.", " in the selected folder."));

        OutputStream opened;
        try {
            opened = resolver.openOutputStream(document, "rwt");
        } catch (Exception ignored) {
            opened = resolver.openOutputStream(document, "wt");
        }
        if (opened == null) throw new IllegalStateException(tr(context, "לא ניתן לפתוח את הקובץ ", "Could not open file ") + fileName + tr(context, " לכתיבה", " for writing"));
        try (OutputStream os = opened) {
            os.write(text.getBytes(StandardCharsets.UTF_8));
            os.flush();
        }
        return document;
    }

    static String analysisReportName(String playlistName) {
        String base = playlistName;
        if (base.toLowerCase(Locale.ROOT).endsWith(".m3u8")) base = base.substring(0, base.length() - 5);
        return base + "-analysis.txt";
    }

    static String buildPlaylistResultSummary(Context context, List<Song> playlist, int sortStrategy, int mode,
                                             String directSortSpec, long durationMs) {
        if (sortStrategy == SORT_DIRECT) {
            StringBuilder direct = new StringBuilder();
            direct.append(tr(context, "תוצאות יצירת פלייליסט\n", "Playlist creation results\n"))
                    .append(tr(context, "שירים: ", "Songs: ")).append(playlist.size()).append('\n')
                    .append(tr(context, "שיטת סידור: Direct Sort\n", "Sort method: Direct Sort\n"))
                    .append(tr(context, "סדר עדיפות: ", "Priority: ")).append(directSortDescription(context, directSortSpec)).append('\n');
            if (durationMs > 0) direct.append(tr(context, "זמן עבודה: ", "Duration: "))
                    .append(formatDuration(context, durationMs)).append('\n');
            direct.append(tr(context,
                    "המיון בוצע לפי metadata בלבד; קצב, אופי ופיזור אמנים לא השתתפו בסדר.",
                    "Ordering used metadata only; tempo, character and artist spacing were not used."));
            return direct.toString().trim();
        }
        return buildSmartPlaylistResultSummary(context, playlist, mode, durationMs);
    }

    private static String buildSmartPlaylistResultSummary(Context context, List<Song> playlist, int mode, long durationMs) {
        StringBuilder sb = new StringBuilder();
        int calm = 0;
        for (Song s : playlist) if (s.energy < BALANCED_ENERGY_THRESHOLD) calm++;
        int energetic = playlist.size() - calm;
        sb.append(tr(context, "תוצאות יצירת פלייליסט\n", "Playlist creation results\n"))
                .append(tr(context, "שירים: ", "Songs: ")).append(playlist.size()).append('\n')
                .append(tr(context, "שיטת סידור: Smart Sort\n", "Sort method: Smart Sort\n"))
                .append(tr(context, "מצב זרימה: ", "Flow mode: ")).append(flowModeName(context, mode)).append('\n');
        if (durationMs > 0) sb.append(tr(context, "זמן עבודה: ", "Duration: ")).append(formatDuration(context, durationMs)).append('\n');
        sb.append(tr(context, "אופי: רגועים ", "Character: calm ")).append(calm).append(tr(context, " | קצביים ", " | energetic ")).append(energetic).append('\n');

        if (mode == 0) {
            boolean calmMinority = calm <= energetic;
            int minorityCount = calmMinority ? calm : energetic;
            double ideal = playlist.size() / (double) Math.max(1, minorityCount);
            double avg = averageClassGap(playlist, BALANCED_ENERGY_THRESHOLD, calmMinority);
            sb.append(tr(context, "פיזור הקבוצה הקטנה: ", "Minority distribution: ")).append(calmMinority ? tr(context, "רגועים", "calm") : tr(context, "קצביים", "energetic"))
                    .append(tr(context, " | יעד ~", " | target ~")).append(String.format(Locale.ROOT, "%.2f", ideal))
                    .append(tr(context, " | בפועל ", " | actual ")).append(String.format(Locale.ROOT, "%.2f", avg)).append('\n');
        } else {
            sb.append(tr(context, "בדיקת זרימה: ", "Flow check: ")).append(flowDiagnosticsText(context, playlist, mode)).append('\n');
        }
        appendTopArtistSpacingStatic(context, sb, playlist, 4);
        return sb.toString().trim();
    }

    static String formatDuration(Context context, long durationMs) {
        long totalSeconds = Math.max(0L, Math.round(durationMs / 1000.0));
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        if (minutes <= 0) return seconds + tr(context, " שניות", " seconds");
        return minutes + tr(context, " דק׳ ", " min ") + seconds + tr(context, " שנ׳", " sec");
    }

    static double averageClassGap(List<Song> songs, double threshold, boolean calmClass) {
        int previous = -1;
        int gaps = 0;
        double sum = 0.0;
        for (int i = 0; i < songs.size(); i++) {
            boolean isCalm = songs.get(i).energy < threshold;
            if (isCalm != calmClass) continue;
            if (previous >= 0) {
                sum += i - previous;
                gaps++;
            }
            previous = i;
        }
        return gaps == 0 ? 0.0 : sum / gaps;
    }

    static String flowDiagnosticsText(Context context, List<Song> songs, int mode) {
        if (songs == null || songs.isEmpty()) return tr(context, "אין נתונים", "No data");
        int n = songs.size();
        int block = Math.max(1, (int) Math.ceil(n / 5.0));
        StringBuilder segments = new StringBuilder();
        for (int part = 0; part < 5; part++) {
            int from = part * block;
            if (from >= n) break;
            int to = Math.min(n, from + block);
            if (segments.length() > 0) segments.append(" → ");
            segments.append(Math.round(averageEnergy(songs, from, to) * 100.0));
        }
        int edge = Math.max(1, n / 5);
        double first = averageEnergy(songs, 0, edge) * 100.0;
        double last = averageEnergy(songs, n - edge, n) * 100.0;
        double delta = last - first;
        double correlation = positionEnergyCorrelation(songs);
        return tr(context, "חמישיות ", "Fifths ") + segments
                + tr(context, " | התחלה ", " | start ") + Math.round(first)
                + tr(context, " | סוף ", " | end ") + Math.round(last)
                + tr(context, " | שינוי ", " | change ") + String.format(Locale.ROOT, "%+.1f", delta)
                + tr(context, " | מתאם ", " | correlation ") + String.format(Locale.ROOT, "%+.2f", correlation);
    }

    private static double averageEnergy(List<Song> songs, int from, int to) {
        if (songs == null || songs.isEmpty()) return 0.0;
        int start = Math.max(0, Math.min(from, songs.size()));
        int end = Math.max(start, Math.min(to, songs.size()));
        if (end <= start) return 0.0;
        double sum = 0.0;
        for (int i = start; i < end; i++) sum += songs.get(i).energy;
        return sum / (end - start);
    }

    private static double positionEnergyCorrelation(List<Song> songs) {
        int n = songs == null ? 0 : songs.size();
        if (n < 2) return 0.0;
        double meanX = (n - 1) / 2.0;
        double meanY = 0.0;
        for (Song s : songs) meanY += s.energy;
        meanY /= n;
        double numerator = 0.0, dx2 = 0.0, dy2 = 0.0;
        for (int i = 0; i < n; i++) {
            double dx = i - meanX;
            double dy = songs.get(i).energy - meanY;
            numerator += dx * dy;
            dx2 += dx * dx;
            dy2 += dy * dy;
        }
        if (dx2 <= 0.0 || dy2 <= 0.0) return 0.0;
        return numerator / Math.sqrt(dx2 * dy2);
    }

    private static void appendTopArtistSpacingStatic(Context context, StringBuilder sb, List<Song> playlist, int limit) {
        Map<String, List<Integer>> positions = new HashMap<>();
        Map<String, String> labels = new HashMap<>();
        for (int i = 0; i < playlist.size(); i++) {
            Song song = playlist.get(i);
            String key = song.artistKey();
            if (key.isEmpty()) continue;
            if (!positions.containsKey(key)) positions.put(key, new ArrayList<>());
            positions.get(key).add(i);
            if (!labels.containsKey(key)) labels.put(key, song.artistIdentity());
        }
        List<String> keys = new ArrayList<>(positions.keySet());
        keys.sort((a, b) -> Integer.compare(positions.get(b).size(), positions.get(a).size()));
        int shown = 0;
        sb.append(tr(context, "פיזור אמנים בולטים:\n", "Top artist spacing:\n"));
        for (String key : keys) {
            List<Integer> pos = positions.get(key);
            if (pos.size() < 2) continue;
            double sum = 0.0;
            for (int i = 1; i < pos.size(); i++) sum += pos.get(i) - pos.get(i - 1);
            double avg = sum / (pos.size() - 1);
            double ideal = playlist.size() / (double) pos.size();
            sb.append("• ").append(labels.get(key)).append(": ").append(pos.size())
                    .append(tr(context, " | יעד ~", " | target ~")).append(String.format(Locale.ROOT, "%.1f", ideal))
                    .append(tr(context, " | ממוצע ", " | average ")).append(String.format(Locale.ROOT, "%.1f", avg)).append('\n');
            shown++;
            if (shown >= limit) break;
        }
        if (shown == 0) sb.append(tr(context, "אין אמן עם יותר משיר אחד.\n", "No artist has more than one song.\n"));
    }

    static String flowModeName(Context context, int mode) {
        if (mode == 1) return tr(context, "מתגבר", "Rising");
        if (mode == 2) return tr(context, "יורד", "Falling");
        return tr(context, "מאוזן", "Balanced");
    }

    private static String cleanField(String value) {
        if (value == null) return "";
        return value.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
    }

    static String pathForPlaylist(Song s) {
        String absolute = absolutePathFromDocumentId(s.documentId);
        return absolute != null ? absolute : s.relativePath;
    }

    static String absolutePathFromDocumentId(String documentId) {
        int colon = documentId.indexOf(':');
        if (colon < 0) return null;
        String volume = documentId.substring(0, colon);
        String path = documentId.substring(colon + 1);
        if ("primary".equalsIgnoreCase(volume)) {
            return path.isEmpty() ? "/storage/emulated/0" : "/storage/emulated/0/" + path;
        }
        if (volume.matches("[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}")) {
            return path.isEmpty() ? "/storage/" + volume : "/storage/" + volume + "/" + path;
        }
        return null;
    }

    static String cleanLine(String s) {
        return s.replace('\n', ' ').replace('\r', ' ');
    }

    private void showAnalysisSummary() {
        if (analyzedSongs.isEmpty()) return;
        double threshold = BALANCED_ENERGY_THRESHOLD;
        int calm = 0, energetic = 0, genreKnown = 0, artistKnown = 0;
        Map<String, Integer> artists = new HashMap<>();
        Map<String, Integer> genres = new HashMap<>();
        for (Song s : analyzedSongs) {
            if (s.energy < threshold) calm++; else energetic++;
            if (!s.artistKey().isEmpty()) { artistKnown++; increment(artists, s.artistIdentity()); }
            if (!s.genreKey().isEmpty()) { genreKnown++; increment(genres, s.genre); }
        }

        StringBuilder sb = new StringBuilder();
        sb.append(tr("תוצאות ניתוח\n", "Analysis results\n"));
        sb.append(tr("שירים שנותחו: ", "Analyzed songs: ")).append(analyzedSongs.size()).append('\n');
        if (lastOperationDurationMs > 0) sb.append(tr("זמן עבודה: ", "Duration: ")).append(formatDuration(this, lastOperationDurationMs)).append('\n');
        if (lastSkipped > 0) sb.append(tr("קבצים שלא נותחו: ", "Files not analyzed: ")).append(lastSkipped).append('\n');
        sb.append(tr("נטענו מהמטמון: ", "Loaded from cache: ")).append(lastCacheHits).append('\n');
        sb.append(tr("אופי משוער: רגועים ", "Estimated character: calm ")).append(calm).append(tr(" | קצביים ", " | energetic ")).append(energetic).append('\n');
        sb.append(tr("אמן/להקה מזוהים: ", "Known artist/band: ")).append(artistKnown).append(tr(" | סוג מזוהה: ", " | known genre: ")).append(genreKnown).append('\n');
        sb.append(tr("סוג מסווג רק מתגית קובץ, override פנימי שאושר, או רשימת זיהוי אמן שמרנית.\n\n", "Genre is classified only from file tags, an approved internal override, or a conservative trusted-artist map.\n\n"));
        appendTopCounts(sb, tr("אמנים/להקות בולטים", "Top artists/bands"), artists, 8);
        appendTopCounts(sb, tr("סוגים", "Genres"), genres, 8);

        sb.append(tr("\nדוגמה מהניתוח:\n", "\nAnalysis sample:\n"));
        List<Song> preview = new ArrayList<>(analyzedSongs);
        preview.sort(Comparator.comparingDouble(s -> s.energy));
        int show = Math.min(20, preview.size());
        for (int i = 0; i < show; i++) {
            Song s = preview.get(i);
            sb.append("• ").append(s.displayTitleWithArtist())
                    .append(" | ").append(s.energy < threshold ? tr("רגוע", "calm") : tr("קצבי", "energetic"))
                    ;
            if (s.bpm > 0) sb.append(" | ~").append(Math.round(s.bpm)).append(" BPM");
            if (s.genre != null) sb.append(" | ").append(s.genre);
            sb.append('\n');
        }
        resultText.setText(sb.toString());
    }

    private String buildPlaylistSummary(List<Song> playlist, int skipped, Uri playlistUri, double threshold) {
        StringBuilder sb = new StringBuilder();
        sb.append(tr("נוצרו ", "Created ")).append(playlist.size()).append(tr(" שירים. קודם בוצע פיזור אמנים/להקות, אחר כך הותאמה זרימת הפלייליסט.\n", " songs. Artist/band spacing was applied first, then playlist flow was adapted.\n"));
        if (skipped > 0) sb.append(tr("דולגו ", "Skipped ")).append(skipped).append(tr(" קבצים שלא ניתן היה לנתח.\n", " files that could not be analyzed.\n"));
        sb.append(tr("\nפיזור אמן/להקה:\n", "\nArtist/band distribution:\n"));
        appendSpacingReport(sb, playlist, true, 8);
        sb.append(tr("\nפיזור סוג מוזיקלי:\n", "\nGenre distribution:\n"));
        appendSpacingReport(sb, playlist, false, 8);
        sb.append(tr("\nלאחר השמירה האפליקציה מבקשת רענון מדיה כללי מ-Android. אם אפליקציית המוזיקה עדיין לא מציגה את הפלייליסט, בצע בה Rescan/Refresh.\n\n", "\nAfter saving, the app requests a generic Android media refresh. If your music app still does not show the playlist, run its Rescan/Refresh.\n\n"));

        int show = Math.min(80, playlist.size());
        for (int i = 0; i < show; i++) {
            Song s = playlist.get(i);
            sb.append(i + 1).append(". ").append(s.energy < threshold ? tr("רגוע", "calm") : tr("קצבי", "energetic"))
                    .append(" — ").append(s.displayTitleWithArtist());
            if (s.genre != null) sb.append(" [").append(s.genre).append("]");
            if (s.bpm > 0) sb.append(" (~").append(Math.round(s.bpm)).append(" BPM)");
            sb.append('\n');
        }
        if (playlist.size() > show) sb.append(tr("… ועוד ", "… and ")).append(playlist.size() - show).append(tr(" שירים", " more songs"));
        return sb.toString();
    }

    private void appendTopCounts(StringBuilder sb, String heading, Map<String, Integer> counts, int limit) {
        if (counts.isEmpty()) return;
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(counts.entrySet());
        entries.sort((a, b) -> {
            int cmp = Integer.compare(b.getValue(), a.getValue());
            return cmp != 0 ? cmp : a.getKey().compareToIgnoreCase(b.getKey());
        });
        sb.append(heading).append(":\n");
        for (int i = 0; i < Math.min(limit, entries.size()); i++) {
            Map.Entry<String, Integer> e = entries.get(i);
            sb.append("• ").append(e.getKey()).append(": ").append(e.getValue()).append('\n');
        }
        sb.append('\n');
    }

    private void appendSpacingReport(StringBuilder sb, List<Song> playlist, boolean artist, int limit) {
        Map<String, List<Integer>> positions = new LinkedHashMap<>();
        Map<String, String> display = new HashMap<>();
        for (int i = 0; i < playlist.size(); i++) {
            Song s = playlist.get(i);
            String key = artist ? s.artistKey() : s.genreKey();
            String label = artist ? s.artistIdentity() : s.genre;
            if (key.isEmpty() || label == null) continue;
            if (!positions.containsKey(key)) positions.put(key, new ArrayList<>());
            positions.get(key).add(i);
            if (!display.containsKey(key)) display.put(key, label);
        }
        List<String> keys = new ArrayList<>(positions.keySet());
        keys.sort((a, b) -> Integer.compare(positions.get(b).size(), positions.get(a).size()));
        int shown = 0;
        for (String key : keys) {
            List<Integer> pos = positions.get(key);
            if (pos.size() < 2) continue;
            double ideal = playlist.size() / (double) pos.size();
            double sum = 0;
            int min = Integer.MAX_VALUE;
            for (int i = 1; i < pos.size(); i++) {
                int gap = pos.get(i) - pos.get(i - 1);
                sum += gap;
                min = Math.min(min, gap);
            }
            double avg = sum / (pos.size() - 1);
            sb.append("• ").append(display.get(key)).append(": ").append(pos.size())
                    .append(tr(" שירים | יעד ~", " songs | target ~")).append(String.format(Locale.ROOT, "%.1f", ideal))
                    .append(tr(" | ממוצע ", " | average ")).append(String.format(Locale.ROOT, "%.1f", avg))
                    .append(tr(" | מינימום ", " | minimum ")).append(min).append('\n');
            shown++;
            if (shown >= limit) break;
        }
        if (shown == 0) sb.append(tr("אין קבוצות עם יותר משיר אחד.\n", "No group has more than one song.\n"));
    }

    // ================== CHANGES & CORRECTIONS UI - START ==================
    private void setCorrectionsEnabled(boolean enabled) {
        if (missingMetadataButton != null) missingMetadataButton.setEnabled(enabled);
        if (genreCheckButton != null) genreCheckButton.setEnabled(enabled);
        if (manualMetadataButton != null) manualMetadataButton.setEnabled(enabled);
    }

    private String metadataFieldLabel(String field) {
        if (META_FIELD_ARTIST.equals(field)) return tr("אמן", "Artist");
        if (META_FIELD_ALBUM_ARTIST.equals(field)) return tr("להקה / Album Artist", "Band / Album Artist");
        if (META_FIELD_TITLE.equals(field)) return tr("כותרת", "Title");
        if (META_FIELD_ALBUM.equals(field)) return tr("אלבום", "Album");
        if (META_FIELD_YEAR.equals(field)) return tr("שנה", "Year");
        if (META_FIELD_GENRE.equals(field)) return "Genre";
        return field;
    }

    private static boolean isMetadataFieldMissing(Song song, String field) {
        if (song == null) return true;
        if (META_FIELD_ARTIST.equals(field)) {
            return song.overrideArtistSet ? trimToNull(song.artist) == null : !song.embeddedArtist;
        }
        if (META_FIELD_ALBUM_ARTIST.equals(field)) {
            return song.overrideAlbumArtistSet ? trimToNull(song.albumArtist) == null : !song.embeddedAlbumArtist;
        }
        if (META_FIELD_TITLE.equals(field)) {
            return song.overrideTitleSet ? trimToNull(song.title) == null : !song.embeddedTitle;
        }
        if (META_FIELD_ALBUM.equals(field)) {
            return song.overrideAlbumSet ? trimToNull(song.album) == null : !song.embeddedAlbum;
        }
        if (META_FIELD_YEAR.equals(field)) {
            return song.overrideYearSet ? song.year <= 0 : !song.embeddedYear;
        }
        if (META_FIELD_GENRE.equals(field)) {
            return song.overrideGenreSet ? trimToNull(song.genre) == null : !song.embeddedGenre;
        }
        return true;
    }

    private int missingMetadataCount(String field) {
        int count = 0;
        for (Song song : analyzedSongs) if (isMetadataFieldMissing(song, field)) count++;
        return count;
    }

    private void updateCorrectionsSummary() {
        if (correctionsSummaryText == null) return;
        if (analyzedSongs.isEmpty()) {
            correctionsSummaryText.setText(tr("יש לנתח ספרייה כדי לבדוק metadata.",
                    "Analyze a library to inspect metadata."));
            return;
        }
        boolean presencePending = false;
        for (Song song : analyzedSongs) if (!song.embeddedMetadataPresenceLoaded) { presencePending = true; break; }
        if (presencePending) {
            correctionsSummaryText.setText(tr(
                    "קיים snapshot/cache מגרסה קודמת. לחץ על 'שדות חסרים' כדי להשלים קריאת תגיות קלה ללא ניתוח אודיו מחדש.",
                    "An older snapshot/cache is loaded. Tap 'Missing fields' to perform a lightweight tag-presence refresh without repeating audio analysis."));
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(tr("שדות חסרים מתוך ", "Missing fields across ")).append(analyzedSongs.size())
                .append(tr(" שירים:\n", " songs:\n"));
        for (int i = 0; i < METADATA_FIELDS.size(); i++) {
            String field = METADATA_FIELDS.get(i);
            sb.append(metadataFieldLabel(field)).append(": ").append(missingMetadataCount(field));
            if (i < METADATA_FIELDS.size() - 1) sb.append(i % 2 == 1 ? '\n' : "   •   ");
        }
        sb.append(tr("\n\nהספירה מתייחסת לתגיות קובץ אמיתיות או ל-override שאושר; fallback משם הקובץ אינו מסתיר תגית חסרה.",
                "\n\nCounts reflect embedded file tags or an approved override; filename fallback does not hide a missing tag."));
        correctionsSummaryText.setText(sb.toString());
    }

    private void showMissingFieldsDialog() {
        if (analyzedSongs.isEmpty()) return;
        for (Song song : analyzedSongs) {
            if (!song.embeddedMetadataPresenceLoaded) {
                enrichEmbeddedPresenceForCorrections();
                return;
            }
        }
        String[] labels = new String[METADATA_FIELDS.size()];
        for (int i = 0; i < METADATA_FIELDS.size(); i++) {
            String field = METADATA_FIELDS.get(i);
            labels[i] = metadataFieldLabel(field) + " — " + missingMetadataCount(field);
        }
        new AlertDialog.Builder(this)
                .setTitle(tr("איזה סוג שדה לבדוק?", "Which field should be checked?"))
                .setItems(labels, (d, which) -> showMissingSongsForField(METADATA_FIELDS.get(which)))
                .setNegativeButton(tr("סגור", "Close"), null)
                .show();
    }

    private void enrichEmbeddedPresenceForCorrections() {
        android.app.ProgressDialog progress = new android.app.ProgressDialog(this);
        progress.setTitle(tr("משלים בדיקת metadata", "Preparing metadata check"));
        progress.setMessage(tr("קורא רק את קיום התגיות החסרות מ-cache ישן; ניתוח האודיו לא חוזר על עצמו.",
                "Reading embedded-tag presence for an older cache; audio analysis is not repeated."));
        progress.setIndeterminate(true);
        progress.setCancelable(false);
        progress.show();
        setCorrectionsEnabled(false);
        correctionsWorker.execute(() -> {
            for (Song song : analyzedSongs) {
                if (Thread.currentThread().isInterrupted()) break;
                if (!song.embeddedMetadataPresenceLoaded) readEmbeddedMetadataPresence(getApplicationContext(), song);
            }
            main.post(() -> {
                try { progress.dismiss(); } catch (Exception ignored) {}
                if (isFinishing() || isDestroyed()) return;
                persistCorrectedSnapshot();
                updateCorrectionsSummary();
                setCorrectionsEnabled(!sharedBusy && !analyzedSongs.isEmpty());
                boolean unresolved = false;
                for (Song song : analyzedSongs) if (!song.embeddedMetadataPresenceLoaded) { unresolved = true; break; }
                if (unresolved) {
                    new AlertDialog.Builder(this)
                            .setTitle(tr("לא ניתן לקרוא חלק מהתגיות", "Some tags could not be read"))
                            .setMessage(tr("לא ניתן לקבוע בבטחה אילו שדות חסרים בחלק מהקבצים. נסה לסרוק מחדש או לבדוק הרשאת גישה לתיקייה.",
                                    "Playlist Maker could not safely determine missing fields for some files. Re-scan the library or check folder access."))
                            .setPositiveButton(tr("סגור", "Close"), null)
                            .show();
                } else {
                    showMissingFieldsDialog();
                }
            });
        });
    }

    private void showMissingSongsForField(String field) {
        List<Integer> indexes = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        for (int i = 0; i < analyzedSongs.size(); i++) {
            Song song = analyzedSongs.get(i);
            if (!isMetadataFieldMissing(song, field)) continue;
            indexes.add(i);
            labels.add(song.displayTitleWithArtist());
        }
        if (indexes.isEmpty()) {
            Toast.makeText(this, tr("לא נמצאו שירים עם שדה חסר מסוג זה.",
                    "No songs are missing this field."), Toast.LENGTH_SHORT).show();
            return;
        }
        showCorrectionsSongMultiSelect(
                metadataFieldLabel(field) + tr(" — שדות חסרים", " — missing"),
                indexes, labels, field, false);
    }

    // 3.4.1: correction song pickers are multi-select. The user may choose any subset or
    // toggle all visible songs before one explicit online-consent step. Network results remain
    // suggestions only; applying selected proposals still requires a separate approval action.
    private void showCorrectionsSongMultiSelect(String title, List<Integer> indexes,
                                                 List<String> labels, String field,
                                                 boolean checkingExistingGenre) {
        if (indexes == null || labels == null || indexes.isEmpty() || indexes.size() != labels.size()) return;
        boolean[] checked = new boolean[indexes.size()];
        String[] items = labels.toArray(new String[0]);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setMultiChoiceItems(items, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton(tr("המשך", "Continue"), null)
                .setNeutralButton(tr("בחר הכול", "Select all"), null)
                .setNegativeButton(tr("ביטול", "Cancel"), null)
                .create();
        dialog.setOnShowListener(d -> {
            Runnable updateAllButton = () -> {
                boolean all = true;
                for (boolean value : checked) {
                    if (!value) { all = false; break; }
                }
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setText(all
                        ? tr("נקה הכול", "Clear all") : tr("בחר הכול", "Select all"));
            };
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                boolean all = true;
                for (boolean value : checked) {
                    if (!value) { all = false; break; }
                }
                boolean target = !all;
                for (int i = 0; i < checked.length; i++) {
                    checked[i] = target;
                    dialog.getListView().setItemChecked(i, target);
                }
                updateAllButton.run();
            });
            dialog.getListView().setOnItemClickListener((parent, view, position, id) -> {
                checked[position] = dialog.getListView().isItemChecked(position);
                updateAllButton.run();
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                List<Integer> selected = new ArrayList<>();
                for (int i = 0; i < checked.length; i++) if (checked[i]) selected.add(indexes.get(i));
                if (selected.isEmpty()) {
                    Toast.makeText(this, tr("יש לבחור לפחות שיר אחד.",
                            "Select at least one song."), Toast.LENGTH_SHORT).show();
                    return;
                }
                dialog.dismiss();
                if (selected.size() == 1) {
                    if (checkingExistingGenre) askInternetForExistingGenre(selected.get(0));
                    else askInternetForMissingField(selected.get(0), field);
                } else {
                    confirmOnlineLookupBatch(selected, field, checkingExistingGenre);
                }
            });
            updateAllButton.run();
        });
        dialog.show();
    }

    private void confirmOnlineLookupBatch(List<Integer> songIndexes, String field,
                                          boolean checkingExistingGenre) {
        int count = songIndexes == null ? 0 : songIndexes.size();
        if (count <= 0) return;
        String message;
        if (checkingExistingGenre) {
            message = tr("להשוות את ה-Genre הקיים של ", "Compare the existing Genre of ") + count
                    + tr(" שירים מול MusicBrainz?\n\nשום שינוי לא ייעשה אוטומטית. לאחר החיפוש תוכל לבחור אילו הצעות לאשר.",
                    " songs with MusicBrainz?\n\nNothing will be changed automatically. After lookup you can choose which proposals to approve.");
        } else {
            message = tr("לחפש ב-MusicBrainz השלמה עבור ", "Search MusicBrainz for ") + count
                    + tr(" שירים שבהם חסר ", " songs missing ") + metadataFieldLabel(field)
                    + tr("?\n\nפרטי זיהוי יישלחו לשירות. שום שינוי לא ייעשה אוטומטית; לאחר החיפוש תבחר אילו הצעות לאשר.",
                    "?\n\nIdentification metadata will be sent to the service. Nothing will be changed automatically; after lookup you will choose which proposals to approve.");
        }
        new AlertDialog.Builder(this)
                .setTitle(checkingExistingGenre ? tr("בדיקת Genre מרובה", "Batch Genre check")
                        : tr("חיפוש השלמות מרובה", "Batch metadata lookup"))
                .setMessage(message)
                .setPositiveButton(checkingExistingGenre ? tr("בדוק ברשת", "Check online")
                        : tr("חפש ברשת", "Search online"),
                        (d, w) -> runOnlineLookupBatch(songIndexes, field, checkingExistingGenre))
                .setNegativeButton(tr("ביטול", "Cancel"), null)
                .show();
    }

    private static final class OnlineBatchItem {
        final int songIndex;
        final MetadataOnlineLookup.Result result;
        final Exception error;

        OnlineBatchItem(int songIndex, MetadataOnlineLookup.Result result, Exception error) {
            this.songIndex = songIndex;
            this.result = result;
            this.error = error;
        }
    }

    private void runOnlineLookupBatch(List<Integer> songIndexes, String field,
                                      boolean checkingExistingGenre) {
        if (songIndexes == null || songIndexes.isEmpty()) return;
        boolean started = BackgroundWorkService.startMetadataLookup(
                getApplicationContext(), new ArrayList<>(songIndexes), field, checkingExistingGenre);
        if (!started) {
            Toast.makeText(this, tr("לא ניתן להתחיל את בדיקת metadata ברקע.",
                    "Could not start the background metadata check."), Toast.LENGTH_LONG).show();
            return;
        }
        syncUiFromSharedState();
        Toast.makeText(this, tr(
                        "הבדיקה התחילה. כל עוד האפליקציה פתוחה ההתקדמות מוצגת באזור שינויים ותיקונים; אם תצא היא תמשיך ברקע.",
                        "The check started. While the app is open, live progress is shown in Changes & corrections; if you leave, it continues in the background."),
                Toast.LENGTH_LONG).show();
    }

    // 3.4.2-3.4.4: result rows wrap instead of ellipsizing and confidence is advisory only.
    // 3.4.4 makes Genre comparison explicit (Current / Online finding / same-or-different) and
    // binds visible check marks directly to one selection state so bulk Select all / green /
    // yellow / red selection and manual taps stay synchronized. Rows with no change to apply
    // remain informational.
    private void showOnlineBatchResults(String field, boolean checkingExistingGenre,
                                        List<OnlineBatchItem> results, int metadataRevision) {
        if (results == null || results.isEmpty()) return;

        String[] labels = new String[results.size()];
        boolean[] actionable = new boolean[results.size()];
        boolean[] checked = new boolean[results.size()];
        int[] categories = new int[results.size()];
        Arrays.fill(categories, CONFIDENCE_NONE);
        int actionableCount = 0;

        for (int i = 0; i < results.size(); i++) {
            OnlineBatchItem item = results.get(i);
            Song song = item.songIndex >= 0 && item.songIndex < analyzedSongs.size()
                    ? analyzedSongs.get(item.songIndex) : null;
            String songLabel = song == null ? tr("שיר לא זמין", "Song unavailable") : song.displayTitleWithArtist();

            if (item.error != null) {
                labels[i] = songLabel + "\n" + tr("החיפוש נכשל: ", "Lookup failed: ") + safeMessage(item.error);
                continue;
            }

            MetadataOnlineLookup.Result result = item.result;
            if (checkingExistingGenre) {
                String current = song == null ? null : trimToNull(song.genre);
                String currentText = current == null ? tr("לא ידוע", "Unknown") : current;
                String onlineGenres = genreCandidatesText(result);

                if (result == null || result.genreCandidates.isEmpty()) {
                    labels[i] = songLabel
                            + "\n" + tr("קיים: ", "Current: ") + currentText
                            + "\n" + tr("ממצא ברשת: לא נמצא Genre.", "Online finding: no Genre was found.")
                            + "\n" + tr("מצב: אין הצעה להחלפה.", "Status: no replacement proposal.");
                } else if (result.genreSupported) {
                    categories[i] = confidenceCategory(result.confidence);
                    labels[i] = songLabel
                            + "\n" + tr("קיים: ", "Current: ") + currentText
                            + "\n" + tr("ממצא ברשת: ", "Online finding: ") + onlineGenres
                            + "\n" + tr("מצב: זהה/תואם ל-Genre הקיים ✓ — אין שינוי להחיל.",
                            "Status: same as / supports the existing Genre ✓ — no change to apply.")
                            + "\n" + tr("ביטחון: ", "Confidence: ") + confidenceText(result.confidence);
                } else if (trimToNull(result.suggestedValue) != null) {
                    categories[i] = confidenceCategory(result.confidence);
                    actionable[i] = true;
                    actionableCount++;
                    labels[i] = songLabel
                            + "\n" + tr("קיים: ", "Current: ") + currentText
                            + "\n" + tr("ממצא ברשת: ", "Online finding: ") + onlineGenres
                            + "\n" + tr("מוצע: ", "Suggested: ") + result.suggestedValue
                            + "\n" + tr("מצב: שונה מהקיים → ניתן לבחור להחלפה.",
                            "Status: different from current → selectable for replacement.")
                            + "\n" + tr("ביטחון: ", "Confidence: ") + confidenceText(result.confidence);
                } else {
                    labels[i] = songLabel
                            + "\n" + tr("קיים: ", "Current: ") + currentText
                            + "\n" + tr("ממצא ברשת: ", "Online finding: ") + onlineGenres
                            + "\n" + tr("מצב: לא נמצאה חלופה שימושית.", "Status: no usable alternative was found.");
                }
            } else {
                if (result != null && trimToNull(result.suggestedValue) != null) {
                    categories[i] = confidenceCategory(result.confidence);
                    actionable[i] = true;
                    actionableCount++;
                    labels[i] = songLabel + "\n" + metadataFieldLabel(field) + ": " + result.suggestedValue
                            + "\n" + tr("ביטחון: ", "Confidence: ") + confidenceText(result.confidence);
                } else {
                    labels[i] = songLabel + "\n" + tr("לא נמצאה הצעה.", "No suggestion was found.");
                }
            }
        }

        int greenCount = 0;
        int yellowCount = 0;
        int redCount = 0;
        for (int i = 0; i < actionable.length; i++) {
            if (!actionable[i]) continue;
            if (categories[i] == CONFIDENCE_HIGH) greenCount++;
            else if (categories[i] == CONFIDENCE_MEDIUM) yellowCount++;
            else if (categories[i] == CONFIDENCE_LOW) redCount++;
        }
        final int finalActionableCount = actionableCount;
        final int finalGreenCount = greenCount;
        final int finalYellowCount = yellowCount;
        final int finalRedCount = redCount;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(4), dp(12), dp(4));
        box.setLayoutDirection(AppLanguage.isHebrew(this) ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        String genreExtra = checkingExistingGenre
                ? tr("\nב-Check Genre, שורה זהה היא מידע בלבד ואינה זקוקה לעדכון; כפתורי הבחירה מסמנים את כל השינויים האפשריים לפי צבע.",
                "\nIn Check Genre, an identical/supported row is informational and needs no update; quick-select buttons select all change proposals by color.")
                : "";
        TextView legend = makeInfoText(
                tr("ירוק: 85–100%  •  צהוב: 65–84%  •  אדום: 0–64%\n"
                                + "הצבע מציין רמת ביטחון בלבד. גם הצעה אדומה ניתנת לבחירה; רק שורה ללא ממצא אינה ניתנת להחלה.",
                        "Green: 85–100%  •  Yellow: 65–84%  •  Red: 0–64%\n"
                                + "Color indicates confidence only. Red suggestions remain selectable; only rows with no result cannot be applied.")
                        + genreExtra,
                12);
        legend.setTextColor(UI_MUTED);
        box.addView(legend, buttonParams(2));

        // 3.4.4: keep a scalable ListView, but bind every visible check mark directly from
        // our own checked[] state instead of relying on ListView's internal choice bookkeeping.
        // Quick selection and manual taps now update the same state, so Select all / confidence
        // colors remain reliable even when Check Genre contains many songs and rows are recycled.
        ListView list = new ListView(this);
        list.setChoiceMode(ListView.CHOICE_MODE_NONE);
        list.setDividerHeight(dp(1));
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_multiple_choice, labels) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View raw = super.getView(position, convertView, parent);
                CheckedTextView row = (CheckedTextView) raw;
                row.setSingleLine(false);
                row.setMaxLines(Integer.MAX_VALUE);
                row.setEllipsize(null);
                row.setHorizontallyScrolling(false);
                row.setGravity((AppLanguage.isHebrew(MainActivity.this) ? Gravity.RIGHT : Gravity.LEFT)
                        | Gravity.CENTER_VERTICAL);
                row.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
                row.setPadding(dp(14), dp(10), dp(14), dp(10));
                row.setTextSize(14);
                row.setTextColor(confidenceColor(categories[position]));
                row.setChecked(actionable[position] && checked[position]);
                row.setEnabled(actionable[position]);
                row.setAlpha(actionable[position] ? 1.0f : 0.72f);
                return row;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            if (!actionable[position]) return;
            checked[position] = !checked[position];
            adapter.notifyDataSetChanged();
        });
        box.addView(list, new LinearLayout.LayoutParams(-1, dp(360)));

        TextView chooseLabel = makeInfoText(checkingExistingGenre
                ? tr("בחירה מהירה של שינויים לפי צבע:", "Quick-select changes by color:")
                : tr("בחירה מהירה לפי צבע:", "Quick selection by color:"), 12);
        chooseLabel.setTextColor(UI_TEXT);
        box.addView(chooseLabel, buttonParams(7));

        LinearLayout quick1 = new LinearLayout(this);
        quick1.setOrientation(LinearLayout.HORIZONTAL);
        quick1.setGravity(Gravity.CENTER);
        Button selectAll = makeButton(checkingExistingGenre
                ? tr("בחר כל השינויים", "Select all changes")
                : tr("בחר הכול", "Select all"));
        Button selectGreen = makeButton(tr("בחר ירוק", "Select green") + " (" + greenCount + ")");
        Button selectYellow = makeButton(tr("בחר צהוב", "Select yellow") + " (" + yellowCount + ")");
        selectAll.setTextSize(11);
        selectGreen.setTextSize(11);
        selectYellow.setTextSize(11);
        selectGreen.setTextColor(CONFIDENCE_GREEN);
        selectYellow.setTextColor(CONFIDENCE_YELLOW);
        quick1.addView(selectAll, new LinearLayout.LayoutParams(0, -2, 1f));
        quick1.addView(selectGreen, new LinearLayout.LayoutParams(0, -2, 1f));
        quick1.addView(selectYellow, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(quick1, buttonParams(4));

        LinearLayout quick2 = new LinearLayout(this);
        quick2.setOrientation(LinearLayout.HORIZONTAL);
        quick2.setGravity(Gravity.CENTER);
        Button selectRed = makeButton(tr("בחר אדום", "Select red") + " (" + redCount + ")");
        Button clear = makeButton(tr("נקה", "Clear"));
        selectRed.setTextSize(11);
        clear.setTextSize(11);
        selectRed.setTextColor(CONFIDENCE_RED);
        quick2.addView(selectRed, new LinearLayout.LayoutParams(0, -2, 1f));
        quick2.addView(clear, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(quick2, buttonParams(4));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(checkingExistingGenre ? tr("תוצאות בדיקת Genre", "Genre check results")
                        : tr("הצעות metadata", "Metadata suggestions"))
                .setView(box)
                .setPositiveButton(tr("אשר והחל מסומנים", "Approve & apply selected"), null)
                .setNegativeButton(tr("סגור ללא שינוי", "Close without changes"), null)
                .create();

        Runnable refreshSelection = () -> {
            adapter.notifyDataSetChanged();
            list.invalidateViews();
        };
        Runnable selectEveryProposal = () -> {
            for (int i = 0; i < checked.length; i++) checked[i] = actionable[i];
            refreshSelection.run();
        };
        java.util.function.IntConsumer selectByCategory = category -> {
            for (int i = 0; i < checked.length; i++) {
                if (actionable[i] && categories[i] == category) checked[i] = true;
            }
            refreshSelection.run();
        };

        selectAll.setOnClickListener(v -> selectEveryProposal.run());
        selectGreen.setOnClickListener(v -> selectByCategory.accept(CONFIDENCE_HIGH));
        selectYellow.setOnClickListener(v -> selectByCategory.accept(CONFIDENCE_MEDIUM));
        selectRed.setOnClickListener(v -> selectByCategory.accept(CONFIDENCE_LOW));
        clear.setOnClickListener(v -> {
            Arrays.fill(checked, false);
            refreshSelection.run();
        });

        dialog.setOnShowListener(d -> {
            metadataResultsDialogShowing = true;
            Button apply = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            Button close = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            if (finalActionableCount == 0) {
                apply.setEnabled(false);
                selectAll.setEnabled(false);
                selectGreen.setEnabled(false);
                selectYellow.setEnabled(false);
                selectRed.setEnabled(false);
                clear.setEnabled(false);
            } else {
                selectGreen.setEnabled(finalGreenCount > 0);
                selectYellow.setEnabled(finalYellowCount > 0);
                selectRed.setEnabled(finalRedCount > 0);
            }
            apply.setOnClickListener(v -> {
                List<OnlineBatchItem> approved = new ArrayList<>();
                for (int i = 0; i < results.size(); i++) {
                    if (checked[i] && actionable[i]) approved.add(results.get(i));
                }
                if (approved.isEmpty()) {
                    Toast.makeText(this, tr("לא סומנה הצעה להחלה.",
                            "No proposal is selected for applying."), Toast.LENGTH_SHORT).show();
                    return;
                }
                BackgroundWorkService.dismissMetadataLookupResults(getApplicationContext(), metadataRevision);
                dialog.dismiss();
                applyInternetOverridesBatch(field, approved);
            });
            close.setOnClickListener(v -> {
                BackgroundWorkService.dismissMetadataLookupResults(getApplicationContext(), metadataRevision);
                dialog.dismiss();
            });
        });
        dialog.setOnDismissListener(d -> metadataResultsDialogShowing = false);
        dialog.show();
    }

    private String genreCandidatesText(MetadataOnlineLookup.Result result) {
        if (result == null || result.genreCandidates == null || result.genreCandidates.isEmpty()) {
            return tr("לא נמצא", "None found");
        }
        StringBuilder sb = new StringBuilder();
        int limit = Math.min(3, result.genreCandidates.size());
        for (int i = 0; i < limit; i++) {
            if (i > 0) sb.append(", ");
            sb.append(result.genreCandidates.get(i));
        }
        if (result.genreCandidates.size() > limit) {
            sb.append(tr(" ועוד ", " + ")).append(result.genreCandidates.size() - limit);
        }
        return sb.toString();
    }

    private int confidenceCategory(int confidence) {
        int value = clampInt(confidence, 0, 100);
        return value >= 85 ? CONFIDENCE_HIGH : value >= 65 ? CONFIDENCE_MEDIUM : CONFIDENCE_LOW;
    }

    private int confidenceColor(int category) {
        if (category == CONFIDENCE_HIGH) return CONFIDENCE_GREEN;
        if (category == CONFIDENCE_MEDIUM) return CONFIDENCE_YELLOW;
        if (category == CONFIDENCE_LOW) return CONFIDENCE_RED;
        return UI_MUTED;
    }

    private void applyInternetOverridesBatch(String field, List<OnlineBatchItem> approved) {
        int applied = 0;
        if (approved != null) {
            for (OnlineBatchItem item : approved) {
                if (item == null || item.result == null || trimToNull(item.result.suggestedValue) == null) continue;
                if (applyInternetOverrideValue(item.songIndex, field, item.result.suggestedValue)) applied++;
            }
        }
        if (applied <= 0) return;
        finishApprovedOverrides(applied);
    }

    private void askInternetForMissingField(int songIndex, String field) {
        if (songIndex < 0 || songIndex >= analyzedSongs.size()) return;
        Song song = analyzedSongs.get(songIndex);
        String effective = metadataFieldValue(song, field);
        StringBuilder message = new StringBuilder(song.displayTitleWithArtist())
                .append("\n\n")
                .append(tr("השדה חסר בתגיות הקובץ.", "This field is missing from the embedded file tags."));
        if (effective != null) {
            message.append(tr("\nערך עזר נוכחי באפליקציה: ", "\nCurrent helper value in the app: ")).append(effective);
        }
        message.append(tr(
                "\n\nלחפש הצעה ב-MusicBrainz? פרטי זיהוי כמו כותרת/אמן יישלחו לשירות. שום שינוי לא יוחל אוטומטית.",
                "\n\nSearch MusicBrainz for a suggestion? Identification metadata such as title/artist will be sent to the service. Nothing will be changed automatically."));
        new AlertDialog.Builder(this)
                .setTitle(metadataFieldLabel(field))
                .setMessage(message.toString())
                .setPositiveButton(tr("חפש ברשת", "Search online"), (d, w) -> runOnlineLookup(songIndex, field, false))
                .setNeutralButton(tr("תיקון ידני", "Edit manually"), (d, w) -> showMetadataEditor(songIndex, field))
                .setNegativeButton(tr("ביטול", "Cancel"), null)
                .show();
    }

    private void showExistingGenrePicker() {
        if (analyzedSongs.isEmpty()) return;
        List<Integer> indexes = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        for (int i = 0; i < analyzedSongs.size(); i++) {
            Song song = analyzedSongs.get(i);
            String genre = trimToNull(song.genre);
            if (genre == null) continue;
            indexes.add(i);
            labels.add(song.displayTitleWithArtist() + "  [" + genre + "]");
        }
        if (indexes.isEmpty()) {
            Toast.makeText(this, tr("לא נמצא Genre קיים לבדיקה.",
                    "No existing Genre value was found to check."), Toast.LENGTH_SHORT).show();
            return;
        }
        showCorrectionsSongMultiSelect(
                tr("בחר שירים לבדיקת Genre", "Choose songs to verify Genre"),
                indexes, labels, META_FIELD_GENRE, true);
    }

    private void askInternetForExistingGenre(int songIndex) {
        Song song = analyzedSongs.get(songIndex);
        new AlertDialog.Builder(this)
                .setTitle(tr("בדיקת Genre קיים", "Check existing Genre"))
                .setMessage(song.displayTitleWithArtist() + "\nGenre: " + nullToEmpty(song.genre)
                        + tr("\n\nלהשוות מול MusicBrainz? שום שינוי לא ייעשה ללא אישור נוסף.",
                        "\n\nCompare it with MusicBrainz? No change will be made without another explicit approval."))
                .setPositiveButton(tr("בדוק ברשת", "Check online"), (d, w) -> runOnlineLookup(songIndex, META_FIELD_GENRE, true))
                .setNeutralButton(tr("תיקון ידני", "Edit manually"), (d, w) -> showMetadataEditor(songIndex, META_FIELD_GENRE))
                .setNegativeButton(tr("ביטול", "Cancel"), null)
                .show();
    }

    private void runOnlineLookup(int songIndex, String field, boolean checkingExistingGenre) {
        if (songIndex < 0 || songIndex >= analyzedSongs.size()) return;
        runOnlineLookupBatch(Collections.singletonList(songIndex), field, checkingExistingGenre);
    }

    private String confidenceText(int confidence) {
        int value = clampInt(confidence, 0, 100);
        String level = value >= 85 ? tr("גבוהה", "High") : value >= 65 ? tr("בינונית", "Medium") : tr("נמוכה", "Low");
        return level + " (" + value + "%)";
    }

    private static String metadataFieldValue(Song song, String field) {
        if (META_FIELD_ARTIST.equals(field)) return trimToNull(song.artist);
        if (META_FIELD_ALBUM_ARTIST.equals(field)) return trimToNull(song.albumArtist);
        if (META_FIELD_TITLE.equals(field)) return trimToNull(song.title);
        if (META_FIELD_ALBUM.equals(field)) return trimToNull(song.album);
        if (META_FIELD_YEAR.equals(field)) return song.year > 0 ? String.valueOf(song.year) : null;
        if (META_FIELD_GENRE.equals(field)) return trimToNull(song.genre);
        return null;
    }

    private boolean applyInternetOverrideValue(int songIndex, String field, String value) {
        if (songIndex < 0 || songIndex >= analyzedSongs.size()) return false;
        Song song = analyzedSongs.get(songIndex);
        String cleaned = trimToNull(value);
        if (cleaned == null) return false;
        if (META_FIELD_ARTIST.equals(field)) {
            song.artist = cleaned;
            song.artistSource = "MusicBrainz approved override";
            song.overrideArtistSet = true;
        } else if (META_FIELD_ALBUM_ARTIST.equals(field)) {
            song.albumArtist = cleaned;
            song.overrideAlbumArtistSet = true;
        } else if (META_FIELD_TITLE.equals(field)) {
            song.title = cleaned;
            song.overrideTitleSet = true;
        } else if (META_FIELD_ALBUM.equals(field)) {
            song.album = cleaned;
            song.overrideAlbumSet = true;
        } else if (META_FIELD_YEAR.equals(field)) {
            int parsed = parseYear(cleaned);
            if (parsed <= 0) return false;
            song.year = parsed;
            song.yearMetadataLoaded = true;
            song.overrideYearSet = true;
        } else if (META_FIELD_GENRE.equals(field)) {
            song.genre = canonicalGenre(cleaned);
            song.genreSource = "MusicBrainz approved override";
            song.overrideGenreSet = true;
        } else {
            return false;
        }
        song.invalidateScheduleKeys();
        saveSingleFieldOverride(song, field);
        return true;
    }

    private void finishApprovedOverrides(int count) {
        persistCorrectedSnapshot();
        refreshFilterOptions();
        updateCorrectionsSummary();
        showAnalysisSummary();
        Toast.makeText(this, count == 1
                        ? tr("התיקון אושר ונשמר כ-override פנימי.",
                        "Correction approved and stored as an internal override.")
                        : tr("נשמרו ", "Stored ") + count
                        + tr(" תיקונים מאושרים כ-overrides פנימיים.",
                        " approved corrections as internal overrides."),
                Toast.LENGTH_SHORT).show();
    }

    private void persistCorrectedSnapshot() {
        if (analyzedSongs.isEmpty()) return;
        BackgroundWorkService.setAnalysisSnapshot(getApplicationContext(), new ArrayList<>(analyzedSongs), lastSkipped, lastCacheHits);
        BackgroundWorkService.State state = BackgroundWorkService.getState(getApplicationContext());
        lastAppliedAnalysisRevision = state.analysisRevision;
    }
    // =================== CHANGES & CORRECTIONS UI - END ===================

    private void showMetadataEditor() {
        showMetadataEditor(-1, null);
    }

    private void showMetadataEditor(int initialSongIndex, String focusField) {
        if (analyzedSongs.isEmpty()) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(4));
        box.setLayoutDirection(AppLanguage.isHebrew(this) ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        Spinner songSpinner = new Spinner(this);
        List<String> labels = new ArrayList<>();
        for (Song s : analyzedSongs) labels.add(s.displayTitleWithArtist());
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        songSpinner.setAdapter(adapter);
        if (initialSongIndex >= 0 && initialSongIndex < analyzedSongs.size()) songSpinner.setSelection(initialSongIndex);
        box.addView(songSpinner, new LinearLayout.LayoutParams(-1, -2));

        EditText artist = metadataField(tr("אמן", "Artist"));
        EditText albumArtist = metadataField(tr("להקה / Album Artist", "Band / Album Artist"));
        EditText title = metadataField(tr("כותרת", "Title"));
        EditText album = metadataField(tr("אלבום", "Album"));
        EditText year = metadataField(tr("שנה", "Year"));
        year.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        EditText genre = metadataField("Genre");
        box.addView(artist);
        box.addView(albumArtist);
        box.addView(title);
        box.addView(album);
        box.addView(year);
        box.addView(genre);

        Runnable load = () -> {
            Song s = analyzedSongs.get(songSpinner.getSelectedItemPosition());
            artist.setText(nullToEmpty(s.artist));
            albumArtist.setText(nullToEmpty(s.albumArtist));
            title.setText(nullToEmpty(s.title));
            album.setText(nullToEmpty(s.album));
            year.setText(s.year > 0 ? String.valueOf(s.year) : "");
            genre.setText(nullToEmpty(s.genre));
        };
        songSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { load.run(); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        load.run();

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(tr("הזנה ותיקון ידניים", "Manual metadata edit"))
                .setView(box)
                .setPositiveButton(tr("שמור override", "Save override"), null)
                .setNeutralButton(tr("אפס תיקון", "Reset override"), null)
                .setNegativeButton(tr("ביטול", "Cancel"), null)
                .create();
        dialog.setOnShowListener(d -> {
            if (focusField != null) {
                EditText focus = META_FIELD_ARTIST.equals(focusField) ? artist
                        : META_FIELD_ALBUM_ARTIST.equals(focusField) ? albumArtist
                        : META_FIELD_TITLE.equals(focusField) ? title
                        : META_FIELD_ALBUM.equals(focusField) ? album
                        : META_FIELD_YEAR.equals(focusField) ? year
                        : META_FIELD_GENRE.equals(focusField) ? genre : null;
                if (focus != null) {
                    focus.requestFocus();
                    focus.setSelection(focus.getText().length());
                }
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                Song song = analyzedSongs.get(songSpinner.getSelectedItemPosition());
                String yearText = trimToNull(year.getText().toString());
                int parsedYear = yearText == null ? 0 : parseYear(yearText);
                if (yearText != null && parsedYear <= 0) {
                    Toast.makeText(this, tr("יש להזין שנה חוקית בת ארבע ספרות או להשאיר ריק.",
                            "Enter a valid four-digit year or leave it blank."), Toast.LENGTH_LONG).show();
                    return;
                }
                song.artist = trimToNull(artist.getText().toString());
                song.albumArtist = trimToNull(albumArtist.getText().toString());
                song.title = trimToNull(title.getText().toString());
                song.album = trimToNull(album.getText().toString());
                song.year = parsedYear;
                song.yearMetadataLoaded = true;
                String enteredGenre = trimToNull(genre.getText().toString());
                song.genre = enteredGenre == null ? null : canonicalGenre(enteredGenre);
                song.genreSource = song.genre == null ? null : "Manual approved override";
                song.artistSource = song.artist == null ? null : "Manual approved override";
                song.overrideArtistSet = true;
                song.overrideAlbumArtistSet = true;
                song.overrideTitleSet = true;
                song.overrideAlbumSet = true;
                song.overrideYearSet = true;
                song.overrideGenreSet = true;
                song.invalidateScheduleKeys();
                saveManualOverride(song);
                persistCorrectedSnapshot();
                refreshFilterOptions();
                updateCorrectionsSummary();
                showAnalysisSummary();
                Toast.makeText(this, tr("התיקון נשמר כ-override פנימי בלבד.",
                        "Correction saved as an internal override only."), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                Song song = analyzedSongs.get(songSpinner.getSelectedItemPosition());
                clearManualOverride(song);
                readMetadata(this, song);
                song.invalidateScheduleKeys();
                persistCorrectedSnapshot();
                refreshFilterOptions();
                updateCorrectionsSummary();
                showAnalysisSummary();
                Toast.makeText(this, tr("ה-override אופס; קובץ האודיו לא שונה.",
                        "Override reset; the audio file was not changed."), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    private EditText metadataField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private void confirmClearCache() {
        new AlertDialog.Builder(this)
                .setTitle(tr("ניקוי מטמון", "Clear cache"))
                .setMessage(tr("למחוק תוצאות ניתוח אודיו שמורות? תיקוני metadata פנימיים לא יימחקו.", "Delete cached audio-analysis results? Internal metadata corrections will not be deleted."))
                .setPositiveButton(tr("נקה", "Clear"), (d, w) -> {
                    SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    for (String key : prefs.getAll().keySet()) {
                        if (key.startsWith(CACHE_PREFIX)) editor.remove(key);
                    }
                    editor.apply();
                    analyzedSongs.clear();
                    refreshFilterOptions();
                    updateCorrectionsSummary();
                    BackgroundWorkService.clearAnalysisSnapshot(getApplicationContext());
                    lastAppliedAnalysisRevision = -1;
                    createButton.setEnabled(false);
                    setCorrectionsEnabled(false);
                    statusText.setText(tr("מטמון הניתוח נוקה. יש לבצע סריקה מחדש.", "Analysis cache cleared. Run a new scan."));
                    resultText.setText("");
                })
                .setNegativeButton(tr("ביטול", "Cancel"), null)
                .show();
    }

    static boolean loadCachedAnalysis(Context context, Song song) {
        try {
            String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(CACHE_PREFIX + song.cacheKey(), null);
            if (json == null) return false;
            JSONObject o = new JSONObject(json);
            if (o.optInt("v", 0) != CACHE_VERSION) return false;
            if (o.optLong("size", -1) != song.size) return false;
            if (o.optLong("modified", -1) != song.lastModified) return false;
            song.rmsDb = o.getDouble("rms");
            song.bpm = o.getDouble("bpm");
            song.activity = o.getDouble("activity");
            song.title = jsonNullToString(o, "title");
            song.artist = jsonNullToString(o, "artist");
            song.albumArtist = jsonNullToString(o, "albumArtist");
            song.album = jsonNullToString(o, "album");
            song.genre = jsonNullToString(o, "genre");
            song.yearMetadataLoaded = o.has("year");
            song.year = song.yearMetadataLoaded ? o.optInt("year", 0) : 0;
            song.genreSource = jsonNullToString(o, "genreSource");
            song.artistSource = jsonNullToString(o, "artistSource");
            song.embeddedMetadataPresenceLoaded = o.optBoolean("embeddedPresenceLoaded", false);
            if (song.embeddedMetadataPresenceLoaded) {
                song.embeddedArtist = o.optBoolean("embeddedArtist", false);
                song.embeddedAlbumArtist = o.optBoolean("embeddedAlbumArtist", false);
                song.embeddedTitle = o.optBoolean("embeddedTitle", false);
                song.embeddedAlbum = o.optBoolean("embeddedAlbum", false);
                song.embeddedYear = o.optBoolean("embeddedYear", false);
                song.embeddedGenre = o.optBoolean("embeddedGenre", false);
            }
            song.analyzed = true;
            song.fromCache = true;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static void saveCachedAnalysis(Context context, Song song) {
        try {
            JSONObject o = new JSONObject();
            o.put("v", CACHE_VERSION);
            o.put("size", song.size);
            o.put("modified", song.lastModified);
            o.put("rms", song.rmsDb);
            o.put("bpm", song.bpm);
            o.put("activity", song.activity);
            putNullable(o, "title", song.title);
            putNullable(o, "artist", song.artist);
            putNullable(o, "albumArtist", song.albumArtist);
            putNullable(o, "album", song.album);
            putNullable(o, "genre", song.genre);
            if (song.yearMetadataLoaded) {
                if (song.year > 0) o.put("year", song.year); else o.put("year", JSONObject.NULL);
            }
            putNullable(o, "genreSource", song.genreSource);
            putNullable(o, "artistSource", song.artistSource);
            if (song.embeddedMetadataPresenceLoaded) {
                o.put("embeddedPresenceLoaded", true);
                o.put("embeddedArtist", song.embeddedArtist);
                o.put("embeddedAlbumArtist", song.embeddedAlbumArtist);
                o.put("embeddedTitle", song.embeddedTitle);
                o.put("embeddedAlbum", song.embeddedAlbum);
                o.put("embeddedYear", song.embeddedYear);
                o.put("embeddedGenre", song.embeddedGenre);
            }
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(CACHE_PREFIX + song.cacheKey(), o.toString()).apply();
        } catch (Exception ignored) {}
    }

    static void applyManualOverride(Context context, Song song) {
        song.clearOverrideFlags();
        try {
            String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(OVERRIDE_PREFIX + song.cacheKey(), null);
            if (json == null) return;
            JSONObject o = new JSONObject(json);
            if (o.has("artist")) {
                song.artist = jsonNullToString(o, "artist");
                song.overrideArtistSet = true;
                song.artistSource = song.artist == null ? null : "User-approved internal override";
            }
            if (o.has("albumArtist")) {
                song.albumArtist = jsonNullToString(o, "albumArtist");
                song.overrideAlbumArtistSet = true;
            }
            if (o.has("title")) {
                song.title = jsonNullToString(o, "title");
                song.overrideTitleSet = true;
            }
            if (o.has("album")) {
                song.album = jsonNullToString(o, "album");
                song.overrideAlbumSet = true;
            }
            if (o.has("year")) {
                song.year = o.isNull("year") ? 0 : o.optInt("year", 0);
                song.yearMetadataLoaded = true;
                song.overrideYearSet = true;
            }
            if (o.has("genre")) {
                song.genre = jsonNullToString(o, "genre");
                song.overrideGenreSet = true;
                song.genreSource = song.genre == null ? null : "User-approved internal override";
            }
        } catch (Exception ignored) {}
    }

    private void saveManualOverride(Song song) {
        try {
            JSONObject o = new JSONObject();
            o.put("v", 2);
            putNullable(o, "artist", song.artist);
            putNullable(o, "albumArtist", song.albumArtist);
            putNullable(o, "title", song.title);
            putNullable(o, "album", song.album);
            if (song.year > 0) o.put("year", song.year); else o.put("year", JSONObject.NULL);
            putNullable(o, "genre", song.genre);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(OVERRIDE_PREFIX + song.cacheKey(), o.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void saveSingleFieldOverride(Song song, String field) {
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            String stored = prefs.getString(OVERRIDE_PREFIX + song.cacheKey(), null);
            JSONObject o = stored == null ? new JSONObject() : new JSONObject(stored);
            o.put("v", 2);
            if (META_FIELD_ARTIST.equals(field)) putNullable(o, "artist", song.artist);
            else if (META_FIELD_ALBUM_ARTIST.equals(field)) putNullable(o, "albumArtist", song.albumArtist);
            else if (META_FIELD_TITLE.equals(field)) putNullable(o, "title", song.title);
            else if (META_FIELD_ALBUM.equals(field)) putNullable(o, "album", song.album);
            else if (META_FIELD_YEAR.equals(field)) {
                if (song.year > 0) o.put("year", song.year); else o.put("year", JSONObject.NULL);
            } else if (META_FIELD_GENRE.equals(field)) putNullable(o, "genre", song.genre);
            prefs.edit().putString(OVERRIDE_PREFIX + song.cacheKey(), o.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void clearManualOverride(Song song) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(OVERRIDE_PREFIX + song.cacheKey()).apply();
        song.clearOverrideFlags();
    }

    private static void putNullable(JSONObject o, String key, String value) throws Exception {
        if (value == null) o.put(key, JSONObject.NULL); else o.put(key, value);
    }

    private static String jsonNullToString(JSONObject o, String key) {
        if (!o.has(key) || o.isNull(key)) return null;
        String s = o.optString(key, null);
        return trimToNull(s);
    }

    static String normalizedPlaylistName(String raw) {
        String s = raw == null ? "" : raw.trim();
        s = s.replace('/', '_').replace('\\', '_').replace('\n', ' ').replace('\r', ' ');
        if (s.isEmpty()) s = DEFAULT_PLAYLIST_NAME;
        if (!s.toLowerCase(Locale.ROOT).endsWith(".m3u8")) s += ".m3u8";
        return s;
    }

    private static String stripExtension(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private static String trimToNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }

    private static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    private static String normalizeGroup(String input) {
        String s = trimToNull(input);
        if (s == null) return "";
        s = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        s = s.toLowerCase(Locale.ROOT).replace('&', ' ');
        if (s.endsWith(", the")) s = "the " + s.substring(0, s.length() - 5).trim();
        s = s.replaceAll("[^\\p{L}\\p{N}]+", " ").trim().replaceAll("\\s+", " ");
        if (s.startsWith("the ")) s = s.substring(4).trim();
        return s;
    }

    private static String normalizeArtistKey(String artist, String title) {
        String a = trimToNull(artist);
        if (a == null) return "";

        // Compilation labels are not the performer. Strip only explicit collection
        // suffixes; do not guess from audio or from arbitrary words.
        String cleaned = a.replaceAll("(?i)\\s*[-–—:]\\s*(platinum collection|greatest hits(?:\\s*cd\\s*\\d+)?|best of(?:\\s+.*)?)\\s*$", "").trim();
        if (!cleaned.isEmpty() && !cleaned.equals(a)) a = cleaned;

        String titleArtist = titleArtistPrefix(title);
        String aNorm = normalizeGroup(a);
        String aCompact = aNorm.replace(" ", "");
        if (titleArtist != null) {
            String tNorm = normalizeGroup(titleArtist);
            String tCompact = tNorm.replace(" ", "");
            boolean genericCollection = aNorm.contains("star mark") && aNorm.contains("greatest hits");
            boolean exactNoSpaces = !tCompact.isEmpty() && aCompact.equals(tCompact);
            boolean channelSuffix = !tCompact.isEmpty() && (
                    aCompact.equals(tCompact + "music")
                            || aCompact.equals(tCompact + "official")
                            || aCompact.equals(tCompact + "vevo")
                            || aCompact.equals(tCompact + "officialmusic")
                            || aCompact.equals(tCompact + "musicOfficial".toLowerCase(Locale.ROOT))
            );
            boolean genericChannel = aCompact.endsWith("vevo") || aCompact.endsWith("official");
            if (genericCollection || exactNoSpaces || channelSuffix || genericChannel) {
                a = titleArtist;
            }
        }

        // Compact only the scheduling key. This merges harmless formatting differences
        // such as "LeonardCohen" vs "Leonard Cohen" without changing displayed metadata.
        return normalizeGroup(a).replace(" ", "");
    }

    private static String titleArtistPrefix(String title) {
        String t = trimToNull(title);
        if (t == null) return null;
        String[] separators = {" — ", " – ", " - "};
        for (String sep : separators) {
            int i = t.indexOf(sep);
            if (i > 1) {
                String prefix = t.substring(0, i).trim();
                if (prefix.length() >= 2 && prefix.length() <= 80) return prefix;
            }
        }
        return null;
    }

    private static String titleFamily(String title) {
        String s = stripExtension(title == null ? "" : title).toLowerCase(Locale.ROOT);
        s = s.replaceAll("\\([^)]*(remaster|remastered|live|mono|stereo|version|mix|edit|demo|take|radio|acoustic)[^)]*\\)", " ");
        s = s.replaceAll("\\[[^]]*(remaster|remastered|live|mono|stereo|version|mix|edit|demo|take|radio|acoustic)[^]]*]", " ");
        s = s.replaceAll("[-–—]\\s*(remaster(ed)?|live|mono|stereo|version|mix|edit|demo|take|radio edit|acoustic).*", " ");
        s = s.replaceAll("\\b(19|20)\\d{2}\\b", " ");
        return normalizeGroup(s);
    }

    private static String sha256(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < 12; i++) out.append(String.format(Locale.ROOT, "%02x", bytes[i]));
            return out.toString();
        } catch (Exception e) {
            return Integer.toHexString(s.hashCode());
        }
    }

    private static void increment(Map<String, Integer> map, String key) {
        String t = trimToNull(key);
        if (t == null) return;
        map.put(t, map.containsKey(t) ? map.get(t) + 1 : 1);
    }

    private static void incrementKey(Map<String, Integer> map, String key) {
        if (key == null || key.isEmpty()) return;
        map.put(key, map.containsKey(key) ? map.get(key) + 1 : 1);
    }

    private static int clampInt(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    static String safeMessage(Exception e) {
        String m = e.getMessage();
        return (m == null || m.trim().isEmpty()) ? e.getClass().getSimpleName() : m;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        // EN: Long-running work belongs to BackgroundWorkService, not this Activity.
        //     Closing the screen does not cancel it; persisted state/snapshot allow recovery.
        // HE: העבודה הארוכה שייכת לשירות הרקע ולא ל-Activity. סגירת המסך אינה מבטלת
        //     את המשימה; מצב שמור ו-snapshot מאפשרים שחזור.
        main.removeCallbacks(uiStatePoller);
        correctionsWorker.shutdownNow();
        super.onDestroy();
    }

    private static final class SimpleItemSelectedListener implements AdapterView.OnItemSelectedListener {
        private final Runnable callback;
        SimpleItemSelectedListener(Runnable callback) { this.callback = callback; }
        @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { callback.run(); }
        @Override public void onNothingSelected(AdapterView<?> parent) {}
    }

    /**
     * One persisted music-library root. `selected` controls whether it participates in the next
     * analysis; `includeSubdirectories` is asked independently for every newly selected root.
     * This is input-selection state only and is intentionally outside Smart/Direct sort logic.
     */
    static final class LibrarySelection {
        final Uri uri;
        boolean selected;
        boolean includeSubdirectories;

        LibrarySelection(Uri uri, boolean selected, boolean includeSubdirectories) {
            this.uri = uri;
            this.selected = selected;
            this.includeSubdirectories = includeSubdirectories;
        }
    }

    static final class AudioFeatures {
        final double rmsDb;
        final double bpm;
        final double activity;
        AudioFeatures(double rmsDb, double bpm, double activity) {
            this.rmsDb = rmsDb;
            this.bpm = bpm;
            this.activity = activity;
        }
    }

    static final class Song {
        final String name;
        final String relativePath;
        final String documentId;
        final Uri uri;
        final long size;
        final long lastModified;
        boolean analyzed;
        boolean fromCache;
        double rmsDb;
        double bpm;
        double activity;
        double energy;
        String title;
        String artist;
        String albumArtist;
        String album;
        String genre;
        int year;
        boolean yearMetadataLoaded;
        String genreSource;
        String artistSource;

        // 3.4.0: embedded-tag presence is tracked separately from effective values/fallbacks.
        boolean embeddedMetadataPresenceLoaded;
        boolean embeddedArtist;
        boolean embeddedAlbumArtist;
        boolean embeddedTitle;
        boolean embeddedAlbum;
        boolean embeddedYear;
        boolean embeddedGenre;

        // Which fields are explicitly controlled by the internal per-song override.
        boolean overrideArtistSet;
        boolean overrideAlbumArtistSet;
        boolean overrideTitleSet;
        boolean overrideAlbumSet;
        boolean overrideYearSet;
        boolean overrideGenreSet;

        Song(String name, String relativePath, String documentId, Uri uri, long size, long lastModified) {
            this.name = name;
            this.relativePath = relativePath;
            this.documentId = documentId;
            this.uri = uri;
            this.size = size;
            this.lastModified = lastModified;
        }

        String displayTitle() {
            return title != null ? title : stripExtension(name);
        }

        String displayTitleWithArtist() {
            String a = artistIdentity();
            return a == null || a.trim().isEmpty() ? displayTitle() : a + " — " + displayTitle();
        }

        void clearOverrideFlags() {
            overrideArtistSet = false;
            overrideAlbumArtistSet = false;
            overrideTitleSet = false;
            overrideAlbumSet = false;
            overrideYearSet = false;
            overrideGenreSet = false;
        }

        String artistIdentity() {
            String aa = trimToNull(albumArtist);
            if (aa != null) {
                String k = normalizeGroup(aa);
                if (!k.equals("various artists") && !k.equals("various") && !k.equals("v a")) return aa;
            }
            return trimToNull(artist);
        }

        private String artistKeyCache;
        private String genreKeyCache;
        private String albumKeyCache;
        private String titleFamilyKeyCache;

        void invalidateScheduleKeys() {
            artistKeyCache = null;
            genreKeyCache = null;
            albumKeyCache = null;
            titleFamilyKeyCache = null;
        }

        void refreshScheduleKeys() {
            artistKeyCache = normalizeArtistKey(artistIdentity(), displayTitle());
            genreKeyCache = normalizeGroup(genre);
            String a = normalizeGroup(album);
            albumKeyCache = a.isEmpty() ? "" : artistKeyCache + "|" + a;
            titleFamilyKeyCache = titleFamily(displayTitle());
        }

        String artistKey() { if (artistKeyCache == null) refreshScheduleKeys(); return artistKeyCache; }
        String genreKey() { if (genreKeyCache == null) refreshScheduleKeys(); return genreKeyCache; }
        String albumKey() { if (albumKeyCache == null) refreshScheduleKeys(); return albumKeyCache; }
        String titleFamilyKey() { if (titleFamilyKeyCache == null) refreshScheduleKeys(); return titleFamilyKeyCache; }
        String cacheKey() { return sha256(documentId); }
    }

    static final class Placement {
        final int target;
        final Song song;
        Placement(int target, Song song) {
            this.target = target;
            this.song = song;
        }
    }

    static final class ScheduleStats {
        final Map<String, Integer> artistCounts = new HashMap<>();
        final Map<String, Integer> genreCounts = new HashMap<>();
        final Map<String, Integer> albumCounts = new HashMap<>();
        final Map<String, Integer> titleCounts = new HashMap<>();
        ScheduleStats(List<Song> songs) {
            for (Song s : songs) {
                incrementKey(artistCounts, s.artistKey());
                incrementKey(genreCounts, s.genreKey());
                incrementKey(albumCounts, s.albumKey());
                incrementKey(titleCounts, s.titleFamilyKey());
            }
        }
    }

    static final class ScheduleState {
        final Map<String, Integer> artistUsed = new HashMap<>();
        final Map<String, Integer> genreUsed = new HashMap<>();
        final Map<String, Integer> albumUsed = new HashMap<>();
        final Map<String, Integer> titleUsed = new HashMap<>();
        final Map<String, Integer> artistLast = new HashMap<>();
        final Map<String, Integer> genreLast = new HashMap<>();
        final Map<String, Integer> albumLast = new HashMap<>();
        final Map<String, Integer> titleLast = new HashMap<>();

        void record(Song s, int pos) {
            recordKey(s.artistKey(), pos, artistUsed, artistLast);
            recordKey(s.genreKey(), pos, genreUsed, genreLast);
            recordKey(s.albumKey(), pos, albumUsed, albumLast);
            recordKey(s.titleFamilyKey(), pos, titleUsed, titleLast);
        }

        private void recordKey(String key, int pos, Map<String, Integer> used, Map<String, Integer> last) {
            if (key == null || key.isEmpty()) return;
            used.put(key, used.containsKey(key) ? used.get(key) + 1 : 1);
            last.put(key, pos);
        }
    }
}
