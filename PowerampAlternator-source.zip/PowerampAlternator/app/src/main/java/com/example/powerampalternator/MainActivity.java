package com.example.powerampalternator;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Main screen and playlist engine.
 *
 * EN: Owns the programmatic GUI, music scan/analysis helpers, metadata cache and the
 * deterministic playlist scheduler. Long-running work itself is executed by
 * BackgroundWorkService so the Activity may leave the foreground safely.
 * HE: מנהל את ממשק המשתמש, סריקה/ניתוח, מטמון metadata ואת מנוע סידור הפלייליסט
 * הדטרמיניסטי. העבודה הארוכה מתבצעת בשירות הרקע כדי שהמסך יוכל להיסגר בבטחה.
 */
public class MainActivity extends Activity {
    private static final int PICK_TREE = 1001;
    private static final String PREFS = "prefs";
    private static final String PREF_TREE_URI = "tree_uri";
    private static final String PREF_MODE = "mode_index";
    private static final String PREF_PLAYLIST_NAME = "playlist_name";
    private static final String PREF_ANALYSIS_REPORT = "analysis_report_enabled";
    private static final String PREF_FILTER_MODE = "filter_mode";
    private static final String PREF_FILTER_ARTIST = "filter_artist";
    private static final String PREF_FILTER_GENRE = "filter_genre";
    private static final String CACHE_PREFIX = "cache_song_";
    private static final String OVERRIDE_PREFIX = "override_song_";
    private static final int CACHE_VERSION = 2;
    static final double BALANCED_ENERGY_THRESHOLD = 0.50;
    private static final String DEFAULT_PLAYLIST_NAME = "Playlist_Maker.m3u8";

    // 3.1.0 visual system: dark cards with a restrained violet accent.
    // The app is a playlist builder, not a player; no playback controls are introduced.
    private static final int UI_BG = Color.rgb(7, 8, 12);
    private static final int UI_CARD = Color.rgb(20, 21, 27);
    private static final int UI_SURFACE = Color.rgb(27, 28, 36);
    private static final int UI_BORDER = Color.rgb(43, 44, 55);
    private static final int UI_TEXT = Color.rgb(247, 247, 250);
    private static final int UI_MUTED = Color.rgb(166, 166, 178);
    private static final int UI_ACCENT = Color.rgb(124, 116, 255);
    private static final int UI_ACCENT_SOFT = Color.rgb(74, 69, 145);

    static final int FILTER_ALL = 0;
    static final int FILTER_ARTIST = 1;
    static final int FILTER_GENRE = 2;
    static final int FILTER_ARTIST_GENRE = 3;

    private String tr(String he, String en) {
        return AppLanguage.text(this, he, en);
    }

    private static String tr(Context context, String he, String en) {
        return AppLanguage.text(context, he, en);
    }

    private final Handler main = new Handler(Looper.getMainLooper());

    private static volatile boolean sharedBusy = false;
    private static volatile int sharedProgress = 0;
    private static volatile String sharedStatus = "";

    private Uri treeUri;
    private TextView folderText;
    private TextView statusText;
    private TextView resultText;
    private TextView flowHelpText;
    private TextView powerampHelpText;
    private ProgressBar progressBar;
    private Button analyzeButton;
    private Button createButton;
    private Button editMetadataButton;
    private Button powerampButton;
    private CheckBox analysisReportCheckBox;
    private Spinner modeSpinner;
    private EditText playlistNameEdit;

    // ======================== FILTER GUI - START ========================
    // EN: Filtering is applied before the existing smart scheduler. The scheduler itself
    // remains unchanged and receives only the selected subset.
    // HE: הסינון מתבצע לפני המתזמן החכם הקיים. המתזמן עצמו אינו משתנה ומקבל רק
    // את קבוצת השירים שנבחרה.
    private int selectedFilterMode = FILTER_ALL;
    private final Button[] filterModeButtons = new Button[4];
    private LinearLayout artistFilterContainer;
    private LinearLayout genreFilterContainer;
    private Spinner artistFilterSpinner;
    private Spinner genreFilterSpinner;
    private TextView filterCountText;
    private boolean filterOptionsUpdating = false;
    // ========================= FILTER GUI - END =========================

    private static final List<Song> analyzedSongs = new ArrayList<>();
    private static int lastSkipped = 0;
    private static int lastCacheHits = 0;
    private static int lastAppliedAnalysisRevision = -1;
    private static long lastOperationDurationMs = 0L;

    private final Runnable uiStatePoller = new Runnable() {
        @Override public void run() {
            syncUiFromSharedState();
            main.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(UI_BG);
        getWindow().setNavigationBarColor(UI_BG);
        buildUi();
        restoreSettings();
        restoreFolder();
        refreshFilterOptions();
        syncUiFromSharedState();
    }

    @Override
    protected void onResume() {
        super.onResume();
        main.removeCallbacks(uiStatePoller);
        main.post(uiStatePoller);
    }

    @Override
    protected void onPause() {
        main.removeCallbacks(uiStatePoller);
        super.onPause();
    }

    private void syncUiFromSharedState() {
        if (statusText == null || progressBar == null) return;

        BackgroundWorkService.State serviceState = BackgroundWorkService.getState(getApplicationContext());
        sharedBusy = serviceState.busy;
        sharedProgress = serviceState.progress;
        lastOperationDurationMs = serviceState.lastDurationMs;
        if (!serviceState.status.isEmpty()) sharedStatus = serviceState.status;

        if (serviceState.analysisReady && serviceState.analysisRevision != lastAppliedAnalysisRevision) {
            List<Song> restored = BackgroundWorkService.getAnalysisSnapshot(getApplicationContext());
            if (restored.size() >= 2) {
                analyzedSongs.clear();
                analyzedSongs.addAll(restored);
                lastSkipped = serviceState.skipped;
                lastCacheHits = serviceState.cacheHits;
                lastAppliedAnalysisRevision = serviceState.analysisRevision;
                refreshFilterOptions();
                if (!sharedBusy && resultText != null && serviceState.resultText.isEmpty()) {
                    showAnalysisSummary();
                }
            }
        }

        if (!sharedStatus.isEmpty()) statusText.setText(sharedStatus);
        if (resultText != null && !serviceState.resultText.isEmpty()) {
            resultText.setText(serviceState.resultText);
        }
        if (sharedBusy) {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(sharedProgress);
        } else {
            progressBar.setVisibility(View.GONE);
        }
        if (analyzeButton != null) analyzeButton.setEnabled(!sharedBusy && treeUri != null);
        if (createButton != null) createButton.setEnabled(!sharedBusy && canCreatePlaylist());
        if (editMetadataButton != null) editMetadataButton.setEnabled(!sharedBusy && !analyzedSongs.isEmpty());
        if (powerampButton != null) powerampButton.setVisibility(serviceState.playlistReady ? View.VISIBLE : View.GONE);
        if (powerampHelpText != null) powerampHelpText.setVisibility(serviceState.playlistReady ? View.VISIBLE : View.GONE);
    }

    // ========================= GUI BUILD - START =========================
    // EN: 3.1.0 keeps the application focused on playlist creation. The visual language is
    // inspired by modern dark audio software (rounded cards, clear hierarchy, violet accent)
    // but it does not copy a player screen and intentionally contains no playback controls.
    // HE: גרסה 3.1.0 משאירה את האפליקציה ככלי ליצירת פלייליסטים בלבד. השפה הגרפית
    // משתמשת בכרטיסים כהים, היררכיה ברורה והדגשה סגולה, ללא מסכי נגן או פקדי נגינה.
    private void buildUi() {
        final boolean hebrewUi = AppLanguage.isHebrew(this);
        final int uiDirection = hebrewUi ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR;

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI_BG);
        scroll.setLayoutDirection(uiDirection);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(34));
        root.setLayoutDirection(uiDirection);
        root.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        root.setBackgroundColor(UI_BG);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        // Header: product name + compact language choice.
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setLayoutDirection(uiDirection);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = makeInfoText("Playlist Maker", 31);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(UI_TEXT);
        titles.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView subtitle = makeInfoText(tr("בניית פלייליסטים חכמה מהספרייה המקומית", "Smart playlist building from your local library"), 13);
        subtitle.setTextColor(UI_MUTED);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(2);
        titles.addView(subtitle, subLp);
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout languageBox = new LinearLayout(this);
        languageBox.setOrientation(LinearLayout.HORIZONTAL);
        languageBox.setGravity(Gravity.CENTER);
        Button heButton = makePillButton("עברית", hebrewUi);
        Button enButton = makePillButton("EN", !hebrewUi);
        heButton.setOnClickListener(v -> {
            if (!AppLanguage.isHebrew(this)) {
                AppLanguage.setLanguage(this, AppLanguage.HEBREW);
                recreate();
            }
        });
        enButton.setOnClickListener(v -> {
            if (AppLanguage.isHebrew(this)) {
                AppLanguage.setLanguage(this, AppLanguage.ENGLISH);
                recreate();
            }
        });
        languageBox.addView(heButton, compactButtonParams());
        LinearLayout.LayoutParams enLp = compactButtonParams();
        enLp.setMarginStart(dp(6));
        languageBox.addView(enButton, enLp);
        header.addView(languageBox, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams headerLp = new LinearLayout.LayoutParams(-1, -2);
        headerLp.bottomMargin = dp(16);
        root.addView(header, headerLp);

        // Step 1 — Library source.
        LinearLayout libraryCard = makeCard();
        addStepHeader(libraryCard, "1", tr("ספריית מוזיקה", "Music library"),
                tr("בחר את התיקייה לניתוח ולשמירת הפלייליסט", "Choose the folder to analyze and save playlists into"));
        Button folderButton = makeButton(tr("▣  בחר תיקיית מוזיקה", "▣  Choose music folder"));
        folderButton.setOnClickListener(v -> chooseFolder());
        libraryCard.addView(folderButton, buttonParams(10));
        folderText = makeInfoText(tr("לא נבחרה תיקייה", "No folder selected"), 13);
        folderText.setTextColor(UI_MUTED);
        folderText.setBackground(roundedDrawable(UI_SURFACE, 14, UI_BORDER, 1));
        folderText.setPadding(dp(13), dp(11), dp(13), dp(11));
        libraryCard.addView(folderText, buttonParams(8));
        root.addView(libraryCard, cardParams());

        // Step 2 — Analysis.
        LinearLayout analysisCard = makeCard();
        addStepHeader(analysisCard, "2", tr("ניתוח הספרייה", "Library analysis"),
                tr("קורא תגיות ומנתח קצב, עוצמה ואופי. העבודה ממשיכה ברקע.",
                        "Reads tags and analyzes tempo, loudness and character. Work continues in background."));
        analyzeButton = makeButton(tr("✦  סרוק ונתח את הספרייה", "✦  Scan and analyze library"));
        analyzeButton.setEnabled(false);
        analyzeButton.setOnClickListener(v -> analyzeLibrary());
        analysisCard.addView(analyzeButton, buttonParams(10));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        if (Build.VERSION.SDK_INT >= 21) {
            progressBar.setProgressTintList(ColorStateList.valueOf(UI_ACCENT));
            progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(UI_BORDER));
        }
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-1, dp(6));
        progressLp.topMargin = dp(12);
        analysisCard.addView(progressBar, progressLp);

        statusText = makeInfoText(tr("מוכן. בחר תיקייה והתחל ניתוח.", "Ready. Choose a folder and start analysis."), 13);
        statusText.setTextColor(UI_MUTED);
        statusText.setBackground(roundedDrawable(UI_SURFACE, 14, UI_BORDER, 1));
        statusText.setPadding(dp(13), dp(11), dp(13), dp(11));
        analysisCard.addView(statusText, buttonParams(9));
        root.addView(analysisCard, cardParams());

        // Step 3 — Filter before scheduling.
        LinearLayout filterCard = makeCard();
        addStepHeader(filterCard, "3", tr("סינון הפלייליסט", "Playlist filter"),
                tr("הסינון מתבצע לפני האלגוריתם החכם ואינו משנה אותו.",
                        "Filtering happens before the smart scheduler and does not change it."));

        LinearLayout filterRow1 = new LinearLayout(this);
        filterRow1.setOrientation(LinearLayout.HORIZONTAL);
        filterRow1.setLayoutDirection(uiDirection);
        LinearLayout filterRow2 = new LinearLayout(this);
        filterRow2.setOrientation(LinearLayout.HORIZONTAL);
        filterRow2.setLayoutDirection(uiDirection);

        filterModeButtons[FILTER_ALL] = makeFilterChoiceButton(FILTER_ALL, tr("♫\nכל השירים", "♫\nAll songs"));
        filterModeButtons[FILTER_ARTIST] = makeFilterChoiceButton(FILTER_ARTIST, tr("●\nאמן", "●\nArtist"));
        filterModeButtons[FILTER_GENRE] = makeFilterChoiceButton(FILTER_GENRE, tr("◆\nGenre", "◆\nGenre"));
        filterModeButtons[FILTER_ARTIST_GENRE] = makeFilterChoiceButton(FILTER_ARTIST_GENRE, tr("● + ◆\nאמן + Genre", "● + ◆\nArtist + Genre"));
        filterRow1.addView(filterModeButtons[FILTER_ALL], choiceParams());
        LinearLayout.LayoutParams choiceGap1 = choiceParams();
        choiceGap1.setMarginStart(dp(8));
        filterRow1.addView(filterModeButtons[FILTER_ARTIST], choiceGap1);
        filterRow2.addView(filterModeButtons[FILTER_GENRE], choiceParams());
        LinearLayout.LayoutParams choiceGap2 = choiceParams();
        choiceGap2.setMarginStart(dp(8));
        filterRow2.addView(filterModeButtons[FILTER_ARTIST_GENRE], choiceGap2);
        filterCard.addView(filterRow1, buttonParams(10));
        filterCard.addView(filterRow2, buttonParams(8));

        artistFilterContainer = makeSelectorContainer(tr("אמן", "Artist"));
        artistFilterSpinner = makeDarkSpinner();
        artistFilterSpinner.setAdapter(darkSpinnerAdapter(Collections.singletonList(tr("יש לבצע ניתוח תחילה", "Analyze the library first"))));
        artistFilterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!filterOptionsUpdating) {
                    saveSettings();
                    updateFilterCount();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        artistFilterContainer.addView(artistFilterSpinner, buttonParams(5));
        filterCard.addView(artistFilterContainer, buttonParams(9));

        genreFilterContainer = makeSelectorContainer("Genre");
        genreFilterSpinner = makeDarkSpinner();
        genreFilterSpinner.setAdapter(darkSpinnerAdapter(Collections.singletonList(tr("יש לבצע ניתוח תחילה", "Analyze the library first"))));
        genreFilterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!filterOptionsUpdating) {
                    saveSettings();
                    updateFilterCount();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        genreFilterContainer.addView(genreFilterSpinner, buttonParams(5));
        filterCard.addView(genreFilterContainer, buttonParams(7));

        filterCountText = makeInfoText(tr("לא נותחה עדיין ספרייה.", "Library has not been analyzed yet."), 12);
        filterCountText.setTextColor(UI_MUTED);
        filterCard.addView(filterCountText, buttonParams(8));
        root.addView(filterCard, cardParams());

        // Step 4 — Flow and playlist output.
        LinearLayout playlistCard = makeCard();
        addStepHeader(playlistCard, "4", tr("סידור ויצירה", "Flow & create"),
                tr("בחר זרימה, שם קובץ וצור M3U8 ל-Poweramp.", "Choose flow, file name and create an M3U8 for Poweramp."));

        TextView modeLabel = makeLabel(tr("זרימת הפלייליסט", "Playlist flow"));
        playlistCard.addView(modeLabel, buttonParams(5));
        modeSpinner = makeDarkSpinner();
        List<String> modes = Arrays.asList(tr("מאוזן", "Balanced"), tr("מתגבר", "Rising"), tr("יורד", "Falling"));
        modeSpinner.setAdapter(darkSpinnerAdapter(modes));
        modeSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(() -> {
            updateFlowHelp();
            saveSettings();
        }));
        playlistCard.addView(modeSpinner, buttonParams(5));

        flowHelpText = makeInfoText("", 12);
        flowHelpText.setTextColor(UI_MUTED);
        playlistCard.addView(flowHelpText, buttonParams(4));
        updateFlowHelp();

        TextView nameLabel = makeLabel(tr("שם הפלייליסט", "Playlist name"));
        playlistCard.addView(nameLabel, buttonParams(11));
        playlistNameEdit = new EditText(this);
        playlistNameEdit.setSingleLine(true);
        playlistNameEdit.setHint(tr("לדוגמה: My Playlist", "Example: My Playlist"));
        playlistNameEdit.setHintTextColor(UI_MUTED);
        playlistNameEdit.setTextColor(UI_TEXT);
        playlistNameEdit.setText(DEFAULT_PLAYLIST_NAME);
        playlistNameEdit.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        playlistNameEdit.setBackground(roundedDrawable(UI_SURFACE, 14, UI_BORDER, 1));
        playlistNameEdit.setPadding(dp(14), dp(11), dp(14), dp(11));
        playlistCard.addView(playlistNameEdit, buttonParams(5));

        analysisReportCheckBox = new CheckBox(this);
        analysisReportCheckBox.setText(tr("צור גם קובץ בדיקה analysis.txt", "Also create analysis.txt diagnostic file"));
        analysisReportCheckBox.setChecked(true);
        analysisReportCheckBox.setTextColor(UI_TEXT);
        analysisReportCheckBox.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        if (Build.VERSION.SDK_INT >= 21) analysisReportCheckBox.setButtonTintList(ColorStateList.valueOf(UI_ACCENT));
        analysisReportCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> saveSettings());
        playlistCard.addView(analysisReportCheckBox, buttonParams(8));

        createButton = makePrimaryButton(tr("✦  צור פלייליסט", "✦  Generate playlist"));
        createButton.setEnabled(false);
        createButton.setOnClickListener(v -> createPlaylistFromAnalysis());
        playlistCard.addView(createButton, buttonParams(12));

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setLayoutDirection(uiDirection);
        editMetadataButton = makeButton(tr("עריכת פרטים", "Edit metadata"));
        editMetadataButton.setEnabled(false);
        editMetadataButton.setOnClickListener(v -> showMetadataEditor());
        tools.addView(editMetadataButton, choiceParams());
        Button clearCacheButton = makeButton(tr("נקה מטמון", "Clear cache"));
        clearCacheButton.setOnClickListener(v -> confirmClearCache());
        LinearLayout.LayoutParams clearLp = choiceParams();
        clearLp.setMarginStart(dp(8));
        tools.addView(clearCacheButton, clearLp);
        playlistCard.addView(tools, buttonParams(8));

        powerampButton = makeButton(tr("פתח Poweramp", "Open Poweramp"));
        powerampButton.setVisibility(View.GONE);
        powerampButton.setOnClickListener(v -> openPoweramp());
        playlistCard.addView(powerampButton, buttonParams(8));
        powerampHelpText = makeInfoText(tr("פתח את Poweramp לביצוע Rescan או לשימוש בפלייליסט החדש.",
                "Open Poweramp to Rescan or use the new playlist."), 12);
        powerampHelpText.setTextColor(UI_MUTED);
        powerampHelpText.setVisibility(View.GONE);
        playlistCard.addView(powerampHelpText, buttonParams(3));
        root.addView(playlistCard, cardParams());

        // Step 5 — Results.
        LinearLayout resultsCard = makeCard();
        addStepHeader(resultsCard, "5", tr("תוצאות", "Results"),
                tr("מספר שירים, זמן עבודה ונתוני פיזור.", "Song count, duration and distribution diagnostics."));
        resultText = makeInfoText(tr("עדיין אין תוצאות להצגה.", "No results yet."), 13);
        resultText.setTextIsSelectable(true);
        resultText.setTextColor(UI_TEXT);
        resultText.setBackground(roundedDrawable(UI_SURFACE, 14, UI_BORDER, 1));
        resultText.setPadding(dp(13), dp(12), dp(13), dp(12));
        resultsCard.addView(resultText, buttonParams(7));
        root.addView(resultsCard, cardParams());

        TextView version = makeInfoText(tr("גרסה 3.1.0", "Version 3.1.0"), 11);
        version.setTextColor(UI_MUTED);
        version.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams versionLp = new LinearLayout.LayoutParams(-1, -2);
        versionLp.topMargin = dp(10);
        root.addView(version, versionLp);

        setContentView(scroll);
        updateFilterUi();
    }
    // ========================== GUI BUILD - END ==========================

    private LinearLayout makeCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(16));
        card.setBackground(roundedDrawable(UI_CARD, 22, UI_BORDER, 1));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(2));
        return card;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        return lp;
    }

    private void addStepHeader(LinearLayout card, String step, String title, String subtitle) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(card.getLayoutDirection());

        TextView badge = makeInfoText(step, 13);
        badge.setGravity(Gravity.CENTER);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setTextColor(UI_TEXT);
        badge.setBackground(roundedDrawable(UI_ACCENT_SOFT, 999, UI_ACCENT, 1));
        row.addView(badge, new LinearLayout.LayoutParams(dp(34), dp(34)));

        LinearLayout textBox = new LinearLayout(this);
        textBox.setOrientation(LinearLayout.VERTICAL);
        TextView heading = makeInfoText(title, 19);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setTextColor(UI_TEXT);
        textBox.addView(heading);
        TextView sub = makeInfoText(subtitle, 12);
        sub.setTextColor(UI_MUTED);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(2);
        textBox.addView(sub, subLp);
        LinearLayout.LayoutParams boxLp = new LinearLayout.LayoutParams(0, -2, 1f);
        boxLp.setMarginStart(dp(11));
        row.addView(textBox, boxLp);
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(UI_TEXT);
        b.setTextSize(14);
        b.setMinHeight(dp(48));
        b.setPadding(dp(13), dp(9), dp(13), dp(9));
        b.setBackground(roundedDrawable(UI_SURFACE, 15, UI_BORDER, 1));
        return b;
    }

    private Button makePrimaryButton(String text) {
        Button b = makeButton(text);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(roundedDrawable(UI_ACCENT_SOFT, 17, UI_ACCENT, 1));
        b.setMinHeight(dp(56));
        return b;
    }

    private Button makePillButton(String text, boolean selected) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setPadding(dp(10), dp(5), dp(10), dp(5));
        b.setTextColor(selected ? UI_TEXT : UI_MUTED);
        b.setBackground(roundedDrawable(selected ? UI_ACCENT_SOFT : UI_SURFACE, 999,
                selected ? UI_ACCENT : UI_BORDER, 1));
        return b;
    }

    private LinearLayout.LayoutParams compactButtonParams() {
        return new LinearLayout.LayoutParams(-2, dp(38));
    }

    private Button makeFilterChoiceButton(int mode, String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setTextSize(13);
        b.setMinHeight(dp(76));
        b.setOnClickListener(v -> {
            selectedFilterMode = mode;
            updateFilterUi();
            saveSettings();
            updateFilterCount();
        });
        return b;
    }

    private LinearLayout.LayoutParams choiceParams() {
        return new LinearLayout.LayoutParams(0, -2, 1f);
    }

    private LinearLayout makeSelectorContainer(String labelText) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView label = makeLabel(labelText);
        box.addView(label, new LinearLayout.LayoutParams(-1, -2));
        return box;
    }

    private Spinner makeDarkSpinner() {
        Spinner spinner = new Spinner(this);
        spinner.setPadding(dp(12), dp(4), dp(12), dp(4));
        spinner.setBackground(roundedDrawable(UI_SURFACE, 14, UI_BORDER, 1));
        if (Build.VERSION.SDK_INT >= 16) spinner.setPopupBackgroundDrawable(roundedDrawable(UI_CARD, 12, UI_BORDER, 1));
        return spinner;
    }

    private ArrayAdapter<String> darkSpinnerAdapter(List<String> items) {
        return new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(UI_TEXT);
                v.setTextSize(14);
                v.setPadding(dp(8), dp(8), dp(8), dp(8));
                return v;
            }
            @Override public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getDropDownView(position, convertView, parent);
                v.setTextColor(UI_TEXT);
                v.setBackgroundColor(UI_CARD);
                v.setTextSize(14);
                v.setPadding(dp(14), dp(12), dp(14), dp(12));
                return v;
            }
        };
    }

    private TextView makeInfoText(String text, float sizeSp) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sizeSp);
        view.setTextColor(UI_TEXT);
        view.setGravity(Gravity.START);
        view.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        return view;
    }

    private TextView makeLabel(String text) {
        TextView view = makeInfoText(text, 14);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setTextColor(UI_TEXT);
        return view;
    }

    private LinearLayout.LayoutParams buttonParams(int topMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(topMarginDp);
        return lp;
    }

    private GradientDrawable roundedDrawable(int fillColor, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private void updateFilterUi() {
        if (artistFilterContainer == null || genreFilterContainer == null) return;
        for (int i = 0; i < filterModeButtons.length; i++) {
            Button b = filterModeButtons[i];
            if (b == null) continue;
            boolean selected = i == selectedFilterMode;
            b.setTextColor(selected ? UI_TEXT : UI_MUTED);
            b.setBackground(roundedDrawable(selected ? UI_ACCENT_SOFT : UI_SURFACE,
                    16, selected ? UI_ACCENT : UI_BORDER, selected ? 2 : 1));
        }
        artistFilterContainer.setVisibility(
                selectedFilterMode == FILTER_ARTIST || selectedFilterMode == FILTER_ARTIST_GENRE
                        ? View.VISIBLE : View.GONE);
        genreFilterContainer.setVisibility(
                selectedFilterMode == FILTER_GENRE || selectedFilterMode == FILTER_ARTIST_GENRE
                        ? View.VISIBLE : View.GONE);
        updateFilterCount();
    }

    private void refreshFilterOptions() {
        if (artistFilterSpinner == null || genreFilterSpinner == null) return;
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String wantedArtist = p.getString(PREF_FILTER_ARTIST, "");
        String wantedGenre = p.getString(PREF_FILTER_GENRE, "");

        Map<String, String> artistLabelsByKey = new HashMap<>();
        Map<String, String> genreLabelsByKey = new HashMap<>();
        for (Song song : analyzedSongs) {
            song.refreshScheduleKeys();
            String artistKey = song.artistKey();
            String artistLabel = filterArtistDisplay(song);
            if (!artistKey.isEmpty() && artistLabel != null) {
                String old = artistLabelsByKey.get(artistKey);
                if (old == null || artistLabel.length() < old.length()) artistLabelsByKey.put(artistKey, artistLabel);
            }
            if (isFilterableGenre(song.genre)) {
                String genreKey = song.genreKey();
                if (!genreKey.isEmpty() && !genreLabelsByKey.containsKey(genreKey)) genreLabelsByKey.put(genreKey, song.genre);
            }
        }

        List<String> artists = new ArrayList<>(artistLabelsByKey.values());
        List<String> genres = new ArrayList<>(genreLabelsByKey.values());
        artists.sort(String.CASE_INSENSITIVE_ORDER);
        genres.sort(String.CASE_INSENSITIVE_ORDER);

        filterOptionsUpdating = true;
        artistFilterSpinner.setAdapter(darkSpinnerAdapter(artists.isEmpty()
                ? Collections.singletonList(tr("לא נמצאו אמנים", "No artists found")) : artists));
        genreFilterSpinner.setAdapter(darkSpinnerAdapter(genres.isEmpty()
                ? Collections.singletonList(tr("לא נמצאו Genres", "No genres found")) : genres));
        selectSpinnerText(artistFilterSpinner, wantedArtist);
        selectSpinnerText(genreFilterSpinner, wantedGenre);
        filterOptionsUpdating = false;
        updateFilterCount();
    }

    private void selectSpinnerText(Spinner spinner, String wanted) {
        if (spinner == null || wanted == null || wanted.trim().isEmpty() || spinner.getAdapter() == null) return;
        for (int i = 0; i < spinner.getAdapter().getCount(); i++) {
            Object item = spinner.getAdapter().getItem(i);
            if (item != null && wanted.equalsIgnoreCase(item.toString())) {
                spinner.setSelection(i);
                return;
            }
        }
    }

    private static String filterArtistDisplay(Song song) {
        String identity = trimToNull(song.artistIdentity());
        String titlePrefix = titleArtistPrefix(song.displayTitle());
        if (titlePrefix != null && normalizeArtistKey(titlePrefix, "").equals(song.artistKey())) return titlePrefix;
        return identity;
    }

    private static boolean isFilterableGenre(String genre) {
        String key = normalizeGroup(genre);
        if (key.isEmpty()) return false;
        return !key.equals("unknown") && !key.equals("music") && !key.equals("people blogs")
                && !key.equals("people & blogs");
    }

    private String selectedArtistFilter() {
        Object value = artistFilterSpinner == null ? null : artistFilterSpinner.getSelectedItem();
        return value == null ? "" : value.toString();
    }

    private String selectedGenreFilter() {
        Object value = genreFilterSpinner == null ? null : genreFilterSpinner.getSelectedItem();
        return value == null ? "" : value.toString();
    }

    private int filteredSongCount() {
        return filterSongsForPlaylist(analyzedSongs, selectedFilterMode,
                selectedArtistFilter(), selectedGenreFilter()).size();
    }

    private boolean canCreatePlaylist() {
        return treeUri != null && analyzedSongs.size() >= 2 && filteredSongCount() >= 2;
    }

    private void updateFilterCount() {
        if (filterCountText == null) return;
        if (analyzedSongs.isEmpty()) {
            filterCountText.setText(tr("לא נותחה עדיין ספרייה.", "Library has not been analyzed yet."));
        } else {
            int count = filteredSongCount();
            filterCountText.setText(tr("תוצאת הסינון: ", "Filter result: ") + count
                    + tr(" שירים מתוך ", " songs out of ") + analyzedSongs.size());
        }
        if (createButton != null) {
            BackgroundWorkService.State state = BackgroundWorkService.getState(getApplicationContext());
            createButton.setEnabled(!state.busy && canCreatePlaylist());
        }
    }

    // ======================== FILTER PIPELINE - START ========================
    // EN: Returns a new list containing only songs selected by the user. This is the only
    // 3.1.0 change in the playlist data path: FILTER -> existing deterministic scheduler.
    // Artist matching uses the same normalized scheduling key; Genre uses reliable metadata
    // already stored on Song and never guesses a Genre from audio.
    // HE: מחזיר רשימה חדשה המכילה רק את השירים שנבחרו. זהו השינוי היחיד בנתיב הנתונים:
    // סינון -> האלגוריתם הדטרמיניסטי הקיים. התאמת אמן משתמשת באותו מפתח מנורמל,
    // ו-Genre נלקח מה-metadata הקיים בלבד ללא ניחוש מאודיו.
    static List<Song> filterSongsForPlaylist(List<Song> source, int filterMode,
                                             String artistFilter, String genreFilter) {
        List<Song> result = new ArrayList<>();
        if (source == null) return result;
        int mode = clampInt(filterMode, FILTER_ALL, FILTER_ARTIST_GENRE);
        String wantedArtist = normalizeArtistKey(artistFilter, "");
        String wantedGenre = normalizeGroup(genreFilter);
        for (Song song : source) {
            song.refreshScheduleKeys();
            boolean artistOk = mode != FILTER_ARTIST && mode != FILTER_ARTIST_GENRE
                    || (!wantedArtist.isEmpty() && song.artistKey().equals(wantedArtist));
            boolean genreOk = mode != FILTER_GENRE && mode != FILTER_ARTIST_GENRE
                    || (!wantedGenre.isEmpty() && song.genreKey().equals(wantedGenre));
            if (artistOk && genreOk) result.add(song);
        }
        return result;
    }

    static String filterDescription(Context context, int filterMode, String artistFilter, String genreFilter) {
        int mode = clampInt(filterMode, FILTER_ALL, FILTER_ARTIST_GENRE);
        if (mode == FILTER_ARTIST) {
            return tr(context, "אמן: ", "Artist: ") + artistFilter;
        } else if (mode == FILTER_GENRE) {
            return "Genre: " + genreFilter;
        } else if (mode == FILTER_ARTIST_GENRE) {
            return tr(context, "אמן: ", "Artist: ") + artistFilter + " | Genre: " + genreFilter;
        }
        return tr(context, "כל השירים", "All songs");
    }
    // ========================= FILTER PIPELINE - END =========================

    private void updateFlowHelp() {
        if (flowHelpText == null || modeSpinner == null) return;
        int mode = modeSpinner.getSelectedItemPosition();
        if (mode == 1) {
            flowHelpText.setText(tr("מתחיל רגוע והופך בהדרגה לקצבי יותר.", "Starts calm and gradually becomes more energetic."));
        } else if (mode == 2) {
            flowHelpText.setText(tr("מתחיל קצבי והופך בהדרגה לרגוע יותר.", "Starts energetic and gradually becomes calmer."));
        } else {
            flowHelpText.setText(tr("משלב שירים רגועים וקצביים לאורך הרשימה.", "Mixes calm and energetic songs across the playlist."));
        }
    }

    private void restoreSettings() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        modeSpinner.setSelection(clampInt(p.getInt(PREF_MODE, 0), 0, 2));
        playlistNameEdit.setText(p.getString(PREF_PLAYLIST_NAME, DEFAULT_PLAYLIST_NAME));
        analysisReportCheckBox.setChecked(p.getBoolean(PREF_ANALYSIS_REPORT, true));
        selectedFilterMode = clampInt(p.getInt(PREF_FILTER_MODE, FILTER_ALL), FILTER_ALL, FILTER_ARTIST_GENRE);
        updateFilterUi();
    }

    private void saveSettings() {
        if (modeSpinner == null || playlistNameEdit == null) return;
        SharedPreferences.Editor editor = getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt(PREF_MODE, modeSpinner.getSelectedItemPosition())
                .putString(PREF_PLAYLIST_NAME, playlistNameEdit.getText().toString())
                .putInt(PREF_FILTER_MODE, selectedFilterMode);
        if (artistFilterSpinner != null && artistFilterSpinner.getSelectedItem() != null) {
            editor.putString(PREF_FILTER_ARTIST, selectedArtistFilter());
        }
        if (genreFilterSpinner != null && genreFilterSpinner.getSelectedItem() != null) {
            editor.putString(PREF_FILTER_GENRE, selectedGenreFilter());
        }
        if (analysisReportCheckBox != null) {
            editor.putBoolean(PREF_ANALYSIS_REPORT, analysisReportCheckBox.isChecked());
        }
        editor.apply();
    }

    private void restoreFolder() {
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_TREE_URI, null);
        if (saved == null) return;
        Uri candidate = Uri.parse(saved);
        boolean stillGranted = false;
        for (UriPermission p : getContentResolver().getPersistedUriPermissions()) {
            if (p.getUri().equals(candidate) && p.isReadPermission()) {
                stillGranted = true;
                break;
            }
        }
        if (stillGranted) {
            treeUri = candidate;
            folderText.setText(tr("תיקייה: ", "Folder: ") + friendlyTreeName(candidate));
            analyzeButton.setEnabled(true);
        }
    }

    private void chooseFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, PICK_TREE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_TREE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri chosen = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(chosen, flags); } catch (SecurityException ignored) {}
        treeUri = chosen;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_TREE_URI, chosen.toString()).apply();
        folderText.setText(tr("תיקייה: ", "Folder: ") + friendlyTreeName(chosen));
        analyzeButton.setEnabled(true);
        analyzedSongs.clear();
        BackgroundWorkService.clearAnalysisSnapshot(getApplicationContext());
        lastAppliedAnalysisRevision = -1;
        createButton.setEnabled(false);
        editMetadataButton.setEnabled(false);
        powerampButton.setVisibility(View.GONE);
        if (powerampHelpText != null) powerampHelpText.setVisibility(View.GONE);
        statusText.setText(tr("מוכן לסריקה.", "Ready to scan."));
        resultText.setText("");
        refreshFilterOptions();
    }

    static String friendlyTreeName(Uri uri) {
        try {
            String id = DocumentsContract.getTreeDocumentId(uri);
            int colon = id.indexOf(':');
            String path = colon >= 0 ? id.substring(colon + 1) : id;
            return path.isEmpty() ? id : path;
        } catch (Exception e) {
            return uri.toString();
        }
    }

    private void analyzeLibrary() {
        if (treeUri == null) return;
        BackgroundWorkService.State state = BackgroundWorkService.getState(getApplicationContext());
        if (state.busy) return;
        saveSettings();
        resultText.setText("");
        analyzedSongs.clear();
        refreshFilterOptions();
        createButton.setEnabled(false);
        editMetadataButton.setEnabled(false);
        powerampButton.setVisibility(View.GONE);
        if (powerampHelpText != null) powerampHelpText.setVisibility(View.GONE);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2002);
        }
        setBusy(true);
        BackgroundWorkService.startAnalysis(getApplicationContext(), treeUri);
        syncUiFromSharedState();
    }

    private void createPlaylistFromAnalysis() {
        if (treeUri == null || analyzedSongs.size() < 2) return;
        BackgroundWorkService.State state = BackgroundWorkService.getState(getApplicationContext());
        if (state.busy) return;
        final String artistFilter = selectedArtistFilter();
        final String genreFilter = selectedGenreFilter();
        List<Song> preview = filterSongsForPlaylist(analyzedSongs, selectedFilterMode, artistFilter, genreFilter);
        if (preview.size() < 2) {
            Toast.makeText(this, tr("הסינון הנוכחי מכיל פחות משני שירים.",
                    "The current filter contains fewer than two songs."), Toast.LENGTH_LONG).show();
            return;
        }
        saveSettings();
        final int mode = modeSpinner.getSelectedItemPosition();
        final String playlistName = normalizedPlaylistName(playlistNameEdit.getText().toString());
        playlistNameEdit.setText(playlistName);
        // Keep the FULL analyzed snapshot. The background service persists the filter
        // separately and applies it immediately before the unchanged scheduler.
        BackgroundWorkService.setAnalysisSnapshot(getApplicationContext(), new ArrayList<>(analyzedSongs), lastSkipped, lastCacheHits);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2002);
        }
        setBusy(true);
        boolean reportEnabled = analysisReportCheckBox != null && analysisReportCheckBox.isChecked();
        BackgroundWorkService.startPlaylist(getApplicationContext(), treeUri, mode, playlistName, reportEnabled,
                selectedFilterMode, artistFilter, genreFilter);
        syncUiFromSharedState();
    }

    private void setBusy(boolean busy) {
        analyzeButton.setEnabled(!busy && treeUri != null);
        createButton.setEnabled(!busy && canCreatePlaylist());
        editMetadataButton.setEnabled(!busy && !analyzedSongs.isEmpty());
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
        if (!busy) progressBar.setProgress(0);
    }

    interface ProgressCallback {
        void onProgress(String text, int percent);
    }

    static final class AnalysisResult {
        final List<Song> songs;
        final int skipped;
        final int cacheHits;
        AnalysisResult(List<Song> songs, int skipped, int cacheHits) {
            this.songs = songs;
            this.skipped = skipped;
            this.cacheHits = cacheHits;
        }
    }

    static final class PlaylistResult {
        final List<Song> playlist;
        final Uri playlistUri;
        final String playlistName;
        final String reportName;
        final String savedAt;
        final String warning;
        PlaylistResult(List<Song> playlist, Uri playlistUri, String playlistName, String reportName,
                       String savedAt, String warning) {
            this.playlist = playlist;
            this.playlistUri = playlistUri;
            this.playlistName = playlistName;
            this.reportName = reportName;
            this.savedAt = savedAt;
            this.warning = warning;
        }
    }

    // ======================= LIBRARY ANALYSIS - START =======================
    // EN: Recursively scans the selected tree, reuses unchanged cached tracks, reads metadata,
    //     analyzes audio features for missing/changed files, then normalizes energy scores.
    // HE: סריקה רקורסיבית, שימוש במטמון לשירים שלא השתנו, קריאת metadata, ניתוח אודיו
    //     לקבצים חדשים/שהשתנו ולבסוף נרמול ציוני האופי.
    static AnalysisResult performAnalysis(Context context, Uri selected, ProgressCallback callback) throws Exception {
        List<Song> songs = new ArrayList<>();
        String rootId = DocumentsContract.getTreeDocumentId(selected);
        scanDirectory(context, selected, rootId, "", songs);
        if (songs.size() < 2) throw new IllegalStateException(tr(context, "נדרשים לפחות שני קובצי מוזיקה בתיקייה שנבחרה.", "At least two music files are required in the selected folder."));

        final int total = songs.size();
        callback.onProgress(tr(context, "נמצאו ", "Found ") + total + tr(context, " שירים. קורא תגיות ומנתח את אופי השירים…", " songs. Reading tags and analyzing song character…"), 2);
        int analyzed = 0;
        int cacheHits = 0;
        for (Song song : songs) {
            try {
                if (loadCachedAnalysis(context, song)) {
                    cacheHits++;
                } else {
                    readMetadata(context, song);
                    AudioFeatures f = analyzeAudio(context, song.uri);
                    song.rmsDb = f.rmsDb;
                    song.bpm = f.bpm;
                    song.activity = f.activity;
                    song.analyzed = true;
                    saveCachedAnalysis(context, song);
                }
                applyManualOverride(context, song);
            } catch (Exception e) {
                song.analyzed = false;
            }
            analyzed++;
            int progress = 2 + (int) (93.0 * analyzed / Math.max(1, total));
            callback.onProgress(tr(context, "מנתח ", "Analyzing ") + analyzed + "/" + total + ": " + song.name + tr(context, "  |  מטמון: ", "  |  cache: ") + cacheHits, progress);
        }

        List<Song> usable = new ArrayList<>();
        for (Song song : songs) if (song.analyzed) usable.add(song);
        if (usable.size() < 2) {
            throw new IllegalStateException(tr(context, "לא הצלחתי לנתח מספיק קובצי אודיו. נסה תיקייה עם MP3/FLAC/M4A רגילים.", "Not enough audio files could be analyzed. Try a folder with standard MP3/FLAC/M4A files."));
        }
        callback.onProgress(tr(context, "מסכם את אופי השירים…", "Finalizing song character scores…"), 97);
        scoreEnergy(usable);
        return new AnalysisResult(usable, songs.size() - usable.size(), cacheHits);
    }
    // ======================== LIBRARY ANALYSIS - END ========================

    // ======================= PLAYLIST CREATION - START =======================
    // EN: Copies the analyzed songs, runs the deterministic smart scheduler, writes M3U8 and
    //     optionally writes the diagnostic report. The source analysis snapshot is not mutated.
    // HE: מעתיק את השירים שנותחו, מפעיל את המתזמן הדטרמיניסטי, כותב M3U8 ובאופן
    //     אופציונלי את קובץ הבדיקה. snapshot המקור אינו משתנה.
    static PlaylistResult performPlaylist(Context context, Uri selected, List<Song> source, int mode,
                                          String requestedPlaylistName, boolean reportEnabled,
                                          String filterDescription, ProgressCallback callback) throws Exception {
        if (source == null || source.size() < 2) {
            throw new IllegalStateException(tr(context, "אין ניתוח שמור שממנו ניתן ליצור פלייליסט.", "No saved analysis is available for playlist creation."));
        }
        final double threshold = BALANCED_ENERGY_THRESHOLD;
        final String playlistName = normalizedPlaylistName(requestedPlaylistName);
        final String reportName = reportEnabled ? analysisReportName(playlistName) : "";
        callback.onProgress(tr(context, "מכין נתוני פיזור…", "Preparing distribution data…"), 1);
        List<Song> copy = new ArrayList<>(source);
        for (Song song : copy) song.refreshScheduleKeys();
        List<Song> playlist = scheduleSmart(context, copy, mode, threshold, callback);
        callback.onProgress(tr(context, "כותב ", "Writing ") + playlistName + "…", 96);
        Uri playlistUri = writePlaylist(context, selected, playlist, playlistName);

        String warning = null;
        if (reportEnabled) {
            callback.onProgress(tr(context, "יוצר קובץ בדיקה ", "Creating diagnostic file ") + reportName + "…", 98);
            try {
                writeAnalysisReport(context, selected, playlist, playlistName, mode, threshold, filterDescription);
            } catch (Exception e) {
                warning = tr(context, "הפלייליסט נוצר, אבל קובץ הבדיקה לא נוצר: ", "The playlist was created, but the diagnostic file could not be created: ") + safeMessage(e);
            }
        } else {
            callback.onProgress(tr(context, "מסיים את יצירת הפלייליסט…", "Finishing playlist creation…"), 98);
        }
        String savedAt = friendlyTreeName(selected) + "/" + playlistName;
        return new PlaylistResult(playlist, playlistUri, playlistName, reportName, savedAt, warning);
    }

    static void scanDirectory(Context context, Uri tree, String parentDocumentId, String relativeDir, List<Song> out) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentDocumentId);
        String[] projection = {
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED
        };
        try (Cursor cursor = resolver.query(children, projection, null, null, null)) {
            if (cursor == null) return;
            int idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            int mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE);
            int sizeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
            int modifiedCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);
            while (cursor.moveToNext()) {
                String id = cursor.getString(idCol);
                String name = cursor.getString(nameCol);
                String mime = cursor.getString(mimeCol);
                long size = sizeCol >= 0 && !cursor.isNull(sizeCol) ? cursor.getLong(sizeCol) : 0L;
                long modified = modifiedCol >= 0 && !cursor.isNull(modifiedCol) ? cursor.getLong(modifiedCol) : 0L;
                if (name == null) name = "unknown";
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    String nextRel = relativeDir.isEmpty() ? name : relativeDir + "/" + name;
                    scanDirectory(context, tree, id, nextRel, out);
                } else if (isAudio(name, mime)) {
                    Uri docUri = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                    String rel = relativeDir.isEmpty() ? name : relativeDir + "/" + name;
                    out.add(new Song(name, rel, id, docUri, size, modified));
                }
            }
        }
    }

    static boolean isAudio(String name, String mime) {
        if (mime != null && mime.startsWith("audio/")) return true;
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".mp3") || lower.endsWith(".flac") || lower.endsWith(".m4a")
                || lower.endsWith(".aac") || lower.endsWith(".ogg") || lower.endsWith(".opus")
                || lower.endsWith(".wav") || lower.endsWith(".wma") || lower.endsWith(".ape")
                || lower.endsWith(".alac") || lower.endsWith(".mka");
    }

    static void readMetadata(Context context, Song song) {
        song.title = null;
        song.artist = null;
        song.albumArtist = null;
        song.album = null;
        song.genre = null;
        song.genreSource = null;
        song.artistSource = null;
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(context, song.uri);
            song.title = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE));
            song.artist = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST));
            song.albumArtist = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST));
            song.album = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM));
            String rawGenre = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE));
            if (rawGenre != null) {
                song.genre = canonicalGenre(rawGenre);
                song.genreSource = "תגית";
            }
        } catch (Exception ignored) {
        } finally {
            try { mmr.release(); } catch (Exception ignored) {}
        }

        parseFilenameFallback(song);
        if (song.genre == null) {
            String trusted = trustedGenreForArtist(song.artistIdentity());
            if (trusted != null) {
                song.genre = trusted;
                song.genreSource = "זיהוי אמן ודאי";
            }
        }
    }

    static void parseFilenameFallback(Song song) {
        String base = stripExtension(song.name);
        if (song.title == null) song.title = base;
        if (song.artist != null) return;
        String[] parts = base.split("\\s+-\\s+");
        if (parts.length == 2 && !parts[0].trim().isEmpty() && !parts[1].trim().isEmpty()) {
            song.artist = parts[0].trim();
            if (song.title == null || song.title.equals(base)) song.title = parts[1].trim();
            song.artistSource = "שם קובץ";
        } else if (parts.length >= 3 && parts[0].trim().matches("\\d{1,3}")) {
            song.artist = parts[1].trim();
            if (!parts[2].trim().isEmpty()) song.title = parts[2].trim();
            song.artistSource = "שם קובץ";
        }
    }

    static String trustedGenreForArtist(String artist) {
        String k = normalizeGroup(artist);
        switch (k) {
            case "glenn miller":
            case "glenn miller orchestra":
            case "benny goodman":
                return "Swing";
            case "miles davis":
            case "john coltrane":
            case "thelonious monk":
            case "dave brubeck":
            case "dave brubeck quartet":
                return "Jazz";
            case "ac dc":
            case "led zeppelin":
            case "deep purple":
            case "rolling stones":
                return "Rock";
            default:
                return null;
        }
    }

    static String canonicalGenre(String raw) {
        if (raw == null) return null;
        String g = raw.toLowerCase(Locale.ROOT);
        if (g.contains("swing")) return "Swing";
        if (g.contains("jazz")) return "Jazz";
        if (g.contains("rock")) return "Rock";
        if (g.contains("blues")) return "Blues";
        if (g.contains("classical") || g.contains("classic")) return "Classical";
        if (g.contains("metal")) return "Metal";
        if (g.contains("country")) return "Country";
        if (g.contains("funk")) return "Funk";
        if (g.contains("soul")) return "Soul";
        if (g.contains("disco")) return "Disco";
        if (g.contains("reggae")) return "Reggae";
        if (g.contains("electro") || g.contains("edm")) return "Electronic";
        if (g.contains("dance")) return "Dance";
        if (g.contains("folk")) return "Folk";
        if (g.contains("hip hop") || g.contains("hip-hop") || g.contains("rap")) return "Hip Hop";
        if (g.contains("pop")) return "Pop";
        String cleaned = raw.trim().replaceAll("\\s+", " ");
        return cleaned.isEmpty() ? null : cleaned;
    }

    static AudioFeatures analyzeAudio(Context context, Uri uri) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec codec = null;
        try {
            extractor.setDataSource(context, uri, null);
            int audioTrack = -1;
            MediaFormat inputFormat = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrack = i;
                    inputFormat = f;
                    break;
                }
            }
            if (audioTrack < 0 || inputFormat == null) throw new IllegalArgumentException(tr(context, "אין ערוץ אודיו", "No audio track found"));

            extractor.selectTrack(audioTrack);
            long durationUs = inputFormat.containsKey(MediaFormat.KEY_DURATION) ? inputFormat.getLong(MediaFormat.KEY_DURATION) : 0L;
            long sampleStartUs = durationUs > 45_000_000L ? Math.min(30_000_000L, durationUs / 5) : 0L;
            long sampleLengthUs = 18_000_000L;
            long sampleEndUs = durationUs > 0 ? Math.min(durationUs, sampleStartUs + sampleLengthUs) : sampleStartUs + sampleLengthUs;
            if (sampleStartUs > 0) extractor.seekTo(sampleStartUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);

            String mime = inputFormat.getString(MediaFormat.KEY_MIME);
            codec = MediaCodec.createDecoderByType(mime);
            codec.configure(inputFormat, null, null, 0);
            codec.start();

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            boolean outputDone = false;
            PcmAnalyzer analyzer = null;
            long wallDeadline = System.currentTimeMillis() + 25_000L;

            while (!outputDone && System.currentTimeMillis() < wallDeadline) {
                if (!inputDone) {
                    int inputIndex = codec.dequeueInputBuffer(10_000);
                    if (inputIndex >= 0) {
                        ByteBuffer inputBuffer = codec.getInputBuffer(inputIndex);
                        if (inputBuffer == null) continue;
                        inputBuffer.clear();
                        long sampleTime = extractor.getSampleTime();
                        if (sampleTime < 0 || sampleTime > sampleEndUs) {
                            codec.queueInputBuffer(inputIndex, 0, 0, Math.max(0, sampleTime), MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            int size = extractor.readSampleData(inputBuffer, 0);
                            if (size < 0) {
                                codec.queueInputBuffer(inputIndex, 0, 0, Math.max(0, sampleTime), MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inputDone = true;
                            } else {
                                codec.queueInputBuffer(inputIndex, 0, size, sampleTime, extractor.getSampleFlags());
                                extractor.advance();
                            }
                        }
                    }
                }

                int outIndex = codec.dequeueOutputBuffer(info, 10_000);
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    analyzer = new PcmAnalyzer(codec.getOutputFormat());
                } else if (outIndex >= 0) {
                    if (analyzer == null) analyzer = new PcmAnalyzer(codec.getOutputFormat());
                    ByteBuffer out = codec.getOutputBuffer(outIndex);
                    if (out != null && info.size > 0) {
                        out.position(info.offset);
                        out.limit(info.offset + info.size);
                        analyzer.consume(out.slice().order(ByteOrder.LITTLE_ENDIAN));
                    }
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true;
                    codec.releaseOutputBuffer(outIndex, false);
                }
            }
            if (analyzer == null || analyzer.sampleCount < 4000) throw new IllegalStateException(tr(context, "אין מספיק PCM", "Not enough PCM audio data"));
            return analyzer.finish();
        } finally {
            try { extractor.release(); } catch (Exception ignored) {}
            if (codec != null) {
                try { codec.stop(); } catch (Exception ignored) {}
                try { codec.release(); } catch (Exception ignored) {}
            }
        }
    }

    private static final class PcmAnalyzer {
        final int sampleRate;
        final int channels;
        final int encoding;
        final int windowSamples;
        final List<Double> envelope = new ArrayList<>();
        double windowSq;
        int windowCount;
        double totalSq;
        long sampleCount;

        PcmAnalyzer(MediaFormat f) {
            sampleRate = f.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? f.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
            channels = f.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? Math.max(1, f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)) : 2;
            int enc = AudioFormat.ENCODING_PCM_16BIT;
            try { if (f.containsKey("pcm-encoding")) enc = f.getInteger("pcm-encoding"); } catch (Exception ignored) {}
            encoding = enc;
            windowSamples = 1024;
        }

        void consume(ByteBuffer b) {
            if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
                while (b.remaining() >= 4 * channels) {
                    double mono = 0;
                    for (int c = 0; c < channels; c++) mono += clamp(b.getFloat());
                    add(mono / channels);
                }
            } else if (encoding == AudioFormat.ENCODING_PCM_8BIT) {
                while (b.remaining() >= channels) {
                    double mono = 0;
                    for (int c = 0; c < channels; c++) mono += ((b.get() & 0xff) - 128) / 128.0;
                    add(mono / channels);
                }
            } else {
                while (b.remaining() >= 2 * channels) {
                    double mono = 0;
                    for (int c = 0; c < channels; c++) mono += b.getShort() / 32768.0;
                    add(mono / channels);
                }
            }
        }

        private static double clamp(float v) {
            if (v > 1f) return 1;
            if (v < -1f) return -1;
            return v;
        }

        private void add(double x) {
            double sq = x * x;
            totalSq += sq;
            sampleCount++;
            windowSq += sq;
            windowCount++;
            if (windowCount >= windowSamples) {
                envelope.add(Math.sqrt(windowSq / windowCount));
                windowSq = 0;
                windowCount = 0;
            }
        }

        AudioFeatures finish() {
            if (windowCount > 0) envelope.add(Math.sqrt(windowSq / windowCount));
            double rms = Math.sqrt(totalSq / Math.max(1, sampleCount));
            double rmsDb = 20.0 * Math.log10(rms + 1e-9);
            if (envelope.size() < 8) return new AudioFeatures(rmsDb, 0, 0);

            double[] onset = new double[envelope.size() - 1];
            double onsetSum = 0;
            for (int i = 1; i < envelope.size(); i++) {
                onset[i - 1] = Math.max(0.0, envelope.get(i) - envelope.get(i - 1));
                onsetSum += onset[i - 1];
            }
            double mean = onsetSum / onset.length;
            double variance = 0;
            for (double v : onset) {
                double d = v - mean;
                variance += d * d;
            }
            double std = Math.sqrt(variance / onset.length);
            double avgEnv = 0;
            for (double v : envelope) avgEnv += v;
            avgEnv /= envelope.size();
            double activity = std / (avgEnv + 1e-7);

            double frameRate = sampleRate / (double) windowSamples;
            int bestLag = -1;
            double best = Double.NEGATIVE_INFINITY;
            int minLag = Math.max(1, (int) Math.floor(frameRate * 60.0 / 180.0));
            int maxLag = Math.min(onset.length / 2, (int) Math.ceil(frameRate * 60.0 / 65.0));
            for (int lag = minLag; lag <= maxLag; lag++) {
                double corr = 0, a2 = 0, b2 = 0;
                for (int i = lag; i < onset.length; i++) {
                    double a = onset[i] - mean;
                    double bb = onset[i - lag] - mean;
                    corr += a * bb;
                    a2 += a * a;
                    b2 += bb * bb;
                }
                double normalized = corr / (Math.sqrt(a2 * b2) + 1e-9);
                if (normalized > best) {
                    best = normalized;
                    bestLag = lag;
                }
            }
            double bpm = bestLag > 0 && best > 0.04 ? 60.0 * frameRate / bestLag : 0.0;
            if (bpm > 0 && bpm < 75) bpm *= 2.0;
            if (bpm > 180) bpm /= 2.0;
            return new AudioFeatures(rmsDb, bpm, activity);
        }
    }

    static void scoreEnergy(List<Song> songs) {
        List<Double> rmsVals = new ArrayList<>();
        List<Double> actVals = new ArrayList<>();
        List<Double> bpmVals = new ArrayList<>();
        for (Song s : songs) {
            rmsVals.add(s.rmsDb);
            actVals.add(s.activity);
            if (s.bpm > 0) bpmVals.add(s.bpm);
        }
        Collections.sort(rmsVals);
        Collections.sort(actVals);
        Collections.sort(bpmVals);
        double rmsLo = percentile(rmsVals, 0.10), rmsHi = percentile(rmsVals, 0.90);
        double actLo = percentile(actVals, 0.10), actHi = percentile(actVals, 0.90);
        double bpmLo = bpmVals.isEmpty() ? 80 : percentile(bpmVals, 0.10);
        double bpmHi = bpmVals.isEmpty() ? 150 : percentile(bpmVals, 0.90);

        for (Song s : songs) {
            double absRms = normRange(s.rmsDb, -32.0, -9.0);
            double absAct = normRange(s.activity, 0.008, 0.16);
            double absBpm = s.bpm > 0 ? normRange(s.bpm, 70.0, 170.0) : 0.42;
            double relRms = normRange(s.rmsDb, rmsLo, rmsHi);
            double relAct = normRange(s.activity, actLo, actHi);
            double relBpm = s.bpm > 0 ? normRange(s.bpm, bpmLo, bpmHi) : 0.42;
            double absolute = 0.45 * absRms + 0.35 * absAct + 0.20 * absBpm;
            double relative = 0.45 * relRms + 0.35 * relAct + 0.20 * relBpm;
            s.energy = clamp01(0.65 * absolute + 0.35 * relative);
        }
    }

    private static double percentile(List<Double> values, double p) {
        if (values.isEmpty()) return 0.0;
        if (values.size() == 1) return values.get(0);
        double idx = p * (values.size() - 1);
        int lo = (int) Math.floor(idx);
        int hi = Math.min(values.size() - 1, lo + 1);
        double frac = idx - lo;
        return values.get(lo) * (1 - frac) + values.get(hi) * frac;
    }

    private static double normRange(double v, double min, double max) {
        if (!Double.isFinite(v) || !Double.isFinite(min) || !Double.isFinite(max) || max - min < 1e-9) return 0.5;
        return clamp01((v - min) / (max - min));
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }

    // ====================== SMART SCHEDULER - START ======================
    // EN: PRIMARY CONSTRAINT = global artist/band spacing. First an artist skeleton is built
    //     across the full list. Each occurrence may move only +/-1 slot. Inside that hard
    //     window the flow target, genre, album and version influence which song is chosen.
    //     No random numbers are used; deterministic path ordering breaks ties.
    // HE: אילוץ ראשי = פיזור אמן/להקה גלובלי. תחילה נבנה שלד אמנים לכל הרשימה וכל
    //     הופעה רשאית לזוז רק +/-1. בתוך החלון משפיעים זרימה, Genre, אלבום וגרסה.
    //     אין אקראיות; שוויון מוכרע באופן דטרמיניסטי לפי הנתיב.
    static List<Song> scheduleSmart(Context context, List<Song> songs, int mode, double threshold, ProgressCallback callback) {
        List<Song> all = new ArrayList<>(songs);
        for (Song s : all) s.refreshScheduleKeys();
        all.sort(Comparator.comparing((Song s) -> s.relativePath, String.CASE_INSENSITIVE_ORDER));

        int total = all.size();
        ScheduleStats stats = new ScheduleStats(all);

        // Stage 1: create the same global artist/band skeleton that passed the 0.2.3 test.
        // Every occurrence receives an ideal target slot across the full playlist.
        Map<String, List<Song>> pools = new LinkedHashMap<>();
        for (Song s : all) {
            String key = schedulingArtistKey(s);
            if (!pools.containsKey(key)) pools.put(key, new ArrayList<>());
            pools.get(key).add(s);
        }

        Map<String, Integer> schedulingCounts = new HashMap<>();
        List<Song> singletonPool = new ArrayList<>();
        for (Map.Entry<String, List<Song>> entry : pools.entrySet()) {
            int count = entry.getValue().size();
            schedulingCounts.put(entry.getKey(), count);
            if (count == 1) singletonPool.add(entry.getValue().get(0));
        }
        singletonPool.sort(Comparator.comparing((Song s) -> s.relativePath, String.CASE_INSENSITIVE_ORDER));

        List<Map.Entry<String, List<Song>>> buckets = new ArrayList<>(pools.entrySet());
        buckets.sort((a, b) -> {
            int cmp = Integer.compare(b.getValue().size(), a.getValue().size());
            return cmp != 0 ? cmp : a.getKey().compareToIgnoreCase(b.getKey());
        });

        String[] artistPlan = new String[total];
        boolean[] occupied = new boolean[total];
        int assigned = 0;
        for (Map.Entry<String, List<Song>> bucket : buckets) {
            String key = bucket.getKey();
            int count = bucket.getValue().size();
            for (int occurrence = 0; occurrence < count; occurrence++) {
                double ideal = ((occurrence + 0.5) * total / (double) count) - 0.5;
                int slot = nearestFreeSlot(context, ideal, occupied, key, occurrence);
                occupied[slot] = true;
                artistPlan[slot] = key;
                assigned++;
            }
            final int done = assigned;
            if (callback != null) callback.onProgress(tr(context, "מפזר אמנים ולהקות: ", "Spreading artists/bands: ") + done + "/" + total + "…",
                    5 + (int) (30.0 * done / Math.max(1, total)));
        }

        // Balanced means: distribute whichever side is the minority. It does NOT try to
        // manufacture a 50/50 library. Example: 141 calm / 595 energetic -> calm is spread
        // evenly; 600 calm / 136 energetic -> energetic is spread evenly.
        int calmCount = 0;
        for (Song s : all) if (s.energy < threshold) calmCount++;
        int energeticCount = total - calmCount;
        boolean minorityIsCalm = calmCount <= energeticCount;
        int minorityCount = Math.min(calmCount, energeticCount);

        // Rising/falling flow is based on the ACTUAL energy distribution of this library,
        // not on a fixed 0.10..0.90 line. Each position gets a target taken from the
        // library's own sorted energy values. This reserves scarce energetic songs for the
        // end of Rising and scarce calm songs for the end of Falling instead of consuming
        // the minority too early and producing a U/V-shaped playlist. Artist spacing remains
        // the hard primary constraint; these targets only choose the best song inside it.
        double[] directionalFlowTargets = buildDirectionalFlowTargets(all, mode);

        // Stage 2: keep the artist skeleton primary, but allow each planned artist occurrence
        // to move at most one position around its target. This gives genre/album/flow a small
        // amount of freedom without allowing the old large artist clusters to return.
        final int artistWindow = 1;
        boolean[] tokenUsed = new boolean[total];
        ScheduleState state = new ScheduleState();
        List<Song> result = new ArrayList<>(total);
        int minorityUsed = 0;

        for (int pos = 0; pos < total; pos++) {
            List<Integer> eligibleTargets = new ArrayList<>();

            // A token that reaches the left edge of its allowed window becomes mandatory.
            // This guarantees every artist occurrence stays inside +/- artistWindow.
            int overdue = -1;
            int deadline = pos - artistWindow;
            if (deadline >= 0) {
                for (int t = 0; t <= deadline; t++) {
                    if (!tokenUsed[t]) {
                        overdue = t;
                        break;
                    }
                }
            }
            if (overdue >= 0) {
                eligibleTargets.add(overdue);
            } else {
                int from = Math.max(0, pos - artistWindow);
                int to = Math.min(total - 1, pos + artistWindow);
                for (int t = from; t <= to; t++) {
                    if (!tokenUsed[t]) eligibleTargets.add(t);
                }
            }

            if (eligibleTargets.isEmpty()) {
                throw new IllegalStateException(tr(context, "שגיאת חלון פיזור במיקום ", "Distribution window error at position ") + (pos + 1));
            }

            Placement bestPlacement = null;
            double bestScore = Double.NEGATIVE_INFINITY;
            for (int target : eligibleTargets) {
                String key = artistPlan[target];
                boolean singletonTarget = schedulingCounts.getOrDefault(key, 0) == 1;
                // Artists that occur once have no repeat-spacing constraint. Their reserved
                // singleton slots can therefore exchange songs globally, giving the flow
                // engine useful freedom without changing the spacing of any repeated artist.
                List<Song> candidates = singletonTarget ? singletonPool : pools.get(key);
                if (candidates == null || candidates.isEmpty()) continue;

                Song candidate = chooseSongInsideArtist(candidates, pos, total, mode, threshold,
                        stats, state, minorityCount, minorityUsed, minorityIsCalm,
                        directionalFlowTargets, singletonTarget);
                if (candidate == null) continue;

                double flow = flowScore(candidate, pos, total, mode, threshold,
                        minorityCount, minorityUsed, minorityIsCalm, directionalFlowTargets);
                double distribution = secondaryDistributionScore(candidate, pos, total, stats, state);
                double displacementPenalty = Math.abs(target - pos) * 0.75;
                double spacingPenalty = artistSpacingPenalty(candidate, pos, total, stats, state);

                // Artist is already a hard constraint through the +/-1 window. Inside that
                // window flow gets enough weight to hit minority targets; genre/album/version
                // still influence close choices without becoming hard constraints.
                double score = flow + distribution * 0.02 - displacementPenalty + spacingPenalty;

                if (score > bestScore + 1e-9
                        || (Math.abs(score - bestScore) < 1e-9
                        && (bestPlacement == null
                        || target < bestPlacement.target
                        || (target == bestPlacement.target
                        && candidate.relativePath.compareToIgnoreCase(bestPlacement.song.relativePath) < 0)))) {
                    bestScore = score;
                    bestPlacement = new Placement(target, candidate);
                }
            }

            if (bestPlacement == null) {
                throw new IllegalStateException(tr(context, "לא נמצא שיר מתאים במיקום ", "No suitable song found at position ") + (pos + 1));
            }

            String chosenKey = artistPlan[bestPlacement.target];
            boolean chosenSingletonTarget = schedulingCounts.getOrDefault(chosenKey, 0) == 1;
            result.add(bestPlacement.song);
            state.record(bestPlacement.song, pos);
            if (chosenSingletonTarget) {
                singletonPool.remove(bestPlacement.song);
            } else {
                List<Song> chosenPool = pools.get(chosenKey);
                if (chosenPool == null || !chosenPool.remove(bestPlacement.song)) {
                    throw new IllegalStateException(tr(context, "שגיאת מאגר אמן במיקום ", "Artist pool error at position ") + (pos + 1));
                }
            }
            tokenUsed[bestPlacement.target] = true;
            if (mode == 0 && minorityCount > 0) {
                boolean calm = bestPlacement.song.energy < threshold;
                if (calm == minorityIsCalm) minorityUsed++;
            }

            final int done = pos + 1;
            if (callback != null && (done == total || done % 20 == 0)) {
                callback.onProgress(tr(context, "מסדר את זרימת הפלייליסט: ", "Arranging playlist flow: ") + done + "/" + total + "…",
                        35 + (int) (60.0 * done / Math.max(1, total)));
            }
        }
        return result;
    }
    // ======================= SMART SCHEDULER - END =======================

    static String schedulingArtistKey(Song s) {
        String key = s.artistKey();
        if (key != null && !key.isEmpty()) return key;
        // Unknown artists must not be treated as one giant group.
        return "__single__" + sha256(s.relativePath);
    }

    static int nearestFreeSlot(Context context, double ideal, boolean[] occupied, String key, int occurrence) {
        int total = occupied.length;
        int base = clampInt((int) Math.round(ideal), 0, total - 1);
        if (!occupied[base]) return base;

        // Deterministic direction preference prevents systematic drift when two groups
        // want the same ideal slot. It is stable, not random.
        boolean preferRight = ((key.hashCode() + occurrence) & 1) == 0;
        for (int distance = 1; distance < total; distance++) {
            int first = preferRight ? base + distance : base - distance;
            int second = preferRight ? base - distance : base + distance;
            if (first >= 0 && first < total && !occupied[first]) return first;
            if (second >= 0 && second < total && !occupied[second]) return second;
        }
        throw new IllegalStateException(tr(context, "אין מקום פנוי בפיזור", "No free distribution slot is available"));
    }

    static Song chooseSongInsideArtist(List<Song> candidates, int pos, int total, int mode, double threshold,
                                        ScheduleStats stats, ScheduleState state,
                                        int minorityCount, int minorityUsed, boolean minorityIsCalm,
                                        double[] directionalFlowTargets, boolean flowFirst) {
        if (candidates.size() == 1) return candidates.get(0);

        // The shared singleton pool is the safe place to give flow real freedom: each artist
        // appears only once, so choosing a different singleton cannot damage artist spacing.
        if (flowFirst) {
            Song best = null;
            double bestScore = Double.NEGATIVE_INFINITY;
            for (Song s : candidates) {
                double flow = flowScore(s, pos, total, mode, threshold,
                        minorityCount, minorityUsed, minorityIsCalm, directionalFlowTargets);
                double distribution = secondaryDistributionScore(s, pos, total, stats, state);
                double score = flow + distribution * 0.02;
                if (score > bestScore + 1e-9
                        || (Math.abs(score - bestScore) < 1e-9
                        && (best == null || s.relativePath.compareToIgnoreCase(best.relativePath) < 0))) {
                    best = s;
                    bestScore = score;
                }
            }
            return best;
        }

        double bestDistribution = Double.NEGATIVE_INFINITY;
        Map<Song, Double> distributionScores = new HashMap<>();
        for (Song s : candidates) {
            double score = secondaryDistributionScore(s, pos, total, stats, state);
            distributionScores.put(s, score);
            if (score > bestDistribution) bestDistribution = score;
        }

        // Preserve genre/album/version priority inside an artist pool, while allowing flow
        // to decide among distribution choices that are close enough.
        final double distributionTolerance = 12.0;
        Song best = null;
        double bestFlow = Double.NEGATIVE_INFINITY;
        for (Song s : candidates) {
            double distribution = distributionScores.get(s);
            if (distribution < bestDistribution - distributionTolerance) continue;
            double flow = flowScore(s, pos, total, mode, threshold,
                    minorityCount, minorityUsed, minorityIsCalm, directionalFlowTargets);
            if (flow > bestFlow + 1e-9
                    || (Math.abs(flow - bestFlow) < 1e-9
                    && (best == null || s.relativePath.compareToIgnoreCase(best.relativePath) < 0))) {
                best = s;
                bestFlow = flow;
            }
        }
        if (best != null) return best;

        return candidates.stream()
                .max(Comparator.comparingDouble((Song s) -> distributionScores.get(s))
                        .thenComparing(s -> s.relativePath, String.CASE_INSENSITIVE_ORDER.reversed()))
                .orElse(candidates.get(0));
    }

    static double secondaryDistributionScore(Song s, int pos, int total,
                                              ScheduleStats stats, ScheduleState state) {
        double score = 0.0;
        score += groupUrgency(s.genreKey(), pos, total, stats.genreCounts, state.genreUsed, state.genreLast, 190.0, 0.62);
        score += groupUrgency(s.albumKey(), pos, total, stats.albumCounts, state.albumUsed, state.albumLast, 105.0, 0.58);
        score += groupUrgency(s.titleFamilyKey(), pos, total, stats.titleCounts, state.titleUsed, state.titleLast, 175.0, 0.75);
        return score;
    }

    static double artistSpacingPenalty(Song s, int pos, int total,
                                        ScheduleStats stats, ScheduleState state) {
        String key = s.artistKey();
        if (key == null || key.isEmpty()) return 0.0;
        Integer countObj = stats.artistCounts.get(key);
        Integer lastPos = state.artistLast.get(key);
        if (countObj == null || countObj <= 1 || lastPos == null) return 0.0;

        double idealGap = total / (double) countObj;
        double distance = pos - lastPos;
        double safeGap = Math.max(1.0, idealGap * 0.78);
        if (distance >= safeGap) return 0.0;
        return -220.0 * (safeGap - distance) / safeGap;
    }

    static double flowScore(Song s, int pos, int total, int mode, double threshold,
                             int minorityCount, int minorityUsed, boolean minorityIsCalm,
                             double[] directionalFlowTargets) {
        if (mode == 0) {
            if (minorityCount <= 0) return 0.0;

            boolean calm = s.energy < threshold;
            boolean isMinority = calm == minorityIsCalm;

            // The next minority occurrence has a moving ideal position. If an exact ideal
            // position cannot be used because of the artist skeleton, the target moves with
            // the still-unused minority songs instead of being abandoned. This is what keeps
            // the smaller group spread over the whole playlist rather than creating long runs.
            double idealNext = ((minorityUsed + 0.5) * total / (double) minorityCount) - 0.5;
            double delta = pos - idealNext;

            double classScore;
            if (isMinority) {
                // Prefer a minority song close to its next ideal occurrence; overdue minority
                // songs remain attractive so a missed target is corrected immediately after.
                classScore = 50.0 - Math.abs(delta) * 20.0;
            } else {
                // Majority songs are preferred while the next minority occurrence is still
                // comfortably in the future, then quickly lose priority once it is due.
                classScore = delta < -0.5 ? 30.0 : -Math.max(0.0, delta) * 30.0;
            }

            double targetEnergy = isMinority
                    ? (minorityIsCalm ? 0.30 : 0.70)
                    : (minorityIsCalm ? 0.70 : 0.30);
            return classScore - Math.abs(s.energy - targetEnergy) * 4.0;
        }

        // Directional modes use the library-adaptive target prepared by
        // buildDirectionalFlowTargets(). Because the target sequence contains exactly the
        // same energy distribution as the input songs, the scheduler cannot plan for more
        // calm/energetic material than actually exists. This is symmetric: it also protects
        // Rising when energetic songs are the minority.
        double target;
        if (directionalFlowTargets != null && pos >= 0 && pos < directionalFlowTargets.length) {
            target = directionalFlowTargets[pos];
        } else {
            double progress = total <= 1 ? 0.5 : pos / (double) (total - 1);
            target = mode == 1 ? 0.10 + 0.80 * progress : 0.90 - 0.80 * progress;
        }
        return -Math.abs(s.energy - target) * 42.0;
    }

    // =============== ADAPTIVE RISING/FALLING TARGETS - START ===============
    // EN: Uses the library's own sorted energy distribution rather than a fixed artificial
    //     0..1 ramp. This preserves scarce energetic/calm tracks for the part of the list
    //     where Rising/Falling needs them.
    // HE: משתמש בהתפלגות ציוני האופי האמיתית ולא ברמפה מלאכותית קבועה. כך שירים
    //     נדירים מהקבוצה הקצבית/רגועה נשמרים לחלק הנכון במתגבר/יורד.
    static double[] buildDirectionalFlowTargets(List<Song> songs, int mode) {
        if (mode != 1 && mode != 2) return null;
        List<Song> ranked = new ArrayList<>(songs);
        ranked.sort(Comparator
                .comparingDouble((Song s) -> s.energy)
                .thenComparing(s -> s.relativePath, String.CASE_INSENSITIVE_ORDER));

        int n = ranked.size();
        double[] targets = new double[n];
        for (int pos = 0; pos < n; pos++) {
            int source = mode == 1 ? pos : (n - 1 - pos);
            targets[pos] = ranked.get(source).energy;
        }
        return targets;
    }

    // ================ ADAPTIVE RISING/FALLING TARGETS - END ================

    static double groupUrgency(String key, int pos, int total, Map<String, Integer> counts,
                                Map<String, Integer> used, Map<String, Integer> last,
                                double weight, double minGapFactor) {
        if (key == null || key.isEmpty()) return 0;
        int count = counts.containsKey(key) ? counts.get(key) : 0;
        if (count <= 0) return 0;
        int u = used.containsKey(key) ? used.get(key) : 0;
        if (u >= count) return -weight * 50.0;

        double targetGap = total / (double) count;
        double idealNext = (u + 0.5) * targetGap - 0.5;
        double urgency = (pos - idealNext) / Math.max(1.0, targetGap);
        double score = urgency * weight;

        Integer lastPos = last.get(key);
        if (lastPos != null) {
            double distance = pos - lastPos;
            double minGap = Math.max(1.0, targetGap * minGapFactor);
            if (distance < minGap) {
                score -= (minGap - distance) / minGap * weight * 8.0;
            }
            if (distance <= 1.0) score -= weight * 24.0;
        }
        return score;
    }

    static Uri writePlaylist(Context context, Uri tree, List<Song> songs, String playlistName) throws Exception {
        StringBuilder m3u = new StringBuilder("#EXTM3U\n");
        for (Song s : songs) {
            m3u.append("#EXTINF:-1,").append(cleanLine(s.displayTitleWithArtist())).append('\n');
            m3u.append(cleanLine(pathForPoweramp(s))).append('\n');
        }
        return writeTextDocument(context, tree, playlistName, "audio/x-mpegurl", m3u.toString());
    }

    static Uri writeAnalysisReport(Context context, Uri tree, List<Song> songs, String playlistName, int mode,
                                   double threshold, String filterDescription) throws Exception {
        String reportName = analysisReportName(playlistName);
        StringBuilder out = new StringBuilder();
        out.append(tr(context, "# קובץ בדיקה אוטומטי של Playlist Maker\n", "# Automatic diagnostic file from Playlist Maker\n"));
        out.append(tr(context, "# מצב זרימה: ", "# Flow mode: ")).append(flowModeName(context, mode)).append('\n');
        if (filterDescription != null && !filterDescription.trim().isEmpty()) {
            out.append(tr(context, "# סינון: ", "# Filter: ")).append(filterDescription.trim()).append('\n');
        }
        out.append(tr(context, "# מספר שירים: ", "# Song count: ")).append(songs.size()).append('\n');
        if (mode == 0) {
            int calm = 0;
            for (Song s : songs) if (s.energy < threshold) calm++;
            int energetic = songs.size() - calm;
            boolean calmMinority = calm <= energetic;
            String minority = calmMinority ? tr(context, "רגועים", "calm") : tr(context, "קצביים", "energetic");
            out.append(tr(context, "# מאוזן: רגועים ", "# Balanced: calm ")).append(calm)
                    .append(tr(context, " | קצביים ", " | energetic ")).append(energetic)
                    .append(tr(context, " | הקבוצה המתפזרת: ", " | distributed minority: ")).append(minority).append('\n');
            double avgGap = averageClassGap(songs, threshold, calmMinority);
            double idealGap = songs.size() / (double) Math.max(1, calmMinority ? calm : energetic);
            out.append(tr(context, "# בדיקת פיזור מיעוט: יעד ~", "# Minority distribution check: target ~"))
                    .append(String.format(Locale.ROOT, "%.2f", idealGap))
                    .append(tr(context, " | מרווח ממוצע ", " | average gap "))
                    .append(String.format(Locale.ROOT, "%.2f", avgGap)).append('\n');
        } else {
            out.append(tr(context, "# בדיקת זרימה מספרית: ", "# Numeric flow check: ")).append(flowDiagnosticsText(context, songs, mode)).append('\n');
        }
        out.append(tr(context, "# הערה: ציון האופי 0-100 הוא מדד פנימי לצורך בדיקה בלבד ואינו משנה את האלגוריתם.\n", "# Note: the 0-100 character score is an internal diagnostic value and does not change the algorithm.\n"));
        out.append(tr(context, "מיקום\tאמן\tכותרת\tציון_אופי_0_100\tאופי\tBPM\tGenre\tקבוצת_פיזור\n", "Position\tArtist\tTitle\tCharacter_score_0_100\tCharacter\tBPM\tGenre\tDistribution_group\n"));
        for (int i = 0; i < songs.size(); i++) {
            Song s = songs.get(i);
            out.append(i + 1).append('\t')
                    .append(cleanField(s.artistIdentity())).append('\t')
                    .append(cleanField(s.displayTitle())).append('\t')
                    .append(Math.round(s.energy * 100.0)).append('\t')
                    .append(s.energy < threshold ? tr(context, "רגוע", "calm") : tr(context, "קצבי", "energetic")).append('\t')
                    .append(s.bpm > 0 ? Math.round(s.bpm) : 0).append('\t')
                    .append(cleanField(s.genre)).append('\t')
                    .append(cleanField(s.artistKey())).append('\n');
        }
        return writeTextDocument(context, tree, reportName, "text/plain", out.toString());
    }

    static Uri writeTextDocument(Context context, Uri tree, String fileName, String mimeType, String text) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        String rootId = DocumentsContract.getTreeDocumentId(tree);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, rootId);
        Uri document = null;
        String[] projection = { DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME };
        try (Cursor c = resolver.query(children, projection, null, null, null)) {
            if (c != null) {
                int idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                while (c.moveToNext()) {
                    if (fileName.equalsIgnoreCase(c.getString(nameCol))) {
                        document = DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(idCol));
                        break;
                    }
                }
            }
        }

        if (document == null) {
            Uri rootDoc = DocumentsContract.buildDocumentUriUsingTree(tree, rootId);
            Exception first = null;
            try {
                document = DocumentsContract.createDocument(resolver, rootDoc, mimeType, fileName);
            } catch (Exception e) {
                first = e;
            }
            if (document == null) {
                try {
                    document = DocumentsContract.createDocument(resolver, rootDoc, "application/octet-stream", fileName);
                } catch (Exception e) {
                    if (first != null) e.addSuppressed(first);
                    throw e;
                }
            }
        }
        if (document == null) throw new IllegalStateException(tr(context, "לא ניתן ליצור את הקובץ ", "Could not create file ") + fileName + tr(context, " בתיקייה שנבחרה.", " in the selected folder."));

        OutputStream opened;
        try {
            opened = resolver.openOutputStream(document, "rwt");
        } catch (Exception ignored) {
            opened = resolver.openOutputStream(document, "wt");
        }
        if (opened == null) throw new IllegalStateException(tr(context, "לא ניתן לפתוח את הקובץ ", "Could not open file ") + fileName + tr(context, " לכתיבה", " for writing"));
        try (OutputStream os = opened) {
            os.write(text.getBytes(StandardCharsets.UTF_8));
            os.flush();
        }
        return document;
    }

    static String analysisReportName(String playlistName) {
        String base = playlistName;
        if (base.toLowerCase(Locale.ROOT).endsWith(".m3u8")) base = base.substring(0, base.length() - 5);
        return base + "-analysis.txt";
    }

    static String buildPlaylistResultSummary(Context context, List<Song> playlist, int mode, long durationMs) {
        StringBuilder sb = new StringBuilder();
        int calm = 0;
        for (Song s : playlist) if (s.energy < BALANCED_ENERGY_THRESHOLD) calm++;
        int energetic = playlist.size() - calm;
        sb.append(tr(context, "תוצאות יצירת פלייליסט\n", "Playlist creation results\n"))
                .append(tr(context, "שירים: ", "Songs: ")).append(playlist.size()).append('\n')
                .append(tr(context, "מצב זרימה: ", "Flow mode: ")).append(flowModeName(context, mode)).append('\n');
        if (durationMs > 0) sb.append(tr(context, "זמן עבודה: ", "Duration: ")).append(formatDuration(context, durationMs)).append('\n');
        sb.append(tr(context, "אופי: רגועים ", "Character: calm ")).append(calm).append(tr(context, " | קצביים ", " | energetic ")).append(energetic).append('\n');

        if (mode == 0) {
            boolean calmMinority = calm <= energetic;
            int minorityCount = calmMinority ? calm : energetic;
            double ideal = playlist.size() / (double) Math.max(1, minorityCount);
            double avg = averageClassGap(playlist, BALANCED_ENERGY_THRESHOLD, calmMinority);
            sb.append(tr(context, "פיזור הקבוצה הקטנה: ", "Minority distribution: ")).append(calmMinority ? tr(context, "רגועים", "calm") : tr(context, "קצביים", "energetic"))
                    .append(tr(context, " | יעד ~", " | target ~")).append(String.format(Locale.ROOT, "%.2f", ideal))
                    .append(tr(context, " | בפועל ", " | actual ")).append(String.format(Locale.ROOT, "%.2f", avg)).append('\n');
        } else {
            sb.append(tr(context, "בדיקת זרימה: ", "Flow check: ")).append(flowDiagnosticsText(context, playlist, mode)).append('\n');
        }
        appendTopArtistSpacingStatic(context, sb, playlist, 4);
        return sb.toString().trim();
    }

    static String formatDuration(Context context, long durationMs) {
        long totalSeconds = Math.max(0L, Math.round(durationMs / 1000.0));
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        if (minutes <= 0) return seconds + tr(context, " שניות", " seconds");
        return minutes + tr(context, " דק׳ ", " min ") + seconds + tr(context, " שנ׳", " sec");
    }

    static double averageClassGap(List<Song> songs, double threshold, boolean calmClass) {
        int previous = -1;
        int gaps = 0;
        double sum = 0.0;
        for (int i = 0; i < songs.size(); i++) {
            boolean isCalm = songs.get(i).energy < threshold;
            if (isCalm != calmClass) continue;
            if (previous >= 0) {
                sum += i - previous;
                gaps++;
            }
            previous = i;
        }
        return gaps == 0 ? 0.0 : sum / gaps;
    }

    static String flowDiagnosticsText(Context context, List<Song> songs, int mode) {
        if (songs == null || songs.isEmpty()) return tr(context, "אין נתונים", "No data");
        int n = songs.size();
        int block = Math.max(1, (int) Math.ceil(n / 5.0));
        StringBuilder segments = new StringBuilder();
        for (int part = 0; part < 5; part++) {
            int from = part * block;
            if (from >= n) break;
            int to = Math.min(n, from + block);
            if (segments.length() > 0) segments.append(" → ");
            segments.append(Math.round(averageEnergy(songs, from, to) * 100.0));
        }
        int edge = Math.max(1, n / 5);
        double first = averageEnergy(songs, 0, edge) * 100.0;
        double last = averageEnergy(songs, n - edge, n) * 100.0;
        double delta = last - first;
        double correlation = positionEnergyCorrelation(songs);
        return tr(context, "חמישיות ", "Fifths ") + segments
                + tr(context, " | התחלה ", " | start ") + Math.round(first)
                + tr(context, " | סוף ", " | end ") + Math.round(last)
                + tr(context, " | שינוי ", " | change ") + String.format(Locale.ROOT, "%+.1f", delta)
                + tr(context, " | מתאם ", " | correlation ") + String.format(Locale.ROOT, "%+.2f", correlation);
    }

    private static double averageEnergy(List<Song> songs, int from, int to) {
        if (songs == null || songs.isEmpty()) return 0.0;
        int start = Math.max(0, Math.min(from, songs.size()));
        int end = Math.max(start, Math.min(to, songs.size()));
        if (end <= start) return 0.0;
        double sum = 0.0;
        for (int i = start; i < end; i++) sum += songs.get(i).energy;
        return sum / (end - start);
    }

    private static double positionEnergyCorrelation(List<Song> songs) {
        int n = songs == null ? 0 : songs.size();
        if (n < 2) return 0.0;
        double meanX = (n - 1) / 2.0;
        double meanY = 0.0;
        for (Song s : songs) meanY += s.energy;
        meanY /= n;
        double numerator = 0.0, dx2 = 0.0, dy2 = 0.0;
        for (int i = 0; i < n; i++) {
            double dx = i - meanX;
            double dy = songs.get(i).energy - meanY;
            numerator += dx * dy;
            dx2 += dx * dx;
            dy2 += dy * dy;
        }
        if (dx2 <= 0.0 || dy2 <= 0.0) return 0.0;
        return numerator / Math.sqrt(dx2 * dy2);
    }

    private static void appendTopArtistSpacingStatic(Context context, StringBuilder sb, List<Song> playlist, int limit) {
        Map<String, List<Integer>> positions = new HashMap<>();
        Map<String, String> labels = new HashMap<>();
        for (int i = 0; i < playlist.size(); i++) {
            Song song = playlist.get(i);
            String key = song.artistKey();
            if (key.isEmpty()) continue;
            if (!positions.containsKey(key)) positions.put(key, new ArrayList<>());
            positions.get(key).add(i);
            if (!labels.containsKey(key)) labels.put(key, song.artistIdentity());
        }
        List<String> keys = new ArrayList<>(positions.keySet());
        keys.sort((a, b) -> Integer.compare(positions.get(b).size(), positions.get(a).size()));
        int shown = 0;
        sb.append(tr(context, "פיזור אמנים בולטים:\n", "Top artist spacing:\n"));
        for (String key : keys) {
            List<Integer> pos = positions.get(key);
            if (pos.size() < 2) continue;
            double sum = 0.0;
            for (int i = 1; i < pos.size(); i++) sum += pos.get(i) - pos.get(i - 1);
            double avg = sum / (pos.size() - 1);
            double ideal = playlist.size() / (double) pos.size();
            sb.append("• ").append(labels.get(key)).append(": ").append(pos.size())
                    .append(tr(context, " | יעד ~", " | target ~")).append(String.format(Locale.ROOT, "%.1f", ideal))
                    .append(tr(context, " | ממוצע ", " | average ")).append(String.format(Locale.ROOT, "%.1f", avg)).append('\n');
            shown++;
            if (shown >= limit) break;
        }
        if (shown == 0) sb.append(tr(context, "אין אמן עם יותר משיר אחד.\n", "No artist has more than one song.\n"));
    }

    static String flowModeName(Context context, int mode) {
        if (mode == 1) return tr(context, "מתגבר", "Rising");
        if (mode == 2) return tr(context, "יורד", "Falling");
        return tr(context, "מאוזן", "Balanced");
    }

    private static String cleanField(String value) {
        if (value == null) return "";
        return value.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
    }

    static String pathForPoweramp(Song s) {
        String absolute = absolutePathFromDocumentId(s.documentId);
        return absolute != null ? absolute : s.relativePath;
    }

    static String absolutePathFromDocumentId(String documentId) {
        int colon = documentId.indexOf(':');
        if (colon < 0) return null;
        String volume = documentId.substring(0, colon);
        String path = documentId.substring(colon + 1);
        if ("primary".equalsIgnoreCase(volume)) {
            return path.isEmpty() ? "/storage/emulated/0" : "/storage/emulated/0/" + path;
        }
        if (volume.matches("[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}")) {
            return path.isEmpty() ? "/storage/" + volume : "/storage/" + volume + "/" + path;
        }
        return null;
    }

    static String cleanLine(String s) {
        return s.replace('\n', ' ').replace('\r', ' ');
    }

    private void showAnalysisSummary() {
        if (analyzedSongs.isEmpty()) return;
        double threshold = BALANCED_ENERGY_THRESHOLD;
        int calm = 0, energetic = 0, genreKnown = 0, artistKnown = 0;
        Map<String, Integer> artists = new HashMap<>();
        Map<String, Integer> genres = new HashMap<>();
        for (Song s : analyzedSongs) {
            if (s.energy < threshold) calm++; else energetic++;
            if (!s.artistKey().isEmpty()) { artistKnown++; increment(artists, s.artistIdentity()); }
            if (!s.genreKey().isEmpty()) { genreKnown++; increment(genres, s.genre); }
        }

        StringBuilder sb = new StringBuilder();
        sb.append(tr("תוצאות ניתוח\n", "Analysis results\n"));
        sb.append(tr("שירים שנותחו: ", "Analyzed songs: ")).append(analyzedSongs.size()).append('\n');
        if (lastOperationDurationMs > 0) sb.append(tr("זמן עבודה: ", "Duration: ")).append(formatDuration(this, lastOperationDurationMs)).append('\n');
        if (lastSkipped > 0) sb.append(tr("קבצים שלא נותחו: ", "Files not analyzed: ")).append(lastSkipped).append('\n');
        sb.append(tr("נטענו מהמטמון: ", "Loaded from cache: ")).append(lastCacheHits).append('\n');
        sb.append(tr("אופי משוער: רגועים ", "Estimated character: calm ")).append(calm).append(tr(" | קצביים ", " | energetic ")).append(energetic).append('\n');
        sb.append(tr("אמן/להקה מזוהים: ", "Known artist/band: ")).append(artistKnown).append(tr(" | סוג מזוהה: ", " | known genre: ")).append(genreKnown).append('\n');
        sb.append(tr("סוג מסווג רק מתגית קובץ, תיקון ידני, או רשימת זיהוי אמן שמרנית.\n\n", "Genre is classified only from file tags, manual correction, or a conservative trusted-artist map.\n\n"));
        appendTopCounts(sb, tr("אמנים/להקות בולטים", "Top artists/bands"), artists, 8);
        appendTopCounts(sb, tr("סוגים", "Genres"), genres, 8);

        sb.append(tr("\nדוגמה מהניתוח:\n", "\nAnalysis sample:\n"));
        List<Song> preview = new ArrayList<>(analyzedSongs);
        preview.sort(Comparator.comparingDouble(s -> s.energy));
        int show = Math.min(20, preview.size());
        for (int i = 0; i < show; i++) {
            Song s = preview.get(i);
            sb.append("• ").append(s.displayTitleWithArtist())
                    .append(" | ").append(s.energy < threshold ? tr("רגוע", "calm") : tr("קצבי", "energetic"))
                    ;
            if (s.bpm > 0) sb.append(" | ~").append(Math.round(s.bpm)).append(" BPM");
            if (s.genre != null) sb.append(" | ").append(s.genre);
            sb.append('\n');
        }
        resultText.setText(sb.toString());
    }

    private String buildPlaylistSummary(List<Song> playlist, int skipped, Uri playlistUri, double threshold) {
        StringBuilder sb = new StringBuilder();
        sb.append(tr("נוצרו ", "Created ")).append(playlist.size()).append(tr(" שירים. קודם בוצע פיזור אמנים/להקות, אחר כך הותאמה זרימת הפלייליסט.\n", " songs. Artist/band spacing was applied first, then playlist flow was adapted.\n"));
        if (skipped > 0) sb.append(tr("דולגו ", "Skipped ")).append(skipped).append(tr(" קבצים שלא ניתן היה לנתח.\n", " files that could not be analyzed.\n"));
        sb.append(tr("\nפיזור אמן/להקה:\n", "\nArtist/band distribution:\n"));
        appendSpacingReport(sb, playlist, true, 8);
        sb.append(tr("\nפיזור סוג מוזיקלי:\n", "\nGenre distribution:\n"));
        appendSpacingReport(sb, playlist, false, 8);
        sb.append(tr("\nב-Poweramp בצע Rescan אם הפלייליסט לא מופיע מיד.\n\n", "\nIn Poweramp, run Rescan if the playlist does not appear immediately.\n\n"));

        int show = Math.min(80, playlist.size());
        for (int i = 0; i < show; i++) {
            Song s = playlist.get(i);
            sb.append(i + 1).append(". ").append(s.energy < threshold ? tr("רגוע", "calm") : tr("קצבי", "energetic"))
                    .append(" — ").append(s.displayTitleWithArtist());
            if (s.genre != null) sb.append(" [").append(s.genre).append("]");
            if (s.bpm > 0) sb.append(" (~").append(Math.round(s.bpm)).append(" BPM)");
            sb.append('\n');
        }
        if (playlist.size() > show) sb.append(tr("… ועוד ", "… and ")).append(playlist.size() - show).append(tr(" שירים", " more songs"));
        return sb.toString();
    }

    private void appendTopCounts(StringBuilder sb, String heading, Map<String, Integer> counts, int limit) {
        if (counts.isEmpty()) return;
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(counts.entrySet());
        entries.sort((a, b) -> {
            int cmp = Integer.compare(b.getValue(), a.getValue());
            return cmp != 0 ? cmp : a.getKey().compareToIgnoreCase(b.getKey());
        });
        sb.append(heading).append(":\n");
        for (int i = 0; i < Math.min(limit, entries.size()); i++) {
            Map.Entry<String, Integer> e = entries.get(i);
            sb.append("• ").append(e.getKey()).append(": ").append(e.getValue()).append('\n');
        }
        sb.append('\n');
    }

    private void appendSpacingReport(StringBuilder sb, List<Song> playlist, boolean artist, int limit) {
        Map<String, List<Integer>> positions = new LinkedHashMap<>();
        Map<String, String> display = new HashMap<>();
        for (int i = 0; i < playlist.size(); i++) {
            Song s = playlist.get(i);
            String key = artist ? s.artistKey() : s.genreKey();
            String label = artist ? s.artistIdentity() : s.genre;
            if (key.isEmpty() || label == null) continue;
            if (!positions.containsKey(key)) positions.put(key, new ArrayList<>());
            positions.get(key).add(i);
            if (!display.containsKey(key)) display.put(key, label);
        }
        List<String> keys = new ArrayList<>(positions.keySet());
        keys.sort((a, b) -> Integer.compare(positions.get(b).size(), positions.get(a).size()));
        int shown = 0;
        for (String key : keys) {
            List<Integer> pos = positions.get(key);
            if (pos.size() < 2) continue;
            double ideal = playlist.size() / (double) pos.size();
            double sum = 0;
            int min = Integer.MAX_VALUE;
            for (int i = 1; i < pos.size(); i++) {
                int gap = pos.get(i) - pos.get(i - 1);
                sum += gap;
                min = Math.min(min, gap);
            }
            double avg = sum / (pos.size() - 1);
            sb.append("• ").append(display.get(key)).append(": ").append(pos.size())
                    .append(tr(" שירים | יעד ~", " songs | target ~")).append(String.format(Locale.ROOT, "%.1f", ideal))
                    .append(tr(" | ממוצע ", " | average ")).append(String.format(Locale.ROOT, "%.1f", avg))
                    .append(tr(" | מינימום ", " | minimum ")).append(min).append('\n');
            shown++;
            if (shown >= limit) break;
        }
        if (shown == 0) sb.append(tr("אין קבוצות עם יותר משיר אחד.\n", "No group has more than one song.\n"));
    }

    private void showMetadataEditor() {
        if (analyzedSongs.isEmpty()) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(4));
        box.setLayoutDirection(AppLanguage.isHebrew(this) ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        Spinner songSpinner = new Spinner(this);
        List<String> labels = new ArrayList<>();
        for (Song s : analyzedSongs) labels.add(s.displayTitleWithArtist());
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        songSpinner.setAdapter(adapter);
        box.addView(songSpinner, new LinearLayout.LayoutParams(-1, -2));

        EditText artist = metadataField(tr("אמן", "Artist"));
        EditText albumArtist = metadataField(tr("להקה / Album Artist", "Band / Album Artist"));
        EditText album = metadataField(tr("אלבום", "Album"));
        EditText genre = metadataField(tr("סוג מוזיקלי", "Genre"));
        box.addView(artist);
        box.addView(albumArtist);
        box.addView(album);
        box.addView(genre);

        Runnable load = () -> {
            Song s = analyzedSongs.get(songSpinner.getSelectedItemPosition());
            artist.setText(nullToEmpty(s.artist));
            albumArtist.setText(nullToEmpty(s.albumArtist));
            album.setText(nullToEmpty(s.album));
            genre.setText(nullToEmpty(s.genre));
        };
        songSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { load.run(); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        load.run();

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(tr("תיקון מידע לשיר", "Edit song metadata"))
                .setView(box)
                .setPositiveButton(tr("שמור", "Save"), null)
                .setNeutralButton(tr("אפס תיקון", "Reset override"), null)
                .setNegativeButton(tr("ביטול", "Cancel"), null)
                .create();
        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                Song s = analyzedSongs.get(songSpinner.getSelectedItemPosition());
                s.artist = trimToNull(artist.getText().toString());
                s.albumArtist = trimToNull(albumArtist.getText().toString());
                s.album = trimToNull(album.getText().toString());
                String enteredGenre = trimToNull(genre.getText().toString());
                s.genre = enteredGenre == null ? null : canonicalGenre(enteredGenre);
                s.genreSource = s.genre == null ? null : "תיקון ידני";
                s.invalidateScheduleKeys();
                saveManualOverride(s);
                refreshFilterOptions();
                showAnalysisSummary();
                Toast.makeText(this, tr("התיקון נשמר", "Correction saved"), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                Song s = analyzedSongs.get(songSpinner.getSelectedItemPosition());
                clearManualOverride(s);
                readMetadata(this, s);
                s.invalidateScheduleKeys();
                refreshFilterOptions();
                showAnalysisSummary();
                Toast.makeText(this, tr("התיקון הידני אופס", "Manual override reset"), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    private EditText metadataField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private void confirmClearCache() {
        new AlertDialog.Builder(this)
                .setTitle(tr("ניקוי מטמון", "Clear cache"))
                .setMessage(tr("למחוק תוצאות ניתוח אודיו שמורות? תיקונים ידניים לא יימחקו.", "Delete cached audio-analysis results? Manual corrections will not be deleted."))
                .setPositiveButton(tr("נקה", "Clear"), (d, w) -> {
                    SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    for (String key : prefs.getAll().keySet()) {
                        if (key.startsWith(CACHE_PREFIX)) editor.remove(key);
                    }
                    editor.apply();
                    analyzedSongs.clear();
                    refreshFilterOptions();
                    BackgroundWorkService.clearAnalysisSnapshot(getApplicationContext());
                    lastAppliedAnalysisRevision = -1;
                    createButton.setEnabled(false);
                    editMetadataButton.setEnabled(false);
                    statusText.setText(tr("מטמון הניתוח נוקה. יש לבצע סריקה מחדש.", "Analysis cache cleared. Run a new scan."));
                    resultText.setText("");
                })
                .setNegativeButton(tr("ביטול", "Cancel"), null)
                .show();
    }

    static boolean loadCachedAnalysis(Context context, Song song) {
        try {
            String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(CACHE_PREFIX + song.cacheKey(), null);
            if (json == null) return false;
            JSONObject o = new JSONObject(json);
            if (o.optInt("v", 0) != CACHE_VERSION) return false;
            if (o.optLong("size", -1) != song.size) return false;
            if (o.optLong("modified", -1) != song.lastModified) return false;
            song.rmsDb = o.getDouble("rms");
            song.bpm = o.getDouble("bpm");
            song.activity = o.getDouble("activity");
            song.title = jsonNullToString(o, "title");
            song.artist = jsonNullToString(o, "artist");
            song.albumArtist = jsonNullToString(o, "albumArtist");
            song.album = jsonNullToString(o, "album");
            song.genre = jsonNullToString(o, "genre");
            song.genreSource = jsonNullToString(o, "genreSource");
            song.artistSource = jsonNullToString(o, "artistSource");
            song.analyzed = true;
            song.fromCache = true;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static void saveCachedAnalysis(Context context, Song song) {
        try {
            JSONObject o = new JSONObject();
            o.put("v", CACHE_VERSION);
            o.put("size", song.size);
            o.put("modified", song.lastModified);
            o.put("rms", song.rmsDb);
            o.put("bpm", song.bpm);
            o.put("activity", song.activity);
            putNullable(o, "title", song.title);
            putNullable(o, "artist", song.artist);
            putNullable(o, "albumArtist", song.albumArtist);
            putNullable(o, "album", song.album);
            putNullable(o, "genre", song.genre);
            putNullable(o, "genreSource", song.genreSource);
            putNullable(o, "artistSource", song.artistSource);
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(CACHE_PREFIX + song.cacheKey(), o.toString()).apply();
        } catch (Exception ignored) {}
    }

    static void applyManualOverride(Context context, Song song) {
        try {
            String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(OVERRIDE_PREFIX + song.cacheKey(), null);
            if (json == null) return;
            JSONObject o = new JSONObject(json);
            song.artist = jsonNullToString(o, "artist");
            song.albumArtist = jsonNullToString(o, "albumArtist");
            song.album = jsonNullToString(o, "album");
            song.genre = jsonNullToString(o, "genre");
            if (song.genre != null) song.genreSource = "תיקון ידני";
        } catch (Exception ignored) {}
    }

    private void saveManualOverride(Song song) {
        try {
            JSONObject o = new JSONObject();
            putNullable(o, "artist", song.artist);
            putNullable(o, "albumArtist", song.albumArtist);
            putNullable(o, "album", song.album);
            putNullable(o, "genre", song.genre);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(OVERRIDE_PREFIX + song.cacheKey(), o.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void clearManualOverride(Song song) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(OVERRIDE_PREFIX + song.cacheKey()).apply();
    }

    private static void putNullable(JSONObject o, String key, String value) throws Exception {
        if (value == null) o.put(key, JSONObject.NULL); else o.put(key, value);
    }

    private static String jsonNullToString(JSONObject o, String key) {
        if (!o.has(key) || o.isNull(key)) return null;
        String s = o.optString(key, null);
        return trimToNull(s);
    }

    private void openPoweramp() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.maxmpz.audioplayer");
        if (launch == null) {
            Toast.makeText(this, tr("Poweramp לא נמצא מותקן במכשיר", "Poweramp is not installed on this device"), Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(launch);
    }

    static String normalizedPlaylistName(String raw) {
        String s = raw == null ? "" : raw.trim();
        s = s.replace('/', '_').replace('\\', '_').replace('\n', ' ').replace('\r', ' ');
        if (s.isEmpty()) s = DEFAULT_PLAYLIST_NAME;
        if (!s.toLowerCase(Locale.ROOT).endsWith(".m3u8")) s += ".m3u8";
        return s;
    }

    private static String stripExtension(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private static String trimToNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }

    private static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    private static String normalizeGroup(String input) {
        String s = trimToNull(input);
        if (s == null) return "";
        s = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        s = s.toLowerCase(Locale.ROOT).replace('&', ' ');
        if (s.endsWith(", the")) s = "the " + s.substring(0, s.length() - 5).trim();
        s = s.replaceAll("[^\\p{L}\\p{N}]+", " ").trim().replaceAll("\\s+", " ");
        if (s.startsWith("the ")) s = s.substring(4).trim();
        return s;
    }

    private static String normalizeArtistKey(String artist, String title) {
        String a = trimToNull(artist);
        if (a == null) return "";

        // Compilation labels are not the performer. Strip only explicit collection
        // suffixes; do not guess from audio or from arbitrary words.
        String cleaned = a.replaceAll("(?i)\\s*[-–—:]\\s*(platinum collection|greatest hits(?:\\s*cd\\s*\\d+)?|best of(?:\\s+.*)?)\\s*$", "").trim();
        if (!cleaned.isEmpty() && !cleaned.equals(a)) a = cleaned;

        String titleArtist = titleArtistPrefix(title);
        String aNorm = normalizeGroup(a);
        String aCompact = aNorm.replace(" ", "");
        if (titleArtist != null) {
            String tNorm = normalizeGroup(titleArtist);
            String tCompact = tNorm.replace(" ", "");
            boolean genericCollection = aNorm.contains("star mark") && aNorm.contains("greatest hits");
            boolean exactNoSpaces = !tCompact.isEmpty() && aCompact.equals(tCompact);
            boolean channelSuffix = !tCompact.isEmpty() && (
                    aCompact.equals(tCompact + "music")
                            || aCompact.equals(tCompact + "official")
                            || aCompact.equals(tCompact + "vevo")
                            || aCompact.equals(tCompact + "officialmusic")
                            || aCompact.equals(tCompact + "musicOfficial".toLowerCase(Locale.ROOT))
            );
            boolean genericChannel = aCompact.endsWith("vevo") || aCompact.endsWith("official");
            if (genericCollection || exactNoSpaces || channelSuffix || genericChannel) {
                a = titleArtist;
            }
        }

        // Compact only the scheduling key. This merges harmless formatting differences
        // such as "LeonardCohen" vs "Leonard Cohen" without changing displayed metadata.
        return normalizeGroup(a).replace(" ", "");
    }

    private static String titleArtistPrefix(String title) {
        String t = trimToNull(title);
        if (t == null) return null;
        String[] separators = {" — ", " – ", " - "};
        for (String sep : separators) {
            int i = t.indexOf(sep);
            if (i > 1) {
                String prefix = t.substring(0, i).trim();
                if (prefix.length() >= 2 && prefix.length() <= 80) return prefix;
            }
        }
        return null;
    }

    private static String titleFamily(String title) {
        String s = stripExtension(title == null ? "" : title).toLowerCase(Locale.ROOT);
        s = s.replaceAll("\\([^)]*(remaster|remastered|live|mono|stereo|version|mix|edit|demo|take|radio|acoustic)[^)]*\\)", " ");
        s = s.replaceAll("\\[[^]]*(remaster|remastered|live|mono|stereo|version|mix|edit|demo|take|radio|acoustic)[^]]*]", " ");
        s = s.replaceAll("[-–—]\\s*(remaster(ed)?|live|mono|stereo|version|mix|edit|demo|take|radio edit|acoustic).*", " ");
        s = s.replaceAll("\\b(19|20)\\d{2}\\b", " ");
        return normalizeGroup(s);
    }

    private static String sha256(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < 12; i++) out.append(String.format(Locale.ROOT, "%02x", bytes[i]));
            return out.toString();
        } catch (Exception e) {
            return Integer.toHexString(s.hashCode());
        }
    }

    private static void increment(Map<String, Integer> map, String key) {
        String t = trimToNull(key);
        if (t == null) return;
        map.put(t, map.containsKey(t) ? map.get(t) + 1 : 1);
    }

    private static void incrementKey(Map<String, Integer> map, String key) {
        if (key == null || key.isEmpty()) return;
        map.put(key, map.containsKey(key) ? map.get(key) + 1 : 1);
    }

    private static int clampInt(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    static String safeMessage(Exception e) {
        String m = e.getMessage();
        return (m == null || m.trim().isEmpty()) ? e.getClass().getSimpleName() : m;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        // EN: Long-running work belongs to BackgroundWorkService, not this Activity.
        //     Closing the screen does not cancel it; persisted state/snapshot allow recovery.
        // HE: העבודה הארוכה שייכת לשירות הרקע ולא ל-Activity. סגירת המסך אינה מבטלת
        //     את המשימה; מצב שמור ו-snapshot מאפשרים שחזור.
        main.removeCallbacks(uiStatePoller);
        super.onDestroy();
    }

    private static final class SimpleItemSelectedListener implements AdapterView.OnItemSelectedListener {
        private final Runnable callback;
        SimpleItemSelectedListener(Runnable callback) { this.callback = callback; }
        @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { callback.run(); }
        @Override public void onNothingSelected(AdapterView<?> parent) {}
    }

    static final class AudioFeatures {
        final double rmsDb;
        final double bpm;
        final double activity;
        AudioFeatures(double rmsDb, double bpm, double activity) {
            this.rmsDb = rmsDb;
            this.bpm = bpm;
            this.activity = activity;
        }
    }

    static final class Song {
        final String name;
        final String relativePath;
        final String documentId;
        final Uri uri;
        final long size;
        final long lastModified;
        boolean analyzed;
        boolean fromCache;
        double rmsDb;
        double bpm;
        double activity;
        double energy;
        String title;
        String artist;
        String albumArtist;
        String album;
        String genre;
        String genreSource;
        String artistSource;

        Song(String name, String relativePath, String documentId, Uri uri, long size, long lastModified) {
            this.name = name;
            this.relativePath = relativePath;
            this.documentId = documentId;
            this.uri = uri;
            this.size = size;
            this.lastModified = lastModified;
        }

        String displayTitle() {
            return title != null ? title : stripExtension(name);
        }

        String displayTitleWithArtist() {
            String a = artistIdentity();
            return a == null || a.trim().isEmpty() ? displayTitle() : a + " — " + displayTitle();
        }

        String artistIdentity() {
            String aa = trimToNull(albumArtist);
            if (aa != null) {
                String k = normalizeGroup(aa);
                if (!k.equals("various artists") && !k.equals("various") && !k.equals("v a")) return aa;
            }
            return trimToNull(artist);
        }

        private String artistKeyCache;
        private String genreKeyCache;
        private String albumKeyCache;
        private String titleFamilyKeyCache;

        void invalidateScheduleKeys() {
            artistKeyCache = null;
            genreKeyCache = null;
            albumKeyCache = null;
            titleFamilyKeyCache = null;
        }

        void refreshScheduleKeys() {
            artistKeyCache = normalizeArtistKey(artistIdentity(), displayTitle());
            genreKeyCache = normalizeGroup(genre);
            String a = normalizeGroup(album);
            albumKeyCache = a.isEmpty() ? "" : artistKeyCache + "|" + a;
            titleFamilyKeyCache = titleFamily(displayTitle());
        }

        String artistKey() { if (artistKeyCache == null) refreshScheduleKeys(); return artistKeyCache; }
        String genreKey() { if (genreKeyCache == null) refreshScheduleKeys(); return genreKeyCache; }
        String albumKey() { if (albumKeyCache == null) refreshScheduleKeys(); return albumKeyCache; }
        String titleFamilyKey() { if (titleFamilyKeyCache == null) refreshScheduleKeys(); return titleFamilyKeyCache; }
        String cacheKey() { return sha256(documentId); }
    }

    static final class Placement {
        final int target;
        final Song song;
        Placement(int target, Song song) {
            this.target = target;
            this.song = song;
        }
    }

    static final class ScheduleStats {
        final Map<String, Integer> artistCounts = new HashMap<>();
        final Map<String, Integer> genreCounts = new HashMap<>();
        final Map<String, Integer> albumCounts = new HashMap<>();
        final Map<String, Integer> titleCounts = new HashMap<>();
        ScheduleStats(List<Song> songs) {
            for (Song s : songs) {
                incrementKey(artistCounts, s.artistKey());
                incrementKey(genreCounts, s.genreKey());
                incrementKey(albumCounts, s.albumKey());
                incrementKey(titleCounts, s.titleFamilyKey());
            }
        }
    }

    static final class ScheduleState {
        final Map<String, Integer> artistUsed = new HashMap<>();
        final Map<String, Integer> genreUsed = new HashMap<>();
        final Map<String, Integer> albumUsed = new HashMap<>();
        final Map<String, Integer> titleUsed = new HashMap<>();
        final Map<String, Integer> artistLast = new HashMap<>();
        final Map<String, Integer> genreLast = new HashMap<>();
        final Map<String, Integer> albumLast = new HashMap<>();
        final Map<String, Integer> titleLast = new HashMap<>();

        void record(Song s, int pos) {
            recordKey(s.artistKey(), pos, artistUsed, artistLast);
            recordKey(s.genreKey(), pos, genreUsed, genreLast);
            recordKey(s.albumKey(), pos, albumUsed, albumLast);
            recordKey(s.titleFamilyKey(), pos, titleUsed, titleLast);
        }

        private void recordKey(String key, int pos, Map<String, Integer> used, Map<String, Integer> last) {
            if (key == null || key.isEmpty()) return;
            used.put(key, used.containsKey(key) ? used.get(key) + 1 : 1);
            last.put(key, pos);
        }
    }
}
