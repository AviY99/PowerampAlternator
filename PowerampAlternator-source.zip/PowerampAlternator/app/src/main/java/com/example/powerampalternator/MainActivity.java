package com.example.powerampalternator;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.UriPermission;
import android.database.Cursor;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_TREE = 1001;
    private static final String PREFS = "prefs";
    private static final String PREF_TREE_URI = "tree_uri";
    private static final String PLAYLIST_NAME = "Poweramp_Alternating.m3u8";

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private Uri treeUri;
    private TextView folderText;
    private TextView statusText;
    private TextView resultText;
    private ProgressBar progressBar;
    private Button createButton;
    private Button powerampButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        restoreFolder();
    }

    private void buildUi() {
        int pad = dp(20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Poweramp Alternator");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("יוצר פלייליסט: שיר רגוע → שיר קצבי → רגוע → קצבי");
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(-1, -2);
        subtitleLp.topMargin = dp(8);
        root.addView(subtitle, subtitleLp);

        Button folderButton = new Button(this);
        folderButton.setText("בחר תיקיית מוזיקה");
        folderButton.setOnClickListener(v -> chooseFolder());
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(-1, -2);
        buttonLp.topMargin = dp(20);
        root.addView(folderButton, buttonLp);

        folderText = new TextView(this);
        folderText.setText("לא נבחרה תיקייה");
        folderText.setTextSize(14);
        LinearLayout.LayoutParams folderLp = new LinearLayout.LayoutParams(-1, -2);
        folderLp.topMargin = dp(8);
        root.addView(folderText, folderLp);

        createButton = new Button(this);
        createButton.setText("סרוק וצור פלייליסט ל-Poweramp");
        createButton.setEnabled(false);
        createButton.setOnClickListener(v -> createPlaylist());
        LinearLayout.LayoutParams createLp = new LinearLayout.LayoutParams(-1, -2);
        createLp.topMargin = dp(12);
        root.addView(createButton, createLp);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-1, dp(12));
        progressLp.topMargin = dp(12);
        root.addView(progressBar, progressLp);

        statusText = new TextView(this);
        statusText.setText("הניתוח מתבצע מקומית על הטלפון.");
        statusText.setTextSize(15);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(12);
        root.addView(statusText, statusLp);

        powerampButton = new Button(this);
        powerampButton.setText("פתח Poweramp");
        powerampButton.setVisibility(View.GONE);
        powerampButton.setOnClickListener(v -> openPoweramp());
        LinearLayout.LayoutParams paLp = new LinearLayout.LayoutParams(-1, -2);
        paLp.topMargin = dp(12);
        root.addView(powerampButton, paLp);

        resultText = new TextView(this);
        resultText.setTextSize(14);
        resultText.setTextIsSelectable(true);
        LinearLayout.LayoutParams resultLp = new LinearLayout.LayoutParams(-1, -2);
        resultLp.topMargin = dp(16);
        root.addView(resultText, resultLp);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private void restoreFolder() {
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_TREE_URI, null);
        if (saved == null) return;
        Uri candidate = Uri.parse(saved);
        boolean stillGranted = false;
        for (UriPermission p : getContentResolver().getPersistedUriPermissions()) {
            if (p.getUri().equals(candidate) && p.isReadPermission()) {
                stillGranted = true;
                break;
            }
        }
        if (stillGranted) {
            treeUri = candidate;
            folderText.setText("תיקייה: " + friendlyTreeName(candidate));
            createButton.setEnabled(true);
        }
    }

    private void chooseFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, PICK_TREE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_TREE || resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        Uri chosen = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            getContentResolver().takePersistableUriPermission(chosen, flags);
        } catch (SecurityException ignored) {
        }
        treeUri = chosen;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_TREE_URI, chosen.toString()).apply();
        folderText.setText("תיקייה: " + friendlyTreeName(chosen));
        createButton.setEnabled(true);
        statusText.setText("מוכן לסריקה.");
        resultText.setText("");
    }

    private String friendlyTreeName(Uri uri) {
        try {
            String id = DocumentsContract.getTreeDocumentId(uri);
            int colon = id.indexOf(':');
            String path = colon >= 0 ? id.substring(colon + 1) : id;
            return path.isEmpty() ? id : path;
        } catch (Exception e) {
            return uri.toString();
        }
    }

    private void createPlaylist() {
        if (treeUri == null) return;
        setBusy(true);
        statusText.setText("סורק קבצי מוזיקה…");
        resultText.setText("");

        final Uri selected = treeUri;
        worker.execute(() -> {
            try {
                List<Song> songs = new ArrayList<>();
                String rootId = DocumentsContract.getTreeDocumentId(selected);
                scanDirectory(selected, rootId, "", songs);

                if (songs.size() < 2) {
                    throw new IllegalStateException("נדרשים לפחות שני קובצי מוזיקה בתיקייה שנבחרה.");
                }

                final int total = songs.size();
                main.post(() -> {
                    progressBar.setVisibility(View.VISIBLE);
                    progressBar.setProgress(0);
                    statusText.setText("נמצאו " + total + " שירים. מנתח קצב ואנרגיה…");
                });

                int analyzed = 0;
                for (Song song : songs) {
                    try {
                        AudioFeatures f = analyzeAudio(song.uri);
                        song.rmsDb = f.rmsDb;
                        song.bpm = f.bpm;
                        song.activity = f.activity;
                        song.analyzed = true;
                    } catch (Exception e) {
                        song.analyzed = false;
                    }
                    analyzed++;
                    final int done = analyzed;
                    final String name = song.name;
                    main.post(() -> {
                        progressBar.setProgress((int) (done * 100.0 / total));
                        statusText.setText("מנתח " + done + "/" + total + ": " + name);
                    });
                }

                List<Song> usable = new ArrayList<>();
                for (Song s : songs) if (s.analyzed) usable.add(s);
                if (usable.size() < 2) {
                    throw new IllegalStateException("לא הצלחתי לנתח מספיק קובצי אודיו. נסה תיקייה עם MP3/FLAC/M4A רגילים.");
                }

                scoreEnergy(usable);
                List<Song> playlist = alternate(usable);
                Uri playlistUri = writePlaylist(selected, playlist);
                String summary = buildSummary(playlist, songs.size() - usable.size(), playlistUri);

                main.post(() -> {
                    statusText.setText("הפלייליסט נוצר בהצלחה: " + PLAYLIST_NAME);
                    resultText.setText(summary);
                    powerampButton.setVisibility(View.VISIBLE);
                    setBusy(false);
                    Toast.makeText(this, "נוצר פלייליסט ל-Poweramp", Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                main.post(() -> {
                    statusText.setText("שגיאה: " + safeMessage(e));
                    setBusy(false);
                });
            }
        });
    }

    private void setBusy(boolean busy) {
        createButton.setEnabled(!busy && treeUri != null);
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
        if (!busy) progressBar.setProgress(0);
    }

    private void scanDirectory(Uri tree, String parentDocumentId, String relativeDir, List<Song> out) throws Exception {
        ContentResolver resolver = getContentResolver();
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentDocumentId);
        String[] projection = {
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
        };
        try (Cursor cursor = resolver.query(children, projection, null, null, null)) {
            if (cursor == null) return;
            int idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            int mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE);
            while (cursor.moveToNext()) {
                String id = cursor.getString(idCol);
                String name = cursor.getString(nameCol);
                String mime = cursor.getString(mimeCol);
                if (name == null) name = "unknown";
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    String nextRel = relativeDir.isEmpty() ? name : relativeDir + "/" + name;
                    scanDirectory(tree, id, nextRel, out);
                } else if (isAudio(name, mime)) {
                    Uri docUri = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                    String rel = relativeDir.isEmpty() ? name : relativeDir + "/" + name;
                    out.add(new Song(name, rel, id, docUri));
                }
            }
        }
    }

    private boolean isAudio(String name, String mime) {
        if (mime != null && mime.startsWith("audio/")) return true;
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".mp3") || lower.endsWith(".flac") || lower.endsWith(".m4a")
                || lower.endsWith(".aac") || lower.endsWith(".ogg") || lower.endsWith(".opus")
                || lower.endsWith(".wav") || lower.endsWith(".wma") || lower.endsWith(".ape")
                || lower.endsWith(".alac") || lower.endsWith(".mka");
    }

    private AudioFeatures analyzeAudio(Uri uri) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec codec = null;
        try {
            extractor.setDataSource(this, uri, null);
            int audioTrack = -1;
            MediaFormat inputFormat = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrack = i;
                    inputFormat = f;
                    break;
                }
            }
            if (audioTrack < 0 || inputFormat == null) throw new IllegalArgumentException("אין ערוץ אודיו");

            extractor.selectTrack(audioTrack);
            long durationUs = inputFormat.containsKey(MediaFormat.KEY_DURATION)
                    ? inputFormat.getLong(MediaFormat.KEY_DURATION) : 0L;
            long sampleStartUs = durationUs > 45_000_000L ? Math.min(30_000_000L, durationUs / 5) : 0L;
            long sampleLengthUs = 18_000_000L;
            long sampleEndUs = durationUs > 0 ? Math.min(durationUs, sampleStartUs + sampleLengthUs)
                    : sampleStartUs + sampleLengthUs;
            if (sampleStartUs > 0) extractor.seekTo(sampleStartUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);

            String mime = inputFormat.getString(MediaFormat.KEY_MIME);
            codec = MediaCodec.createDecoderByType(mime);
            codec.configure(inputFormat, null, null, 0);
            codec.start();

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            boolean outputDone = false;
            PcmAnalyzer analyzer = null;
            long wallDeadline = System.currentTimeMillis() + 25_000L;

            while (!outputDone && System.currentTimeMillis() < wallDeadline) {
                if (!inputDone) {
                    int inputIndex = codec.dequeueInputBuffer(10_000);
                    if (inputIndex >= 0) {
                        ByteBuffer inputBuffer = codec.getInputBuffer(inputIndex);
                        if (inputBuffer == null) continue;
                        inputBuffer.clear();
                        long sampleTime = extractor.getSampleTime();
                        if (sampleTime < 0 || sampleTime > sampleEndUs) {
                            codec.queueInputBuffer(inputIndex, 0, 0, Math.max(0, sampleTime), MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            int size = extractor.readSampleData(inputBuffer, 0);
                            if (size < 0) {
                                codec.queueInputBuffer(inputIndex, 0, 0, Math.max(0, sampleTime), MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inputDone = true;
                            } else {
                                codec.queueInputBuffer(inputIndex, 0, size, sampleTime, extractor.getSampleFlags());
                                extractor.advance();
                            }
                        }
                    }
                }

                int outIndex = codec.dequeueOutputBuffer(info, 10_000);
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat outFormat = codec.getOutputFormat();
                    analyzer = new PcmAnalyzer(outFormat);
                } else if (outIndex >= 0) {
                    if (analyzer == null) analyzer = new PcmAnalyzer(codec.getOutputFormat());
                    ByteBuffer out = codec.getOutputBuffer(outIndex);
                    if (out != null && info.size > 0) {
                        out.position(info.offset);
                        out.limit(info.offset + info.size);
                        analyzer.consume(out.slice().order(ByteOrder.LITTLE_ENDIAN));
                    }
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true;
                    codec.releaseOutputBuffer(outIndex, false);
                }
            }
            if (analyzer == null || analyzer.sampleCount < 4000) throw new IllegalStateException("אין מספיק PCM");
            return analyzer.finish();
        } finally {
            try { extractor.release(); } catch (Exception ignored) {}
            if (codec != null) {
                try { codec.stop(); } catch (Exception ignored) {}
                try { codec.release(); } catch (Exception ignored) {}
            }
        }
    }

    private static final class PcmAnalyzer {
        final int sampleRate;
        final int channels;
        final int encoding;
        final int windowSamples;
        final List<Double> envelope = new ArrayList<>();
        double windowSq;
        int windowCount;
        double totalSq;
        long sampleCount;

        PcmAnalyzer(MediaFormat f) {
            sampleRate = f.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? f.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
            channels = f.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? Math.max(1, f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)) : 2;
            int enc = AudioFormat.ENCODING_PCM_16BIT;
            try {
                if (f.containsKey("pcm-encoding")) enc = f.getInteger("pcm-encoding");
            } catch (Exception ignored) {}
            encoding = enc;
            windowSamples = 1024;
        }

        void consume(ByteBuffer b) {
            if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
                while (b.remaining() >= 4 * channels) {
                    double mono = 0;
                    for (int c = 0; c < channels; c++) mono += clamp(b.getFloat());
                    add(mono / channels);
                }
            } else if (encoding == AudioFormat.ENCODING_PCM_8BIT) {
                while (b.remaining() >= channels) {
                    double mono = 0;
                    for (int c = 0; c < channels; c++) mono += ((b.get() & 0xff) - 128) / 128.0;
                    add(mono / channels);
                }
            } else {
                while (b.remaining() >= 2 * channels) {
                    double mono = 0;
                    for (int c = 0; c < channels; c++) mono += b.getShort() / 32768.0;
                    add(mono / channels);
                }
            }
        }

        private static double clamp(float v) {
            if (v > 1f) return 1;
            if (v < -1f) return -1;
            return v;
        }

        private void add(double x) {
            double sq = x * x;
            totalSq += sq;
            sampleCount++;
            windowSq += sq;
            windowCount++;
            if (windowCount >= windowSamples) {
                envelope.add(Math.sqrt(windowSq / windowCount));
                windowSq = 0;
                windowCount = 0;
            }
        }

        AudioFeatures finish() {
            if (windowCount > 0) envelope.add(Math.sqrt(windowSq / windowCount));
            double rms = Math.sqrt(totalSq / Math.max(1, sampleCount));
            double rmsDb = 20.0 * Math.log10(rms + 1e-9);

            if (envelope.size() < 8) return new AudioFeatures(rmsDb, 0, 0);
            double[] onset = new double[envelope.size() - 1];
            double onsetSum = 0;
            for (int i = 1; i < envelope.size(); i++) {
                onset[i - 1] = Math.max(0.0, envelope.get(i) - envelope.get(i - 1));
                onsetSum += onset[i - 1];
            }
            double mean = onsetSum / onset.length;
            double variance = 0;
            for (double v : onset) {
                double d = v - mean;
                variance += d * d;
            }
            double std = Math.sqrt(variance / onset.length);
            double avgEnv = 0;
            for (double v : envelope) avgEnv += v;
            avgEnv /= envelope.size();
            double activity = std / (avgEnv + 1e-7);

            double frameRate = sampleRate / (double) windowSamples;
            int bestLag = -1;
            double best = Double.NEGATIVE_INFINITY;
            int minLag = Math.max(1, (int) Math.floor(frameRate * 60.0 / 180.0));
            int maxLag = Math.min(onset.length / 2, (int) Math.ceil(frameRate * 60.0 / 65.0));
            for (int lag = minLag; lag <= maxLag; lag++) {
                double corr = 0, a2 = 0, b2 = 0;
                for (int i = lag; i < onset.length; i++) {
                    double a = onset[i] - mean;
                    double bb = onset[i - lag] - mean;
                    corr += a * bb;
                    a2 += a * a;
                    b2 += bb * bb;
                }
                double normalized = corr / (Math.sqrt(a2 * b2) + 1e-9);
                if (normalized > best) {
                    best = normalized;
                    bestLag = lag;
                }
            }
            double bpm = bestLag > 0 && best > 0.04 ? 60.0 * frameRate / bestLag : 0.0;
            if (bpm > 0 && bpm < 75) bpm *= 2.0;
            if (bpm > 180) bpm /= 2.0;
            return new AudioFeatures(rmsDb, bpm, activity);
        }
    }

    private void scoreEnergy(List<Song> songs) {
        double minRms = Double.POSITIVE_INFINITY, maxRms = Double.NEGATIVE_INFINITY;
        double minAct = Double.POSITIVE_INFINITY, maxAct = Double.NEGATIVE_INFINITY;
        double minBpm = Double.POSITIVE_INFINITY, maxBpm = Double.NEGATIVE_INFINITY;
        for (Song s : songs) {
            minRms = Math.min(minRms, s.rmsDb); maxRms = Math.max(maxRms, s.rmsDb);
            minAct = Math.min(minAct, s.activity); maxAct = Math.max(maxAct, s.activity);
            if (s.bpm > 0) { minBpm = Math.min(minBpm, s.bpm); maxBpm = Math.max(maxBpm, s.bpm); }
        }
        if (!Double.isFinite(minBpm)) { minBpm = 80; maxBpm = 140; }
        for (Song s : songs) {
            double nr = norm(s.rmsDb, minRms, maxRms);
            double na = norm(s.activity, minAct, maxAct);
            double nb = s.bpm > 0 ? norm(s.bpm, minBpm, maxBpm) : 0.35;
            s.energy = 0.50 * nr + 0.30 * na + 0.20 * nb;
        }
    }

    private static double norm(double v, double min, double max) {
        if (!Double.isFinite(v) || max - min < 1e-9) return 0.5;
        return Math.max(0, Math.min(1, (v - min) / (max - min)));
    }

    private List<Song> alternate(List<Song> songs) {
        List<Song> sorted = new ArrayList<>(songs);
        sorted.sort(Comparator.comparingDouble(s -> s.energy));
        int quietCount = (sorted.size() + 1) / 2;
        List<Song> quiet = new ArrayList<>(sorted.subList(0, quietCount));
        List<Song> energetic = new ArrayList<>(sorted.subList(quietCount, sorted.size()));
        energetic.sort((a, b) -> Double.compare(b.energy, a.energy));

        List<Song> result = new ArrayList<>(sorted.size());
        int q = 0, e = 0;
        while (q < quiet.size() || e < energetic.size()) {
            if (q < quiet.size()) result.add(quiet.get(q++));
            if (e < energetic.size()) result.add(energetic.get(e++));
        }
        return result;
    }

    private Uri writePlaylist(Uri tree, List<Song> songs) throws Exception {
        ContentResolver resolver = getContentResolver();
        String rootId = DocumentsContract.getTreeDocumentId(tree);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, rootId);
        String[] projection = { DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME };
        try (Cursor c = resolver.query(children, projection, null, null, null)) {
            if (c != null) {
                int idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                while (c.moveToNext()) {
                    if (PLAYLIST_NAME.equalsIgnoreCase(c.getString(nameCol))) {
                        Uri old = DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(idCol));
                        try { DocumentsContract.deleteDocument(resolver, old); } catch (Exception ignored) {}
                        break;
                    }
                }
            }
        }

        Uri rootDoc = DocumentsContract.buildDocumentUriUsingTree(tree, rootId);
        Uri playlist = DocumentsContract.createDocument(resolver, rootDoc, "application/vnd.apple.mpegurl", PLAYLIST_NAME);
        if (playlist == null) throw new IllegalStateException("לא ניתן ליצור קובץ פלייליסט בתיקייה");

        StringBuilder m3u = new StringBuilder("#EXTM3U\n");
        for (Song s : songs) {
            m3u.append("#EXTINF:-1,").append(cleanLine(s.displayTitle())).append('\n');
            m3u.append(cleanLine(pathForPoweramp(s))).append('\n');
        }
        try (OutputStream os = resolver.openOutputStream(playlist, "wt")) {
            if (os == null) throw new IllegalStateException("לא ניתן לפתוח את קובץ הפלייליסט לכתיבה");
            os.write(m3u.toString().getBytes(StandardCharsets.UTF_8));
        }
        return playlist;
    }

    private String pathForPoweramp(Song s) {
        String absolute = absolutePathFromDocumentId(s.documentId);
        return absolute != null ? absolute : s.relativePath;
    }

    private String absolutePathFromDocumentId(String documentId) {
        int colon = documentId.indexOf(':');
        if (colon < 0) return null;
        String volume = documentId.substring(0, colon);
        String path = documentId.substring(colon + 1);
        if ("primary".equalsIgnoreCase(volume)) {
            return path.isEmpty() ? "/storage/emulated/0" : "/storage/emulated/0/" + path;
        }
        if (volume.matches("[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}")) {
            return path.isEmpty() ? "/storage/" + volume : "/storage/" + volume + "/" + path;
        }
        return null;
    }

    private String cleanLine(String s) {
        return s.replace('\n', ' ').replace('\r', ' ');
    }

    private String buildSummary(List<Song> playlist, int skipped, Uri playlistUri) {
        StringBuilder sb = new StringBuilder();
        sb.append("נוצרו ").append(playlist.size()).append(" שירים בסדר מתחלף.\n");
        if (skipped > 0) sb.append("דולגו ").append(skipped).append(" קבצים שלא ניתן היה לנתח.\n");
        sb.append("\nב-Poweramp בצע Rescan אם הפלייליסט לא מופיע מיד.\n\n");
        int show = Math.min(80, playlist.size());
        for (int i = 0; i < show; i++) {
            Song s = playlist.get(i);
            String kind = (i % 2 == 0) ? "רגוע" : "קצבי";
            sb.append(i + 1).append(". ").append(kind).append(" — ").append(s.displayTitle());
            if (s.bpm > 0) sb.append("  (~").append(Math.round(s.bpm)).append(" BPM)");
            sb.append('\n');
        }
        if (playlist.size() > show) sb.append("… ועוד ").append(playlist.size() - show).append(" שירים");
        return sb.toString();
    }

    private void openPoweramp() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.maxmpz.audioplayer");
        if (launch == null) {
            Toast.makeText(this, "Poweramp לא נמצא מותקן במכשיר", Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(launch);
    }

    private static String safeMessage(Exception e) {
        String m = e.getMessage();
        return (m == null || m.trim().isEmpty()) ? e.getClass().getSimpleName() : m;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        worker.shutdownNow();
    }

    private static final class AudioFeatures {
        final double rmsDb;
        final double bpm;
        final double activity;
        AudioFeatures(double rmsDb, double bpm, double activity) {
            this.rmsDb = rmsDb;
            this.bpm = bpm;
            this.activity = activity;
        }
    }

    private static final class Song {
        final String name;
        final String relativePath;
        final String documentId;
        final Uri uri;
        boolean analyzed;
        double rmsDb;
        double bpm;
        double activity;
        double energy;

        Song(String name, String relativePath, String documentId, Uri uri) {
            this.name = name;
            this.relativePath = relativePath;
            this.documentId = documentId;
            this.uri = uri;
        }

        String displayTitle() {
            int dot = name.lastIndexOf('.');
            return dot > 0 ? name.substring(0, dot) : name;
        }
    }
}
