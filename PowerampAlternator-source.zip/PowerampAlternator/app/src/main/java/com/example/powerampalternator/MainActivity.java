package com.example.powerampalternator;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.database.Cursor;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_TREE = 1001;
    private static final String PREFS = "prefs";
    private static final String PREF_TREE_URI = "tree_uri";
    private static final String PREF_THRESHOLD = "energy_threshold";
    private static final String PREF_RATIO = "ratio_index";
    private static final String PREF_MODE = "mode_index";
    private static final String PREF_PLAYLIST_NAME = "playlist_name";
    private static final String CACHE_PREFIX = "cache_song_";
    private static final String OVERRIDE_PREFIX = "override_song_";
    private static final int CACHE_VERSION = 2;
    private static final String DEFAULT_PLAYLIST_NAME = "Poweramp_Alternating.m3u8";

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private Uri treeUri;
    private TextView folderText;
    private TextView statusText;
    private TextView resultText;
    private TextView thresholdText;
    private ProgressBar progressBar;
    private Button analyzeButton;
    private Button createButton;
    private Button editMetadataButton;
    private Button powerampButton;
    private SeekBar thresholdSeek;
    private Spinner ratioSpinner;
    private Spinner modeSpinner;
    private EditText playlistNameEdit;

    private final List<Song> analyzedSongs = new ArrayList<>();
    private int lastSkipped = 0;
    private int lastCacheHits = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        restoreSettings();
        restoreFolder();
    }

    private void buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView title = new TextView(this);
        title.setText("Poweramp Alternator");
        title.setTextSize(27);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("ניתוח מקומי + פיזור חכם לפי אנרגיה, אמן/להקה, סוג, אלבום וגרסאות דומות");
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(-1, -2);
        subtitleLp.topMargin = dp(7);
        root.addView(subtitle, subtitleLp);

        Button folderButton = new Button(this);
        folderButton.setText("בחר תיקיית מוזיקה");
        folderButton.setOnClickListener(v -> chooseFolder());
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(-1, -2);
        buttonLp.topMargin = dp(16);
        root.addView(folderButton, buttonLp);

        folderText = new TextView(this);
        folderText.setText("לא נבחרה תיקייה");
        folderText.setTextSize(14);
        LinearLayout.LayoutParams folderLp = new LinearLayout.LayoutParams(-1, -2);
        folderLp.topMargin = dp(6);
        root.addView(folderText, folderLp);

        analyzeButton = new Button(this);
        analyzeButton.setText("סרוק ונתח את הספרייה");
        analyzeButton.setEnabled(false);
        analyzeButton.setOnClickListener(v -> analyzeLibrary());
        LinearLayout.LayoutParams analyzeLp = new LinearLayout.LayoutParams(-1, -2);
        analyzeLp.topMargin = dp(10);
        root.addView(analyzeButton, analyzeLp);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-1, dp(10));
        progressLp.topMargin = dp(10);
        root.addView(progressBar, progressLp);

        statusText = new TextView(this);
        statusText.setText("הניתוח מתבצע מקומית על הטלפון. מידע מוזיקלי נלקח קודם כל מתגיות הקובץ.");
        statusText.setTextSize(14);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(10);
        root.addView(statusText, statusLp);

        addSectionTitle(root, "הגדרות הפלייליסט");

        thresholdText = new TextView(this);
        thresholdText.setTextSize(14);
        root.addView(thresholdText, new LinearLayout.LayoutParams(-1, -2));

        thresholdSeek = new SeekBar(this);
        thresholdSeek.setMax(100);
        thresholdSeek.setProgress(50);
        thresholdSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateThresholdLabel();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                saveSettings();
                if (!analyzedSongs.isEmpty()) showAnalysisSummary();
            }
        });
        root.addView(thresholdSeek, new LinearLayout.LayoutParams(-1, -2));

        TextView ratioLabel = new TextView(this);
        ratioLabel.setText("יחס רצוי בין רגוע לקצבי:");
        ratioLabel.setTextSize(14);
        root.addView(ratioLabel, new LinearLayout.LayoutParams(-1, -2));

        ratioSpinner = new Spinner(this);
        List<String> ratios = Arrays.asList(
                "1 רגוע : 1 קצבי",
                "2 רגועים : 1 קצבי",
                "1 רגוע : 2 קצביים",
                "3 רגועים : 1 קצבי",
                "1 רגוע : 3 קצביים"
        );
        ArrayAdapter<String> ratioAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ratios);
        ratioAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ratioSpinner.setAdapter(ratioAdapter);
        ratioSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(this::saveSettings));
        root.addView(ratioSpinner, new LinearLayout.LayoutParams(-1, -2));

        TextView modeLabel = new TextView(this);
        modeLabel.setText("מצב סידור:");
        modeLabel.setTextSize(14);
        LinearLayout.LayoutParams modeLabelLp = new LinearLayout.LayoutParams(-1, -2);
        modeLabelLp.topMargin = dp(6);
        root.addView(modeLabel, modeLabelLp);

        modeSpinner = new Spinner(this);
        List<String> modes = Arrays.asList(
                "מתחלף ומאוזן",
                "עלייה הדרגתית באנרגיה",
                "ירידה הדרגתית באנרגיה"
        );
        ArrayAdapter<String> modeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, modes);
        modeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        modeSpinner.setAdapter(modeAdapter);
        modeSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(this::saveSettings));
        root.addView(modeSpinner, new LinearLayout.LayoutParams(-1, -2));

        TextView nameLabel = new TextView(this);
        nameLabel.setText("שם הפלייליסט:");
        nameLabel.setTextSize(14);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(-1, -2);
        nameLp.topMargin = dp(6);
        root.addView(nameLabel, nameLp);

        playlistNameEdit = new EditText(this);
        playlistNameEdit.setSingleLine(true);
        playlistNameEdit.setText(DEFAULT_PLAYLIST_NAME);
        root.addView(playlistNameEdit, new LinearLayout.LayoutParams(-1, -2));

        createButton = new Button(this);
        createButton.setText("צור פלייליסט חכם ל-Poweramp");
        createButton.setEnabled(false);
        createButton.setOnClickListener(v -> createPlaylistFromAnalysis());
        LinearLayout.LayoutParams createLp = new LinearLayout.LayoutParams(-1, -2);
        createLp.topMargin = dp(10);
        root.addView(createButton, createLp);

        editMetadataButton = new Button(this);
        editMetadataButton.setText("תקן אמן / להקה / אלבום / סוג");
        editMetadataButton.setEnabled(false);
        editMetadataButton.setOnClickListener(v -> showMetadataEditor());
        LinearLayout.LayoutParams editLp = new LinearLayout.LayoutParams(-1, -2);
        editLp.topMargin = dp(6);
        root.addView(editMetadataButton, editLp);

        Button clearCacheButton = new Button(this);
        clearCacheButton.setText("נקה מטמון ניתוח");
        clearCacheButton.setOnClickListener(v -> confirmClearCache());
        LinearLayout.LayoutParams cacheLp = new LinearLayout.LayoutParams(-1, -2);
        cacheLp.topMargin = dp(6);
        root.addView(clearCacheButton, cacheLp);

        powerampButton = new Button(this);
        powerampButton.setText("פתח Poweramp");
        powerampButton.setVisibility(View.GONE);
        powerampButton.setOnClickListener(v -> openPoweramp());
        LinearLayout.LayoutParams paLp = new LinearLayout.LayoutParams(-1, -2);
        paLp.topMargin = dp(8);
        root.addView(powerampButton, paLp);

        resultText = new TextView(this);
        resultText.setTextSize(13);
        resultText.setTextIsSelectable(true);
        LinearLayout.LayoutParams resultLp = new LinearLayout.LayoutParams(-1, -2);
        resultLp.topMargin = dp(14);
        root.addView(resultText, resultLp);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
        updateThresholdLabel();
    }

    private void addSectionTitle(LinearLayout root, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(18);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(16);
        lp.bottomMargin = dp(6);
        root.addView(t, lp);
    }

    private void restoreSettings() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        thresholdSeek.setProgress(p.getInt(PREF_THRESHOLD, 50));
        ratioSpinner.setSelection(clampInt(p.getInt(PREF_RATIO, 0), 0, 4));
        modeSpinner.setSelection(clampInt(p.getInt(PREF_MODE, 0), 0, 2));
        playlistNameEdit.setText(p.getString(PREF_PLAYLIST_NAME, DEFAULT_PLAYLIST_NAME));
        updateThresholdLabel();
    }

    private void saveSettings() {
        if (thresholdSeek == null || ratioSpinner == null || modeSpinner == null || playlistNameEdit == null) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt(PREF_THRESHOLD, thresholdSeek.getProgress())
                .putInt(PREF_RATIO, ratioSpinner.getSelectedItemPosition())
                .putInt(PREF_MODE, modeSpinner.getSelectedItemPosition())
                .putString(PREF_PLAYLIST_NAME, playlistNameEdit.getText().toString())
                .apply();
    }

    private void updateThresholdLabel() {
        if (thresholdText != null && thresholdSeek != null) {
            thresholdText.setText("סף אנרגיה רגוע/קצבי: " + thresholdSeek.getProgress() + "%");
        }
    }

    private void restoreFolder() {
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_TREE_URI, null);
        if (saved == null) return;
        Uri candidate = Uri.parse(saved);
        boolean stillGranted = false;
        for (UriPermission p : getContentResolver().getPersistedUriPermissions()) {
            if (p.getUri().equals(candidate) && p.isReadPermission()) {
                stillGranted = true;
                break;
            }
        }
        if (stillGranted) {
            treeUri = candidate;
            folderText.setText("תיקייה: " + friendlyTreeName(candidate));
            analyzeButton.setEnabled(true);
        }
    }

    private void chooseFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, PICK_TREE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_TREE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri chosen = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(chosen, flags); } catch (SecurityException ignored) {}
        treeUri = chosen;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_TREE_URI, chosen.toString()).apply();
        folderText.setText("תיקייה: " + friendlyTreeName(chosen));
        analyzeButton.setEnabled(true);
        analyzedSongs.clear();
        createButton.setEnabled(false);
        editMetadataButton.setEnabled(false);
        powerampButton.setVisibility(View.GONE);
        statusText.setText("מוכן לסריקה.");
        resultText.setText("");
    }

    private String friendlyTreeName(Uri uri) {
        try {
            String id = DocumentsContract.getTreeDocumentId(uri);
            int colon = id.indexOf(':');
            String path = colon >= 0 ? id.substring(colon + 1) : id;
            return path.isEmpty() ? id : path;
        } catch (Exception e) {
            return uri.toString();
        }
    }

    private void analyzeLibrary() {
        if (treeUri == null) return;
        saveSettings();
        setBusy(true);
        statusText.setText("סורק קבצי מוזיקה…");
        resultText.setText("");
        analyzedSongs.clear();
        createButton.setEnabled(false);
        editMetadataButton.setEnabled(false);
        powerampButton.setVisibility(View.GONE);

        final Uri selected = treeUri;
        worker.execute(() -> {
            try {
                List<Song> songs = new ArrayList<>();
                String rootId = DocumentsContract.getTreeDocumentId(selected);
                scanDirectory(selected, rootId, "", songs);
                if (songs.size() < 2) throw new IllegalStateException("נדרשים לפחות שני קובצי מוזיקה בתיקייה שנבחרה.");

                final int total = songs.size();
                main.post(() -> {
                    progressBar.setVisibility(View.VISIBLE);
                    progressBar.setProgress(0);
                    statusText.setText("נמצאו " + total + " שירים. קורא תגיות ומנתח קצב ואנרגיה…");
                });

                int analyzed = 0;
                int cacheHits = 0;
                for (Song song : songs) {
                    try {
                        if (loadCachedAnalysis(song)) {
                            cacheHits++;
                        } else {
                            readMetadata(song);
                            AudioFeatures f = analyzeAudio(song.uri);
                            song.rmsDb = f.rmsDb;
                            song.bpm = f.bpm;
                            song.activity = f.activity;
                            song.analyzed = true;
                            saveCachedAnalysis(song);
                        }
                        applyManualOverride(song);
                    } catch (Exception e) {
                        song.analyzed = false;
                    }
                    analyzed++;
                    final int done = analyzed;
                    final int hits = cacheHits;
                    final String name = song.name;
                    main.post(() -> {
                        progressBar.setProgress((int) (done * 100.0 / total));
                        statusText.setText("מנתח " + done + "/" + total + ": " + name + "  |  מטמון: " + hits);
                    });
                }

                List<Song> usable = new ArrayList<>();
                for (Song s : songs) if (s.analyzed) usable.add(s);
                if (usable.size() < 2) {
                    throw new IllegalStateException("לא הצלחתי לנתח מספיק קובצי אודיו. נסה תיקייה עם MP3/FLAC/M4A רגילים.");
                }

                scoreEnergy(usable);
                final int skipped = songs.size() - usable.size();
                final int hits = cacheHits;
                main.post(() -> {
                    analyzedSongs.clear();
                    analyzedSongs.addAll(usable);
                    lastSkipped = skipped;
                    lastCacheHits = hits;
                    statusText.setText("הניתוח הסתיים. אפשר לבדוק את הסיווג וליצור פלייליסט.");
                    createButton.setEnabled(true);
                    editMetadataButton.setEnabled(true);
                    setBusy(false);
                    showAnalysisSummary();
                });
            } catch (Exception e) {
                main.post(() -> {
                    statusText.setText("שגיאה: " + safeMessage(e));
                    setBusy(false);
                });
            }
        });
    }

    private void createPlaylistFromAnalysis() {
        if (treeUri == null || analyzedSongs.size() < 2) return;
        saveSettings();
        setBusy(true);
        progressBar.setProgress(0);
        statusText.setText("מכין נתוני פיזור…");
        final List<Song> source = new ArrayList<>(analyzedSongs);
        final Uri selected = treeUri;
        final int mode = modeSpinner.getSelectedItemPosition();
        final int ratioIndex = ratioSpinner.getSelectedItemPosition();
        final double threshold = thresholdSeek.getProgress() / 100.0;
        final String playlistName = normalizedPlaylistName(playlistNameEdit.getText().toString());
        playlistNameEdit.setText(playlistName);

        worker.execute(() -> {
            try {
                // Pre-compute normalized grouping keys once. The previous implementation
                // recalculated several regex-heavy keys for every candidate at every slot,
                // which could take minutes on libraries with hundreds of songs.
                for (Song s : source) s.refreshScheduleKeys();
                int[] ratio = ratioForIndex(ratioIndex);
                List<Song> playlist = scheduleSmart(source, mode, ratio[0], ratio[1], threshold);
                main.post(() -> {
                    progressBar.setProgress(100);
                    statusText.setText("כותב " + playlistName + "…");
                });
                Uri playlistUri = writePlaylist(selected, playlist, playlistName);
                String summary = buildPlaylistSummary(playlist, lastSkipped, playlistUri, threshold);
                final String savedAt = friendlyTreeName(selected) + "/" + playlistName;
                main.post(() -> {
                    statusText.setText("הפלייליסט נוצר בהצלחה: " + savedAt);
                    resultText.setText(summary);
                    powerampButton.setVisibility(View.VISIBLE);
                    setBusy(false);
                    Toast.makeText(this, "נוצר: " + playlistName, Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                main.post(() -> {
                    statusText.setText("שגיאה ביצירת הפלייליסט: " + safeMessage(e));
                    setBusy(false);
                });
            }
        });
    }

    private void setBusy(boolean busy) {
        analyzeButton.setEnabled(!busy && treeUri != null);
        createButton.setEnabled(!busy && analyzedSongs.size() >= 2);
        editMetadataButton.setEnabled(!busy && !analyzedSongs.isEmpty());
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
        if (!busy) progressBar.setProgress(0);
    }

    private void scanDirectory(Uri tree, String parentDocumentId, String relativeDir, List<Song> out) throws Exception {
        ContentResolver resolver = getContentResolver();
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentDocumentId);
        String[] projection = {
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED
        };
        try (Cursor cursor = resolver.query(children, projection, null, null, null)) {
            if (cursor == null) return;
            int idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            int mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE);
            int sizeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
            int modifiedCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);
            while (cursor.moveToNext()) {
                String id = cursor.getString(idCol);
                String name = cursor.getString(nameCol);
                String mime = cursor.getString(mimeCol);
                long size = sizeCol >= 0 && !cursor.isNull(sizeCol) ? cursor.getLong(sizeCol) : 0L;
                long modified = modifiedCol >= 0 && !cursor.isNull(modifiedCol) ? cursor.getLong(modifiedCol) : 0L;
                if (name == null) name = "unknown";
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    String nextRel = relativeDir.isEmpty() ? name : relativeDir + "/" + name;
                    scanDirectory(tree, id, nextRel, out);
                } else if (isAudio(name, mime)) {
                    Uri docUri = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                    String rel = relativeDir.isEmpty() ? name : relativeDir + "/" + name;
                    out.add(new Song(name, rel, id, docUri, size, modified));
                }
            }
        }
    }

    private boolean isAudio(String name, String mime) {
        if (mime != null && mime.startsWith("audio/")) return true;
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".mp3") || lower.endsWith(".flac") || lower.endsWith(".m4a")
                || lower.endsWith(".aac") || lower.endsWith(".ogg") || lower.endsWith(".opus")
                || lower.endsWith(".wav") || lower.endsWith(".wma") || lower.endsWith(".ape")
                || lower.endsWith(".alac") || lower.endsWith(".mka");
    }

    private void readMetadata(Song song) {
        song.title = null;
        song.artist = null;
        song.albumArtist = null;
        song.album = null;
        song.genre = null;
        song.genreSource = null;
        song.artistSource = null;
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(this, song.uri);
            song.title = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE));
            song.artist = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST));
            song.albumArtist = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST));
            song.album = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM));
            String rawGenre = trimToNull(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE));
            if (rawGenre != null) {
                song.genre = canonicalGenre(rawGenre);
                song.genreSource = "תגית";
            }
        } catch (Exception ignored) {
        } finally {
            try { mmr.release(); } catch (Exception ignored) {}
        }

        parseFilenameFallback(song);
        if (song.genre == null) {
            String trusted = trustedGenreForArtist(song.artistIdentity());
            if (trusted != null) {
                song.genre = trusted;
                song.genreSource = "זיהוי אמן ודאי";
            }
        }
    }

    private void parseFilenameFallback(Song song) {
        String base = stripExtension(song.name);
        if (song.title == null) song.title = base;
        if (song.artist != null) return;
        String[] parts = base.split("\\s+-\\s+");
        if (parts.length == 2 && !parts[0].trim().isEmpty() && !parts[1].trim().isEmpty()) {
            song.artist = parts[0].trim();
            if (song.title == null || song.title.equals(base)) song.title = parts[1].trim();
            song.artistSource = "שם קובץ";
        } else if (parts.length >= 3 && parts[0].trim().matches("\\d{1,3}")) {
            song.artist = parts[1].trim();
            if (!parts[2].trim().isEmpty()) song.title = parts[2].trim();
            song.artistSource = "שם קובץ";
        }
    }

    private String trustedGenreForArtist(String artist) {
        String k = normalizeGroup(artist);
        switch (k) {
            case "glenn miller":
            case "glenn miller orchestra":
            case "benny goodman":
                return "Swing";
            case "miles davis":
            case "john coltrane":
            case "thelonious monk":
            case "dave brubeck":
            case "dave brubeck quartet":
                return "Jazz";
            case "ac dc":
            case "led zeppelin":
            case "deep purple":
            case "rolling stones":
                return "Rock";
            default:
                return null;
        }
    }

    private String canonicalGenre(String raw) {
        if (raw == null) return null;
        String g = raw.toLowerCase(Locale.ROOT);
        if (g.contains("swing")) return "Swing";
        if (g.contains("jazz")) return "Jazz";
        if (g.contains("rock")) return "Rock";
        if (g.contains("blues")) return "Blues";
        if (g.contains("classical") || g.contains("classic")) return "Classical";
        if (g.contains("metal")) return "Metal";
        if (g.contains("country")) return "Country";
        if (g.contains("funk")) return "Funk";
        if (g.contains("soul")) return "Soul";
        if (g.contains("disco")) return "Disco";
        if (g.contains("reggae")) return "Reggae";
        if (g.contains("electro") || g.contains("edm")) return "Electronic";
        if (g.contains("dance")) return "Dance";
        if (g.contains("folk")) return "Folk";
        if (g.contains("hip hop") || g.contains("hip-hop") || g.contains("rap")) return "Hip Hop";
        if (g.contains("pop")) return "Pop";
        String cleaned = raw.trim().replaceAll("\\s+", " ");
        return cleaned.isEmpty() ? null : cleaned;
    }

    private AudioFeatures analyzeAudio(Uri uri) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec codec = null;
        try {
            extractor.setDataSource(this, uri, null);
            int audioTrack = -1;
            MediaFormat inputFormat = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrack = i;
                    inputFormat = f;
                    break;
                }
            }
            if (audioTrack < 0 || inputFormat == null) throw new IllegalArgumentException("אין ערוץ אודיו");

            extractor.selectTrack(audioTrack);
            long durationUs = inputFormat.containsKey(MediaFormat.KEY_DURATION) ? inputFormat.getLong(MediaFormat.KEY_DURATION) : 0L;
            long sampleStartUs = durationUs > 45_000_000L ? Math.min(30_000_000L, durationUs / 5) : 0L;
            long sampleLengthUs = 18_000_000L;
            long sampleEndUs = durationUs > 0 ? Math.min(durationUs, sampleStartUs + sampleLengthUs) : sampleStartUs + sampleLengthUs;
            if (sampleStartUs > 0) extractor.seekTo(sampleStartUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);

            String mime = inputFormat.getString(MediaFormat.KEY_MIME);
            codec = MediaCodec.createDecoderByType(mime);
            codec.configure(inputFormat, null, null, 0);
            codec.start();

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            boolean outputDone = false;
            PcmAnalyzer analyzer = null;
            long wallDeadline = System.currentTimeMillis() + 25_000L;

            while (!outputDone && System.currentTimeMillis() < wallDeadline) {
                if (!inputDone) {
                    int inputIndex = codec.dequeueInputBuffer(10_000);
                    if (inputIndex >= 0) {
                        ByteBuffer inputBuffer = codec.getInputBuffer(inputIndex);
                        if (inputBuffer == null) continue;
                        inputBuffer.clear();
                        long sampleTime = extractor.getSampleTime();
                        if (sampleTime < 0 || sampleTime > sampleEndUs) {
                            codec.queueInputBuffer(inputIndex, 0, 0, Math.max(0, sampleTime), MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            int size = extractor.readSampleData(inputBuffer, 0);
                            if (size < 0) {
                                codec.queueInputBuffer(inputIndex, 0, 0, Math.max(0, sampleTime), MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inputDone = true;
                            } else {
                                codec.queueInputBuffer(inputIndex, 0, size, sampleTime, extractor.getSampleFlags());
                                extractor.advance();
                            }
                        }
                    }
                }

                int outIndex = codec.dequeueOutputBuffer(info, 10_000);
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    analyzer = new PcmAnalyzer(codec.getOutputFormat());
                } else if (outIndex >= 0) {
                    if (analyzer == null) analyzer = new PcmAnalyzer(codec.getOutputFormat());
                    ByteBuffer out = codec.getOutputBuffer(outIndex);
                    if (out != null && info.size > 0) {
                        out.position(info.offset);
                        out.limit(info.offset + info.size);
                        analyzer.consume(out.slice().order(ByteOrder.LITTLE_ENDIAN));
                    }
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true;
                    codec.releaseOutputBuffer(outIndex, false);
                }
            }
            if (analyzer == null || analyzer.sampleCount < 4000) throw new IllegalStateException("אין מספיק PCM");
            return analyzer.finish();
        } finally {
            try { extractor.release(); } catch (Exception ignored) {}
            if (codec != null) {
                try { codec.stop(); } catch (Exception ignored) {}
                try { codec.release(); } catch (Exception ignored) {}
            }
        }
    }

    private static final class PcmAnalyzer {
        final int sampleRate;
        final int channels;
        final int encoding;
        final int windowSamples;
        final List<Double> envelope = new ArrayList<>();
        double windowSq;
        int windowCount;
        double totalSq;
        long sampleCount;

        PcmAnalyzer(MediaFormat f) {
            sampleRate = f.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? f.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
            channels = f.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? Math.max(1, f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)) : 2;
            int enc = AudioFormat.ENCODING_PCM_16BIT;
            try { if (f.containsKey("pcm-encoding")) enc = f.getInteger("pcm-encoding"); } catch (Exception ignored) {}
            encoding = enc;
            windowSamples = 1024;
        }

        void consume(ByteBuffer b) {
            if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
                while (b.remaining() >= 4 * channels) {
                    double mono = 0;
                    for (int c = 0; c < channels; c++) mono += clamp(b.getFloat());
                    add(mono / channels);
                }
            } else if (encoding == AudioFormat.ENCODING_PCM_8BIT) {
                while (b.remaining() >= channels) {
                    double mono = 0;
                    for (int c = 0; c < channels; c++) mono += ((b.get() & 0xff) - 128) / 128.0;
                    add(mono / channels);
                }
            } else {
                while (b.remaining() >= 2 * channels) {
                    double mono = 0;
                    for (int c = 0; c < channels; c++) mono += b.getShort() / 32768.0;
                    add(mono / channels);
                }
            }
        }

        private static double clamp(float v) {
            if (v > 1f) return 1;
            if (v < -1f) return -1;
            return v;
        }

        private void add(double x) {
            double sq = x * x;
            totalSq += sq;
            sampleCount++;
            windowSq += sq;
            windowCount++;
            if (windowCount >= windowSamples) {
                envelope.add(Math.sqrt(windowSq / windowCount));
                windowSq = 0;
                windowCount = 0;
            }
        }

        AudioFeatures finish() {
            if (windowCount > 0) envelope.add(Math.sqrt(windowSq / windowCount));
            double rms = Math.sqrt(totalSq / Math.max(1, sampleCount));
            double rmsDb = 20.0 * Math.log10(rms + 1e-9);
            if (envelope.size() < 8) return new AudioFeatures(rmsDb, 0, 0);

            double[] onset = new double[envelope.size() - 1];
            double onsetSum = 0;
            for (int i = 1; i < envelope.size(); i++) {
                onset[i - 1] = Math.max(0.0, envelope.get(i) - envelope.get(i - 1));
                onsetSum += onset[i - 1];
            }
            double mean = onsetSum / onset.length;
            double variance = 0;
            for (double v : onset) {
                double d = v - mean;
                variance += d * d;
            }
            double std = Math.sqrt(variance / onset.length);
            double avgEnv = 0;
            for (double v : envelope) avgEnv += v;
            avgEnv /= envelope.size();
            double activity = std / (avgEnv + 1e-7);

            double frameRate = sampleRate / (double) windowSamples;
            int bestLag = -1;
            double best = Double.NEGATIVE_INFINITY;
            int minLag = Math.max(1, (int) Math.floor(frameRate * 60.0 / 180.0));
            int maxLag = Math.min(onset.length / 2, (int) Math.ceil(frameRate * 60.0 / 65.0));
            for (int lag = minLag; lag <= maxLag; lag++) {
                double corr = 0, a2 = 0, b2 = 0;
                for (int i = lag; i < onset.length; i++) {
                    double a = onset[i] - mean;
                    double bb = onset[i - lag] - mean;
                    corr += a * bb;
                    a2 += a * a;
                    b2 += bb * bb;
                }
                double normalized = corr / (Math.sqrt(a2 * b2) + 1e-9);
                if (normalized > best) {
                    best = normalized;
                    bestLag = lag;
                }
            }
            double bpm = bestLag > 0 && best > 0.04 ? 60.0 * frameRate / bestLag : 0.0;
            if (bpm > 0 && bpm < 75) bpm *= 2.0;
            if (bpm > 180) bpm /= 2.0;
            return new AudioFeatures(rmsDb, bpm, activity);
        }
    }

    private void scoreEnergy(List<Song> songs) {
        List<Double> rmsVals = new ArrayList<>();
        List<Double> actVals = new ArrayList<>();
        List<Double> bpmVals = new ArrayList<>();
        for (Song s : songs) {
            rmsVals.add(s.rmsDb);
            actVals.add(s.activity);
            if (s.bpm > 0) bpmVals.add(s.bpm);
        }
        Collections.sort(rmsVals);
        Collections.sort(actVals);
        Collections.sort(bpmVals);
        double rmsLo = percentile(rmsVals, 0.10), rmsHi = percentile(rmsVals, 0.90);
        double actLo = percentile(actVals, 0.10), actHi = percentile(actVals, 0.90);
        double bpmLo = bpmVals.isEmpty() ? 80 : percentile(bpmVals, 0.10);
        double bpmHi = bpmVals.isEmpty() ? 150 : percentile(bpmVals, 0.90);

        for (Song s : songs) {
            double absRms = normRange(s.rmsDb, -32.0, -9.0);
            double absAct = normRange(s.activity, 0.008, 0.16);
            double absBpm = s.bpm > 0 ? normRange(s.bpm, 70.0, 170.0) : 0.42;
            double relRms = normRange(s.rmsDb, rmsLo, rmsHi);
            double relAct = normRange(s.activity, actLo, actHi);
            double relBpm = s.bpm > 0 ? normRange(s.bpm, bpmLo, bpmHi) : 0.42;
            double absolute = 0.45 * absRms + 0.35 * absAct + 0.20 * absBpm;
            double relative = 0.45 * relRms + 0.35 * relAct + 0.20 * relBpm;
            s.energy = clamp01(0.65 * absolute + 0.35 * relative);
        }
    }

    private static double percentile(List<Double> values, double p) {
        if (values.isEmpty()) return 0.0;
        if (values.size() == 1) return values.get(0);
        double idx = p * (values.size() - 1);
        int lo = (int) Math.floor(idx);
        int hi = Math.min(values.size() - 1, lo + 1);
        double frac = idx - lo;
        return values.get(lo) * (1 - frac) + values.get(hi) * frac;
    }

    private static double normRange(double v, double min, double max) {
        if (!Double.isFinite(v) || !Double.isFinite(min) || !Double.isFinite(max) || max - min < 1e-9) return 0.5;
        return clamp01((v - min) / (max - min));
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }

    private List<Song> scheduleSmart(List<Song> songs, int mode, int calmPer, int energeticPer, double threshold) {
        List<Song> remaining = new ArrayList<>(songs);
        for (Song s : remaining) s.refreshScheduleKeys();
        remaining.sort(Comparator.comparing(Song::artistKey)
                .thenComparing(Song::titleFamilyKey)
                .thenComparing(s -> s.relativePath));

        int total = remaining.size();
        ScheduleStats stats = new ScheduleStats(remaining);
        ScheduleState state = new ScheduleState();
        List<Song> result = new ArrayList<>(total);

        for (int pos = 0; pos < total; pos++) {
            final int done = pos;
            if (pos == 0 || pos % 20 == 0) {
                main.post(() -> {
                    progressBar.setProgress((int) (done * 100.0 / Math.max(1, total)));
                    statusText.setText("מסדר פלייליסט: " + done + "/" + total + "…");
                });
            }

            boolean wantCalm = desiredCalmAt(pos, calmPer, energeticPer);
            boolean anyMatching = false;
            if (mode == 0) {
                for (Song s : remaining) {
                    if ((s.energy < threshold) == wantCalm) { anyMatching = true; break; }
                }
            }

            Song best = null;
            double bestPenalty = Double.POSITIVE_INFINITY;
            for (Song s : remaining) {
                if (mode == 0 && anyMatching && ((s.energy < threshold) != wantCalm)) continue;
                double penalty = schedulingPenalty(s, pos, total, mode, wantCalm, threshold, stats, state);
                if (penalty < bestPenalty - 1e-9
                        || (Math.abs(penalty - bestPenalty) < 1e-9 && (best == null || s.relativePath.compareToIgnoreCase(best.relativePath) < 0))) {
                    best = s;
                    bestPenalty = penalty;
                }
            }
            if (best == null) best = remaining.get(0);
            result.add(best);
            state.record(best, pos);
            remaining.remove(best);
        }
        return result;
    }

    private double schedulingPenalty(Song s, int pos, int total, int mode, boolean wantCalm, double threshold,
                                     ScheduleStats stats, ScheduleState state) {
        double penalty = 0;
        if (mode == 0) {
            double target = wantCalm ? Math.max(0.12, threshold * 0.62) : Math.min(0.90, threshold + (1.0 - threshold) * 0.52);
            penalty += Math.abs(s.energy - target) * 18.0;
        } else {
            double progress = total <= 1 ? 0.5 : pos / (double) (total - 1);
            double target = mode == 1 ? 0.15 + 0.75 * progress : 0.90 - 0.75 * progress;
            penalty += Math.abs(s.energy - target) * 95.0;
        }

        penalty += groupPenalty(s.artistKey(), pos, total, stats.artistCounts, state.artistUsed, state.artistLast, 145.0, 0.58);
        penalty += groupPenalty(s.genreKey(), pos, total, stats.genreCounts, state.genreUsed, state.genreLast, 95.0, 0.55);
        penalty += groupPenalty(s.albumKey(), pos, total, stats.albumCounts, state.albumUsed, state.albumLast, 65.0, 0.50);
        penalty += groupPenalty(s.titleFamilyKey(), pos, total, stats.titleCounts, state.titleUsed, state.titleLast, 120.0, 0.70);
        return penalty;
    }

    private double groupPenalty(String key, int pos, int total, Map<String, Integer> counts,
                                Map<String, Integer> used, Map<String, Integer> last,
                                double weight, double minGapFactor) {
        if (key == null || key.isEmpty()) return 0;
        int count = counts.containsKey(key) ? counts.get(key) : 0;
        if (count <= 1) return 0;
        int u = used.containsKey(key) ? used.get(key) : 0;
        double targetGap = total / (double) count;
        double ideal = (u + 0.5) * targetGap - 0.5;
        double penalty = Math.abs(pos - ideal) / Math.max(1.0, targetGap) * weight;
        Integer lastPos = last.get(key);
        if (lastPos != null) {
            double distance = pos - lastPos;
            double minGap = Math.max(1.0, targetGap * minGapFactor);
            if (distance < minGap) {
                penalty += (minGap - distance) / minGap * weight * 5.0;
            }
            if (distance <= 1.0) penalty += weight * 10.0;
        }
        return penalty;
    }

    private boolean desiredCalmAt(int pos, int calmPer, int energeticPer) {
        int cycle = calmPer + energeticPer;
        int within = pos % Math.max(1, cycle);
        return within < calmPer;
    }

    private int[] ratioForIndex(int index) {
        switch (index) {
            case 1: return new int[]{2, 1};
            case 2: return new int[]{1, 2};
            case 3: return new int[]{3, 1};
            case 4: return new int[]{1, 3};
            default: return new int[]{1, 1};
        }
    }

    private Uri writePlaylist(Uri tree, List<Song> songs, String playlistName) throws Exception {
        ContentResolver resolver = getContentResolver();
        String rootId = DocumentsContract.getTreeDocumentId(tree);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, rootId);
        Uri playlist = null;
        String[] projection = { DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME };
        try (Cursor c = resolver.query(children, projection, null, null, null)) {
            if (c != null) {
                int idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                while (c.moveToNext()) {
                    if (playlistName.equalsIgnoreCase(c.getString(nameCol))) {
                        playlist = DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(idCol));
                        break;
                    }
                }
            }
        }

        // Reuse an existing playlist instead of deleting it first. This avoids losing the
        // previous file if a document provider refuses a subsequent create operation.
        if (playlist == null) {
            Uri rootDoc = DocumentsContract.buildDocumentUriUsingTree(tree, rootId);
            Exception first = null;
            try {
                playlist = DocumentsContract.createDocument(resolver, rootDoc, "audio/x-mpegurl", playlistName);
            } catch (Exception e) {
                first = e;
            }
            if (playlist == null) {
                try {
                    playlist = DocumentsContract.createDocument(resolver, rootDoc, "application/octet-stream", playlistName);
                } catch (Exception e) {
                    if (first != null) e.addSuppressed(first);
                    throw e;
                }
            }
        }
        if (playlist == null) throw new IllegalStateException("לא ניתן ליצור קובץ פלייליסט בתיקייה. בחר את התיקייה מחדש ואשר הרשאת כתיבה.");

        StringBuilder m3u = new StringBuilder("#EXTM3U\n");
        for (Song s : songs) {
            m3u.append("#EXTINF:-1,").append(cleanLine(s.displayTitleWithArtist())).append('\n');
            m3u.append(cleanLine(pathForPoweramp(s))).append('\n');
        }
        OutputStream opened;
        try {
            opened = resolver.openOutputStream(playlist, "rwt");
        } catch (Exception ignored) {
            opened = resolver.openOutputStream(playlist, "wt");
        }
        if (opened == null) throw new IllegalStateException("לא ניתן לפתוח את קובץ הפלייליסט לכתיבה");
        try (OutputStream os = opened) {
            os.write(m3u.toString().getBytes(StandardCharsets.UTF_8));
            os.flush();
        }
        return playlist;
    }

    private String pathForPoweramp(Song s) {
        String absolute = absolutePathFromDocumentId(s.documentId);
        return absolute != null ? absolute : s.relativePath;
    }

    private String absolutePathFromDocumentId(String documentId) {
        int colon = documentId.indexOf(':');
        if (colon < 0) return null;
        String volume = documentId.substring(0, colon);
        String path = documentId.substring(colon + 1);
        if ("primary".equalsIgnoreCase(volume)) {
            return path.isEmpty() ? "/storage/emulated/0" : "/storage/emulated/0/" + path;
        }
        if (volume.matches("[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}")) {
            return path.isEmpty() ? "/storage/" + volume : "/storage/" + volume + "/" + path;
        }
        return null;
    }

    private String cleanLine(String s) {
        return s.replace('\n', ' ').replace('\r', ' ');
    }

    private void showAnalysisSummary() {
        if (analyzedSongs.isEmpty()) return;
        double threshold = thresholdSeek.getProgress() / 100.0;
        int calm = 0, energetic = 0, genreKnown = 0, artistKnown = 0;
        Map<String, Integer> artists = new HashMap<>();
        Map<String, Integer> genres = new HashMap<>();
        for (Song s : analyzedSongs) {
            if (s.energy < threshold) calm++; else energetic++;
            if (!s.artistKey().isEmpty()) { artistKnown++; increment(artists, s.artistIdentity()); }
            if (!s.genreKey().isEmpty()) { genreKnown++; increment(genres, s.genre); }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("תוצאות ניתוח\n");
        sb.append("שירים שנותחו: ").append(analyzedSongs.size()).append('\n');
        if (lastSkipped > 0) sb.append("קבצים שלא נותחו: ").append(lastSkipped).append('\n');
        sb.append("נטענו מהמטמון: ").append(lastCacheHits).append('\n');
        sb.append("רגועים לפי הסף הנוכחי: ").append(calm).append(" | קצביים: ").append(energetic).append('\n');
        sb.append("אמן/להקה מזוהים: ").append(artistKnown).append(" | סוג מזוהה: ").append(genreKnown).append('\n');
        sb.append("סוג מסווג רק מתגית קובץ, תיקון ידני, או רשימת זיהוי אמן שמרנית.\n\n");
        appendTopCounts(sb, "אמנים/להקות בולטים", artists, 8);
        appendTopCounts(sb, "סוגים", genres, 8);

        sb.append("\nדוגמה מהניתוח:\n");
        List<Song> preview = new ArrayList<>(analyzedSongs);
        preview.sort(Comparator.comparingDouble(s -> s.energy));
        int show = Math.min(20, preview.size());
        for (int i = 0; i < show; i++) {
            Song s = preview.get(i);
            sb.append("• ").append(s.displayTitleWithArtist())
                    .append(" | ").append(s.energy < threshold ? "רגוע" : "קצבי")
                    .append(" | E=").append(Math.round(s.energy * 100));
            if (s.bpm > 0) sb.append(" | ~").append(Math.round(s.bpm)).append(" BPM");
            if (s.genre != null) sb.append(" | ").append(s.genre);
            sb.append('\n');
        }
        resultText.setText(sb.toString());
    }

    private String buildPlaylistSummary(List<Song> playlist, int skipped, Uri playlistUri, double threshold) {
        StringBuilder sb = new StringBuilder();
        sb.append("נוצרו ").append(playlist.size()).append(" שירים עם פיזור רב-קריטריוני.\n");
        if (skipped > 0) sb.append("דולגו ").append(skipped).append(" קבצים שלא ניתן היה לנתח.\n");
        sb.append("\nפיזור אמן/להקה:\n");
        appendSpacingReport(sb, playlist, true, 8);
        sb.append("\nפיזור סוג מוזיקלי:\n");
        appendSpacingReport(sb, playlist, false, 8);
        sb.append("\nב-Poweramp בצע Rescan אם הפלייליסט לא מופיע מיד.\n\n");

        int show = Math.min(80, playlist.size());
        for (int i = 0; i < show; i++) {
            Song s = playlist.get(i);
            sb.append(i + 1).append(". ").append(s.energy < threshold ? "רגוע" : "קצבי")
                    .append(" — ").append(s.displayTitleWithArtist());
            if (s.genre != null) sb.append(" [").append(s.genre).append("]");
            if (s.bpm > 0) sb.append(" (~").append(Math.round(s.bpm)).append(" BPM)");
            sb.append('\n');
        }
        if (playlist.size() > show) sb.append("… ועוד ").append(playlist.size() - show).append(" שירים");
        return sb.toString();
    }

    private void appendTopCounts(StringBuilder sb, String heading, Map<String, Integer> counts, int limit) {
        if (counts.isEmpty()) return;
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(counts.entrySet());
        entries.sort((a, b) -> {
            int cmp = Integer.compare(b.getValue(), a.getValue());
            return cmp != 0 ? cmp : a.getKey().compareToIgnoreCase(b.getKey());
        });
        sb.append(heading).append(":\n");
        for (int i = 0; i < Math.min(limit, entries.size()); i++) {
            Map.Entry<String, Integer> e = entries.get(i);
            sb.append("• ").append(e.getKey()).append(": ").append(e.getValue()).append('\n');
        }
        sb.append('\n');
    }

    private void appendSpacingReport(StringBuilder sb, List<Song> playlist, boolean artist, int limit) {
        Map<String, List<Integer>> positions = new LinkedHashMap<>();
        Map<String, String> display = new HashMap<>();
        for (int i = 0; i < playlist.size(); i++) {
            Song s = playlist.get(i);
            String key = artist ? s.artistKey() : s.genreKey();
            String label = artist ? s.artistIdentity() : s.genre;
            if (key.isEmpty() || label == null) continue;
            if (!positions.containsKey(key)) positions.put(key, new ArrayList<>());
            positions.get(key).add(i);
            if (!display.containsKey(key)) display.put(key, label);
        }
        List<String> keys = new ArrayList<>(positions.keySet());
        keys.sort((a, b) -> Integer.compare(positions.get(b).size(), positions.get(a).size()));
        int shown = 0;
        for (String key : keys) {
            List<Integer> pos = positions.get(key);
            if (pos.size() < 2) continue;
            double ideal = playlist.size() / (double) pos.size();
            double sum = 0;
            int min = Integer.MAX_VALUE;
            for (int i = 1; i < pos.size(); i++) {
                int gap = pos.get(i) - pos.get(i - 1);
                sum += gap;
                min = Math.min(min, gap);
            }
            double avg = sum / (pos.size() - 1);
            sb.append("• ").append(display.get(key)).append(": ").append(pos.size())
                    .append(" שירים | יעד ~").append(String.format(Locale.ROOT, "%.1f", ideal))
                    .append(" | ממוצע ").append(String.format(Locale.ROOT, "%.1f", avg))
                    .append(" | מינימום ").append(min).append('\n');
            shown++;
            if (shown >= limit) break;
        }
        if (shown == 0) sb.append("אין קבוצות עם יותר משיר אחד.\n");
    }

    private void showMetadataEditor() {
        if (analyzedSongs.isEmpty()) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(4));
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        Spinner songSpinner = new Spinner(this);
        List<String> labels = new ArrayList<>();
        for (Song s : analyzedSongs) labels.add(s.displayTitleWithArtist());
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        songSpinner.setAdapter(adapter);
        box.addView(songSpinner, new LinearLayout.LayoutParams(-1, -2));

        EditText artist = metadataField("אמן");
        EditText albumArtist = metadataField("להקה / Album Artist");
        EditText album = metadataField("אלבום");
        EditText genre = metadataField("סוג מוזיקלי");
        box.addView(artist);
        box.addView(albumArtist);
        box.addView(album);
        box.addView(genre);

        Runnable load = () -> {
            Song s = analyzedSongs.get(songSpinner.getSelectedItemPosition());
            artist.setText(nullToEmpty(s.artist));
            albumArtist.setText(nullToEmpty(s.albumArtist));
            album.setText(nullToEmpty(s.album));
            genre.setText(nullToEmpty(s.genre));
        };
        songSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { load.run(); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        load.run();

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("תיקון מידע לשיר")
                .setView(box)
                .setPositiveButton("שמור", null)
                .setNeutralButton("אפס תיקון", null)
                .setNegativeButton("ביטול", null)
                .create();
        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                Song s = analyzedSongs.get(songSpinner.getSelectedItemPosition());
                s.artist = trimToNull(artist.getText().toString());
                s.albumArtist = trimToNull(albumArtist.getText().toString());
                s.album = trimToNull(album.getText().toString());
                String enteredGenre = trimToNull(genre.getText().toString());
                s.genre = enteredGenre == null ? null : canonicalGenre(enteredGenre);
                s.genreSource = s.genre == null ? null : "תיקון ידני";
                s.invalidateScheduleKeys();
                saveManualOverride(s);
                showAnalysisSummary();
                Toast.makeText(this, "התיקון נשמר", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                Song s = analyzedSongs.get(songSpinner.getSelectedItemPosition());
                clearManualOverride(s);
                readMetadata(s);
                s.invalidateScheduleKeys();
                showAnalysisSummary();
                Toast.makeText(this, "התיקון הידני אופס", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    private EditText metadataField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private void confirmClearCache() {
        new AlertDialog.Builder(this)
                .setTitle("ניקוי מטמון")
                .setMessage("למחוק תוצאות ניתוח אודיו שמורות? תיקונים ידניים לא יימחקו.")
                .setPositiveButton("נקה", (d, w) -> {
                    SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    for (String key : prefs.getAll().keySet()) {
                        if (key.startsWith(CACHE_PREFIX)) editor.remove(key);
                    }
                    editor.apply();
                    analyzedSongs.clear();
                    createButton.setEnabled(false);
                    editMetadataButton.setEnabled(false);
                    statusText.setText("מטמון הניתוח נוקה. יש לבצע סריקה מחדש.");
                    resultText.setText("");
                })
                .setNegativeButton("ביטול", null)
                .show();
    }

    private boolean loadCachedAnalysis(Song song) {
        try {
            String json = getSharedPreferences(PREFS, MODE_PRIVATE).getString(CACHE_PREFIX + song.cacheKey(), null);
            if (json == null) return false;
            JSONObject o = new JSONObject(json);
            if (o.optInt("v", 0) != CACHE_VERSION) return false;
            if (o.optLong("size", -1) != song.size) return false;
            if (o.optLong("modified", -1) != song.lastModified) return false;
            song.rmsDb = o.getDouble("rms");
            song.bpm = o.getDouble("bpm");
            song.activity = o.getDouble("activity");
            song.title = jsonNullToString(o, "title");
            song.artist = jsonNullToString(o, "artist");
            song.albumArtist = jsonNullToString(o, "albumArtist");
            song.album = jsonNullToString(o, "album");
            song.genre = jsonNullToString(o, "genre");
            song.genreSource = jsonNullToString(o, "genreSource");
            song.artistSource = jsonNullToString(o, "artistSource");
            song.analyzed = true;
            song.fromCache = true;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void saveCachedAnalysis(Song song) {
        try {
            JSONObject o = new JSONObject();
            o.put("v", CACHE_VERSION);
            o.put("size", song.size);
            o.put("modified", song.lastModified);
            o.put("rms", song.rmsDb);
            o.put("bpm", song.bpm);
            o.put("activity", song.activity);
            putNullable(o, "title", song.title);
            putNullable(o, "artist", song.artist);
            putNullable(o, "albumArtist", song.albumArtist);
            putNullable(o, "album", song.album);
            putNullable(o, "genre", song.genre);
            putNullable(o, "genreSource", song.genreSource);
            putNullable(o, "artistSource", song.artistSource);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(CACHE_PREFIX + song.cacheKey(), o.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void applyManualOverride(Song song) {
        try {
            String json = getSharedPreferences(PREFS, MODE_PRIVATE).getString(OVERRIDE_PREFIX + song.cacheKey(), null);
            if (json == null) return;
            JSONObject o = new JSONObject(json);
            song.artist = jsonNullToString(o, "artist");
            song.albumArtist = jsonNullToString(o, "albumArtist");
            song.album = jsonNullToString(o, "album");
            song.genre = jsonNullToString(o, "genre");
            if (song.genre != null) song.genreSource = "תיקון ידני";
        } catch (Exception ignored) {}
    }

    private void saveManualOverride(Song song) {
        try {
            JSONObject o = new JSONObject();
            putNullable(o, "artist", song.artist);
            putNullable(o, "albumArtist", song.albumArtist);
            putNullable(o, "album", song.album);
            putNullable(o, "genre", song.genre);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(OVERRIDE_PREFIX + song.cacheKey(), o.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void clearManualOverride(Song song) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(OVERRIDE_PREFIX + song.cacheKey()).apply();
    }

    private static void putNullable(JSONObject o, String key, String value) throws Exception {
        if (value == null) o.put(key, JSONObject.NULL); else o.put(key, value);
    }

    private static String jsonNullToString(JSONObject o, String key) {
        if (!o.has(key) || o.isNull(key)) return null;
        String s = o.optString(key, null);
        return trimToNull(s);
    }

    private void openPoweramp() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.maxmpz.audioplayer");
        if (launch == null) {
            Toast.makeText(this, "Poweramp לא נמצא מותקן במכשיר", Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(launch);
    }

    private static String normalizedPlaylistName(String raw) {
        String s = raw == null ? "" : raw.trim();
        s = s.replace('/', '_').replace('\\', '_').replace('\n', ' ').replace('\r', ' ');
        if (s.isEmpty()) s = DEFAULT_PLAYLIST_NAME;
        if (!s.toLowerCase(Locale.ROOT).endsWith(".m3u8")) s += ".m3u8";
        return s;
    }

    private static String stripExtension(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private static String trimToNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }

    private static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    private static String normalizeGroup(String input) {
        String s = trimToNull(input);
        if (s == null) return "";
        s = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        s = s.toLowerCase(Locale.ROOT).replace('&', ' ');
        if (s.endsWith(", the")) s = "the " + s.substring(0, s.length() - 5).trim();
        s = s.replaceAll("[^\\p{L}\\p{N}]+", " ").trim().replaceAll("\\s+", " ");
        if (s.startsWith("the ")) s = s.substring(4).trim();
        return s;
    }

    private static String titleFamily(String title) {
        String s = stripExtension(title == null ? "" : title).toLowerCase(Locale.ROOT);
        s = s.replaceAll("\\([^)]*(remaster|remastered|live|mono|stereo|version|mix|edit|demo|take|radio|acoustic)[^)]*\\)", " ");
        s = s.replaceAll("\\[[^]]*(remaster|remastered|live|mono|stereo|version|mix|edit|demo|take|radio|acoustic)[^]]*]", " ");
        s = s.replaceAll("[-–—]\\s*(remaster(ed)?|live|mono|stereo|version|mix|edit|demo|take|radio edit|acoustic).*", " ");
        s = s.replaceAll("\\b(19|20)\\d{2}\\b", " ");
        return normalizeGroup(s);
    }

    private static String sha256(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < 12; i++) out.append(String.format(Locale.ROOT, "%02x", bytes[i]));
            return out.toString();
        } catch (Exception e) {
            return Integer.toHexString(s.hashCode());
        }
    }

    private static void increment(Map<String, Integer> map, String key) {
        String t = trimToNull(key);
        if (t == null) return;
        map.put(t, map.containsKey(t) ? map.get(t) + 1 : 1);
    }

    private static void incrementKey(Map<String, Integer> map, String key) {
        if (key == null || key.isEmpty()) return;
        map.put(key, map.containsKey(key) ? map.get(key) + 1 : 1);
    }

    private static int clampInt(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private static String safeMessage(Exception e) {
        String m = e.getMessage();
        return (m == null || m.trim().isEmpty()) ? e.getClass().getSimpleName() : m;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        worker.shutdownNow();
    }

    private static final class SimpleItemSelectedListener implements AdapterView.OnItemSelectedListener {
        private final Runnable callback;
        SimpleItemSelectedListener(Runnable callback) { this.callback = callback; }
        @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { callback.run(); }
        @Override public void onNothingSelected(AdapterView<?> parent) {}
    }

    private static final class AudioFeatures {
        final double rmsDb;
        final double bpm;
        final double activity;
        AudioFeatures(double rmsDb, double bpm, double activity) {
            this.rmsDb = rmsDb;
            this.bpm = bpm;
            this.activity = activity;
        }
    }

    private static final class Song {
        final String name;
        final String relativePath;
        final String documentId;
        final Uri uri;
        final long size;
        final long lastModified;
        boolean analyzed;
        boolean fromCache;
        double rmsDb;
        double bpm;
        double activity;
        double energy;
        String title;
        String artist;
        String albumArtist;
        String album;
        String genre;
        String genreSource;
        String artistSource;

        Song(String name, String relativePath, String documentId, Uri uri, long size, long lastModified) {
            this.name = name;
            this.relativePath = relativePath;
            this.documentId = documentId;
            this.uri = uri;
            this.size = size;
            this.lastModified = lastModified;
        }

        String displayTitle() {
            return title != null ? title : stripExtension(name);
        }

        String displayTitleWithArtist() {
            String a = artistIdentity();
            return a == null || a.trim().isEmpty() ? displayTitle() : a + " — " + displayTitle();
        }

        String artistIdentity() {
            String aa = trimToNull(albumArtist);
            if (aa != null) {
                String k = normalizeGroup(aa);
                if (!k.equals("various artists") && !k.equals("various") && !k.equals("v a")) return aa;
            }
            return trimToNull(artist);
        }

        private String artistKeyCache;
        private String genreKeyCache;
        private String albumKeyCache;
        private String titleFamilyKeyCache;

        void invalidateScheduleKeys() {
            artistKeyCache = null;
            genreKeyCache = null;
            albumKeyCache = null;
            titleFamilyKeyCache = null;
        }

        void refreshScheduleKeys() {
            artistKeyCache = normalizeGroup(artistIdentity());
            genreKeyCache = normalizeGroup(genre);
            String a = normalizeGroup(album);
            albumKeyCache = a.isEmpty() ? "" : artistKeyCache + "|" + a;
            titleFamilyKeyCache = titleFamily(displayTitle());
        }

        String artistKey() { if (artistKeyCache == null) refreshScheduleKeys(); return artistKeyCache; }
        String genreKey() { if (genreKeyCache == null) refreshScheduleKeys(); return genreKeyCache; }
        String albumKey() { if (albumKeyCache == null) refreshScheduleKeys(); return albumKeyCache; }
        String titleFamilyKey() { if (titleFamilyKeyCache == null) refreshScheduleKeys(); return titleFamilyKeyCache; }
        String cacheKey() { return sha256(documentId); }
    }

    private static final class ScheduleStats {
        final Map<String, Integer> artistCounts = new HashMap<>();
        final Map<String, Integer> genreCounts = new HashMap<>();
        final Map<String, Integer> albumCounts = new HashMap<>();
        final Map<String, Integer> titleCounts = new HashMap<>();
        ScheduleStats(List<Song> songs) {
            for (Song s : songs) {
                incrementKey(artistCounts, s.artistKey());
                incrementKey(genreCounts, s.genreKey());
                incrementKey(albumCounts, s.albumKey());
                incrementKey(titleCounts, s.titleFamilyKey());
            }
        }
    }

    private static final class ScheduleState {
        final Map<String, Integer> artistUsed = new HashMap<>();
        final Map<String, Integer> genreUsed = new HashMap<>();
        final Map<String, Integer> albumUsed = new HashMap<>();
        final Map<String, Integer> titleUsed = new HashMap<>();
        final Map<String, Integer> artistLast = new HashMap<>();
        final Map<String, Integer> genreLast = new HashMap<>();
        final Map<String, Integer> albumLast = new HashMap<>();
        final Map<String, Integer> titleLast = new HashMap<>();

        void record(Song s, int pos) {
            recordKey(s.artistKey(), pos, artistUsed, artistLast);
            recordKey(s.genreKey(), pos, genreUsed, genreLast);
            recordKey(s.albumKey(), pos, albumUsed, albumLast);
            recordKey(s.titleFamilyKey(), pos, titleUsed, titleLast);
        }

        private void recordKey(String key, int pos, Map<String, Integer> used, Map<String, Integer> last) {
            if (key == null || key.isEmpty()) return;
            used.put(key, used.containsKey(key) ? used.get(key) + 1 : 1);
            last.put(key, pos);
        }
    }
}
