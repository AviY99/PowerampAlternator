# Playlist Maker 3.0.0

התיעוד המלא בעברית נמצא ב-[docs/README_HE.md](docs/README_HE.md).

מסמכים נוספים:
- [אלגוריתמים](docs/ALGORITHMS_HE.md)
- [ארכיטקטורה וקבצים](docs/ARCHITECTURE_HE.md)
- [לוג שינויים](docs/CHANGELOG_HE.md)
