# Playlist Maker 3.1.2

Playlist Maker builds deterministic M3U8 playlists from a local Android music folder and is designed to work with Poweramp.

Version **3.1.2** is a GUI usability patch on top of 3.1.1. The stable playlist scheduler is intentionally unchanged.

Changes in 3.1.2:

- adds Android system-bar safe-area handling so the `Playlist Maker` title stays below the status bar;
- removes the user-facing **Artist + Genre** filter and keeps the clearer choices **All songs / Artist / Genre**;
- adds immediate violet visual press feedback to programmatic buttons, including language, scan and generate actions;
- keeps the single progressive filter selector and cached filter-count performance improvement from 3.1.1;
- preserves the same deterministic scheduling engine.

The data path remains:

`Analyzed library -> User filter -> Existing deterministic scheduler -> M3U8`

GUI language is selectable between **עברית / English** and is remembered between launches.

## Documentation

- [English overview](docs/README_EN.md)
- [סקירה בעברית](docs/README_HE.md)
- [Algorithms — English](docs/ALGORITHMS_EN.md)
- [אלגוריתמים — עברית](docs/ALGORITHMS_HE.md)
- [Architecture / files — English](docs/ARCHITECTURE_EN.md)
- [ארכיטקטורה / קבצים — עברית](docs/ARCHITECTURE_HE.md)
- [Change log — English](docs/CHANGELOG_EN.md)
- [לוג שינויים — עברית](docs/CHANGELOG_HE.md)

## Version

- `versionName`: `3.1.2`
- `versionCode`: `14`
- `applicationId`: `com.example.powerampalternator`
- Display name: **Playlist Maker**
