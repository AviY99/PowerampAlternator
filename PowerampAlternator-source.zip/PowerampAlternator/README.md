# Playlist Maker 3.3.1

Playlist Maker builds deterministic `M3U8` playlists from a local Android music library. It is **not a music player** and does not depend on Poweramp or any other specific playback application.

Version **3.3.1** refines the Direct Sort UI introduced in 3.3.0 while keeping the approved 3.2.1 Smart Sort baseline intact.

## Ordering modes

### Smart Sort

The existing deterministic engine is unchanged:

- global artist/band distribution;
- Balanced, Rising and Falling flow modes;
- reliable Genre and album/version signals as lower-priority considerations;
- deterministic tie breaking and no random shuffle.

### Direct Sort

Direct Sort is strict metadata ordering. A fixed list shows every sort field; check ✓ the fields to use and drag rows to define their priority. Available fields are:

- Artist;
- Genre;
- Year;
- Album;
- Title.

Each checked row can be ascending / A→Z or descending / Z→A. Top-to-bottom row order is the priority; long-press ≡ and drag to reorder. The old arrow/add/remove controls are removed. Missing metadata values are always placed after known values. A final relative-path tie-break keeps output deterministic.

When Direct Sort is selected, the Balanced/Rising/Falling controls disappear. Direct Sort does **not** use BPM, character/energy score, or smart artist spacing.

## Filtering

Filtering still happens first and supports:

- All songs;
- one or more Artists;
- one or more Genres.

Therefore Direct Sort can be applied to the complete library or to any currently selected Artist/Genre subset.

## Year compatibility

3.2.1 did not persist Year. 3.3.0 reads `METADATA_KEY_YEAR` and stores a parsed four-digit year. Old analysis/audio cache remains valid: when Year is missing from an older cache, Playlist Maker performs only a lightweight metadata read rather than repeating audio analysis.

## Data paths

`Analyzed library -> User filter -> Smart Sort -> M3U8`

or

`Analyzed library -> User filter -> Direct Sort criteria -> M3U8`

The selected output folder, optional diagnostic file and generic Android media refresh remain unchanged from 3.2.x.

GUI language is selectable between **עברית / English** and is remembered between launches.

## Documentation

- [English overview](docs/README_EN.md)
- [סקירה בעברית](docs/README_HE.md)
- [Algorithms — English](docs/ALGORITHMS_EN.md)
- [אלגוריתמים — עברית](docs/ALGORITHMS_HE.md)
- [Architecture / files — English](docs/ARCHITECTURE_EN.md)
- [ארכיטקטורה / קבצים — עברית](docs/ARCHITECTURE_HE.md)
- [Change log — English](docs/CHANGELOG_EN.md)
- [לוג שינויים — עברית](docs/CHANGELOG_HE.md)

## Version

- `versionName`: `3.3.1`
- `versionCode`: `18`
- `applicationId`: `com.example.powerampalternator`
- Display name: **Playlist Maker**
