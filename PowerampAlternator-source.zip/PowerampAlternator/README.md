# Playlist Maker 3.1.1

Playlist Maker builds deterministic M3U8 playlists from a local Android music folder and is designed to work with Poweramp.

Version **3.1.1** is a GUI/performance patch on top of the 3.1.0 filter release. The filter pipeline and stable 3.0.0 / 0.2.8 scheduling engine are unchanged.

3.1.0 introduced:

- **Playlist filters before scheduling:** All songs, Artist, Genre, or Artist + Genre.
- **New dark card-based GUI:** rounded dark surfaces, clear step hierarchy and a restrained violet accent. The app remains a playlist builder and does not add playback/player controls.

The approved smart scheduling engine itself is intentionally unchanged. The data path is now:

`Analyzed library -> User filter -> Existing deterministic scheduler -> M3U8`

GUI language remains selectable between **עברית / English** and is remembered between launches. In 3.1.1 the title stays on one line, the language control is smaller, filter mode is a single drop-down, and only the relevant next selector is shown. Repeated filter-count work was cached to improve UI responsiveness.

## Documentation

- [English overview](docs/README_EN.md)
- [סקירה בעברית](docs/README_HE.md)
- [Algorithms — English](docs/ALGORITHMS_EN.md)
- [אלגוריתמים — עברית](docs/ALGORITHMS_HE.md)
- [Architecture / files — English](docs/ARCHITECTURE_EN.md)
- [ארכיטקטורה / קבצים — עברית](docs/ARCHITECTURE_HE.md)
- [Change log — English](docs/CHANGELOG_EN.md)
- [לוג שינויים — עברית](docs/CHANGELOG_HE.md)

## Version

- `versionName`: `3.1.1`
- `versionCode`: `13`
- `applicationId`: `com.example.powerampalternator` (unchanged for signed in-place updates)
- Display name: **Playlist Maker**
