# Playlist Maker 3.0.0

Playlist Maker builds deterministic M3U8 playlists from a local Android music folder and is designed to work with Poweramp.

Version **3.0.0** is the documentation/localization release built on the stable 0.2.8 playlist engine. It does **not** change the approved scheduling algorithm.

- GUI language: **עברית / English**, selectable inside the app and remembered between launches.
- Full project documentation: English and Hebrew.
- Source-level documentation comments were added around the GUI, analysis, smart scheduler, adaptive Rising/Falling flow and resumable background service.

## Documentation

- [English overview](docs/README_EN.md)
- [סקירה בעברית](docs/README_HE.md)
- [Algorithms — English](docs/ALGORITHMS_EN.md)
- [אלגוריתמים — עברית](docs/ALGORITHMS_HE.md)
- [Architecture / files — English](docs/ARCHITECTURE_EN.md)
- [ארכיטקטורה / קבצים — עברית](docs/ARCHITECTURE_HE.md)
- [Change log — English](docs/CHANGELOG_EN.md)
- [לוג שינויים — עברית](docs/CHANGELOG_HE.md)

## Version

- `versionName`: `3.0.0`
- `versionCode`: `11`
- `applicationId`: `com.example.powerampalternator` (unchanged so signed updates continue to install over the stable build)
- Display name: **Playlist Maker**
