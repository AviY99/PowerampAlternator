# Playlist Maker 3.2.1

Playlist Maker builds deterministic M3U8 playlists from a local Android music library. It is **not a music player** and version 3.2.1 keeps playlist output player-agnostic so the generated file can be used by music applications that support M3U/M3U8 playlists.

Version **3.2.1** adds multi-selection to the Artist and Genre filters on top of the 3.2.0 storage/discovery update. The approved deterministic scheduler is intentionally unchanged.

Changes in 3.2.1:

- Artist filtering now opens a scrollable multi-choice list and allows selecting several artists at once;
- Genre filtering now opens the same type of scrollable multi-choice list and allows selecting several Genres at once;
- selected entries are marked with Android multi-choice check indicators and the closed control summarizes the selection;
- multi-selection is persisted as a JSON array, while legacy single-value preferences from older versions remain readable;
- filter-count preview and background task recovery use exactly the same selected Artist/Genre set;
- the 3.2.0 output-folder and generic Android media-refresh behavior remains unchanged;
- the smart scheduler, artist distribution, Balanced, Rising and Falling logic remain unchanged.


The data path remains:

`Analyzed library -> User filter -> Existing deterministic scheduler -> Selected output folder -> M3U8 -> Generic Android media refresh`

A third-party music app may still keep its own private library database and require its own Rescan/Refresh. Playlist Maker does not call a player-specific API.

GUI language is selectable between **עברית / English** and is remembered between launches.

## Documentation

- [English overview](docs/README_EN.md)
- [סקירה בעברית](docs/README_HE.md)
- [Algorithms — English](docs/ALGORITHMS_EN.md)
- [אלגוריתמים — עברית](docs/ALGORITHMS_HE.md)
- [Architecture / files — English](docs/ARCHITECTURE_EN.md)
- [ארכיטקטורה / קבצים — עברית](docs/ARCHITECTURE_HE.md)
- [Change log — English](docs/CHANGELOG_EN.md)
- [לוג שינויים — עברית](docs/CHANGELOG_HE.md)

## Version

- `versionName`: `3.2.1`
- `versionCode`: `16`
- `applicationId`: `com.example.powerampalternator`
- Display name: **Playlist Maker**
