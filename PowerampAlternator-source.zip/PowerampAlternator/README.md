# Playlist Maker 3.2.0

Playlist Maker builds deterministic M3U8 playlists from a local Android music library. It is **not a music player** and version 3.2.0 keeps playlist output player-agnostic so the generated file can be used by music applications that support M3U/M3U8 playlists.

Version **3.2.0** is a storage/discovery update on top of the stable 3.1.2 scheduler. The approved playlist algorithm is intentionally unchanged.

Changes in 3.2.0:

- adds a persistent, user-selectable **playlist save folder** independent from the analyzed music folder;
- keeps the music folder as the default output location until a dedicated save folder is selected;
- shows the active save location in the GUI and lets the user change it or return to the music-folder default;
- saves the optional `analysis.txt` report next to the playlist in the selected output folder;
- requests a **generic Android media refresh** after writing the M3U8 using `ContentResolver` notification and, for standard primary/removable external storage, `MediaScannerConnection`;
- removes the user-facing Poweramp launch/rescan control and the package query because no player-specific API is required;
- keeps the dark 3.1.2 GUI, filters, background recovery and deterministic scheduling behavior unchanged.

The data path remains:

`Analyzed library -> User filter -> Existing deterministic scheduler -> Selected output folder -> M3U8 -> Generic Android media refresh`

A third-party music app may still keep its own private library database and require its own Rescan/Refresh. Playlist Maker does not call a player-specific API.

GUI language is selectable between **עברית / English** and is remembered between launches.

## Documentation

- [English overview](docs/README_EN.md)
- [סקירה בעברית](docs/README_HE.md)
- [Algorithms — English](docs/ALGORITHMS_EN.md)
- [אלגוריתמים — עברית](docs/ALGORITHMS_HE.md)
- [Architecture / files — English](docs/ARCHITECTURE_EN.md)
- [ארכיטקטורה / קבצים — עברית](docs/ARCHITECTURE_HE.md)
- [Change log — English](docs/CHANGELOG_EN.md)
- [לוג שינויים — עברית](docs/CHANGELOG_HE.md)

## Version

- `versionName`: `3.2.0`
- `versionCode`: `15`
- `applicationId`: `com.example.powerampalternator`
- Display name: **Playlist Maker**
