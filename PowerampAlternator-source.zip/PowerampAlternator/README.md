# Playlist Maker 3.4.17

Playlist Maker builds deterministic `M3U8` playlists from one or more local Android music libraries. It is **not a music player** and does not depend on Poweramp or any other specific playback application.

Version **3.4.17** keeps the working 3.4.15 UI, doubles the icon inside the inline **About** panel from 76dp to 152dp, and moves **Era Spread** out of Smart Sort. Era Spread is now a standalone third ordering method beside Smart Sort and Direct Sort. Smart Sort returns to the unchanged 3.4.14 behavior.

## Multiple music libraries (3.4.5)

Step 1 now supports more than one Android SAF music-library root. The library manager shows saved roots with ✓ check marks, lets the user add another folder through the system picker, and remembers which roots are active. Every root that becomes selected asks **separately** whether to scan all subfolders or only files directly inside that folder. Overlapping selected roots are de-duplicated during discovery so the same document is not analyzed twice. A 3.4.4 single-library selection migrates automatically as one checked recursive root.

Library analysis remains owned by `BackgroundWorkService`; the active root list and each root's recursive/non-recursive choice are persisted with the analysis task so background restart/resume uses the same input set.

## Changes & corrections (3.4.x)

After library analysis, one dedicated area now contains all metadata repair tools:

- **Missing fields** — counts missing embedded tags by Artist, Band / Album Artist, Title, Album, Year and Genre, then lets the user choose a field and one or more songs to review, with Select all / Clear all. Filename fallback does not hide a genuinely missing embedded tag.
- **Existing Genre check** — compares an already-present Genre with MusicBrainz Genre data and shows confidence. A supported current value is reported as supported; otherwise the UI shows `current -> suggested`.
- **Manual edit** — the previous manual editor now lives here and covers all six fields above.

Internet lookup is explicitly opt-in per check or selected batch. After consent, the lookup runs in the existing resumable foreground service. While Playlist Maker is visible, the **Changes & corrections** card mirrors the live status and progress; when the Activity leaves the foreground the same service continues, and returning re-attaches the visible progress to the persisted job. Minimizing/leaving the screen therefore does not cancel it and saved progress can resume after process recreation. MusicBrainz results are **suggestions only**: nothing is changed until the user approves a proposal. No Genre is guessed from audio. Approved changes are stored as Playlist Maker internal per-song overrides; 3.4.5 does not rewrite MP3/FLAC tags. Result approval now binds visible check marks to one explicit selection state; Select all and the green/yellow/red quick-selection buttons reliably select every applicable change proposal, including low-confidence proposals. In Check Genre, identical/supported rows are shown explicitly as informational because there is no change to apply.

Result rows wrap to multiple lines. Confidence is visual guidance only: **green 85–100%**, **yellow 65–84%**, **red 0–64%**. A red/low-confidence proposal is still selectable; only rows with no concrete proposal cannot be applied. The approval screen includes quick selection for **all / green / yellow / red / clear**.

Old 3.3.2 analysis/audio cache remains reusable. When embedded-tag presence is not available in an older cache/snapshot, Playlist Maker performs only a lightweight metadata pass; audio analysis is not repeated.

## Ordering modes

### Smart Sort

Smart Sort keeps the established artist-spacing and flow behavior exactly as before: global artist/band distribution, Balanced/Rising/Falling, lower-priority Genre/album/version signals and deterministic tie breaking. Era Spread is not part of Smart Sort.

### Direct Sort

Direct Sort remains strict metadata ordering by one or more selected fields: Artist, Genre, Year, Album and Title. Missing values remain after known values, and final relative-path tie breaking keeps output deterministic. Direct Sort does not use BPM, character/energy score or smart artist spacing.

### Era Spread

Era Spread is a separate third ordering engine:

- **New** = 2000 through today;
- **Less new** = 1980–1999;
- **Old** = before 1980;
- the three known eras use the rotating preference `1-2-3`, `1-3-2`, `2-1-3`, `2-3-1`, `3-1-2`, `3-2-1`;
- actual group size is respected across the full playlist, so a small era is not exhausted near the beginning;
- songs without Year form a neutral separate pool and are distributed proportionally;
- artist/Genre spacing is secondary support only. Smart Sort and Direct Sort are not called by Era Spread.

## Filtering

Filtering still happens first and supports:

- All songs;
- one or more Artists;
- one or more Genres.

Therefore Direct Sort can be applied to the complete library or to any currently selected Artist/Genre subset.

## Year compatibility

3.2.1 did not persist Year. 3.3.0 reads `METADATA_KEY_YEAR` and stores a parsed four-digit year. Old analysis/audio cache remains valid: when Direct Sort needs Year **or** Era Spread is selected and an older cache lacks Year, Playlist Maker performs only a lightweight metadata read rather than repeating audio analysis.

## Data paths

`Analyzed library -> User filter -> Smart Sort -> M3U8`

or

`Analyzed library -> User filter -> Direct Sort criteria -> M3U8`

or

`Analyzed library -> User filter -> Era Spread -> M3U8`

The selected output folder, optional diagnostic file and generic Android media refresh remain unchanged from 3.2.x.

GUI language is selectable between **עברית / English** and is remembered between launches.

## Documentation

- [English overview](docs/README_EN.md)
- [סקירה בעברית](docs/README_HE.md)
- [Algorithms — English](docs/ALGORITHMS_EN.md)
- [אלגוריתמים — עברית](docs/ALGORITHMS_HE.md)
- [Architecture / files — English](docs/ARCHITECTURE_EN.md)
- [ארכיטקטורה / קבצים — עברית](docs/ARCHITECTURE_HE.md)
- [Change log — English](docs/CHANGELOG_EN.md)
- [לוג שינויים — עברית](docs/CHANGELOG_HE.md)

## Version

- `versionName`: `3.4.17`
- `versionCode`: `36`
- `applicationId`: `com.example.powerampalternator`
- Display name: **Playlist Maker**
