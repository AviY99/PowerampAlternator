# Changelog

Current release: **3.4.7 — Results scrolling and styled About dialog**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
