# Changelog

Current release: **3.4.1 — Changes & corrections multi-select fix**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
