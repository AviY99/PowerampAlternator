# Changelog

Current release: **3.4.2 — resumable metadata lookup and confidence review fixes**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
