# Changelog

Current release: **3.4.16 — larger About icon + standalone Era Spread**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
