# Changelog

Current release: **3.4.4 — busy-UI lock and clearer Genre review**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
