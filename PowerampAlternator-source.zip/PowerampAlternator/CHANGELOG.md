# Changelog

Current release: **3.4.6 — approved launcher icon and About/developer identification**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
