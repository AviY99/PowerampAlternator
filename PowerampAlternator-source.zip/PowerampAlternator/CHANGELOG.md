# Changelog

Current release: **3.4.3 — live foreground metadata progress with background continuity**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
