# Changelog

Current release: **3.4.17 — true 2× About icon scaling**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
