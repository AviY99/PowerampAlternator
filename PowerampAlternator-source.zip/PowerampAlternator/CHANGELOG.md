# Changelog

Current release: **3.4.0 — Changes & corrections**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
