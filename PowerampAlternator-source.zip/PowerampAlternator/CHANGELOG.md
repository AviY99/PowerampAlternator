# Changelog

Current release: **3.4.15 — polished About + optional Smart Sort era spread**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
