# Changelog / לוג שינויים

- [English changelog](docs/CHANGELOG_EN.md)
- [לוג שינויים בעברית](docs/CHANGELOG_HE.md)
