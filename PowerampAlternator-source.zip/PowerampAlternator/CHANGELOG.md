# Changelog

Current release: **3.4.5 — multiple music libraries with per-root subfolder choice**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
