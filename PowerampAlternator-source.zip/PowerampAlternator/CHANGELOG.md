# Changelog

Current release: **3.4.14 — inline expandable About panel**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
