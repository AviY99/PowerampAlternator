# Changelog

Current release: **3.4.8 — startup-safe Results scrolling fix**.

- [English changelog](docs/CHANGELOG_EN.md)
- [יומן שינויים בעברית](docs/CHANGELOG_HE.md)
