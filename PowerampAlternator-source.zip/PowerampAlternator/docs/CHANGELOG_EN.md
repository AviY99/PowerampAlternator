# Change log — Playlist Maker

## 3.4.0

- Added one **Changes & corrections** area containing all metadata-repair workflows.
- Added missing embedded-tag counts for Artist, Band / Album Artist, Title, Album, Year and Genre.
- Missing-field detection distinguishes real embedded tags from filename fallback and the conservative legacy artist-to-Genre map; approved internal overrides satisfy the field.
- Added per-field missing-song review and an explicit question before any Internet lookup.
- Added read-only MusicBrainz suggestions with a meaningful User-Agent and serialized requests respecting the one-request-per-second service limit.
- Online suggestions are never applied automatically; every proposed change requires an explicit user approval.
- Added verification of **existing** Genre values against MusicBrainz Genre data, including confidence and either “supported” or `current -> suggested` output.
- Genre is still never inferred from audio.
- Moved the legacy manual metadata editor into Changes & corrections and expanded it to Artist, Band / Album Artist, Title, Album, Year and Genre.
- Approved manual/online corrections are stored as per-song Playlist Maker internal overrides; MP3/FLAC tags are not rewritten.
- Added embedded-tag-presence persistence to analysis cache/snapshots while preserving the existing cache version; old 3.3.2 audio analysis is enriched with a lightweight metadata-only pass instead of being repeated.
- Added `INTERNET` permission only for explicit metadata lookup.
- Smart Sort, artist distribution, Balanced/Rising/Falling, Direct Sort criteria/comparator and priority behavior are intentionally unchanged.
- Updated README, bilingual docs, changelog and source comments.
- `versionCode` increased to 20 for signed in-place update; `versionName` is 3.4.0.

## 3.3.2

- Direct Sort now always keeps at least one sort field selected; attempts to clear the final checked row are rejected with a short message.
- Migrates any empty Direct Sort selection saved by 3.3.1 to Title A→Z automatically.
- Replaced Android free-floating drag-and-drop with an in-place vertical-only row drag on the ≡ handle, so the row no longer drifts sideways while priority is changed.
- Reordering still changes only top-to-bottom Direct Sort priority; the Direct Sort comparator and Smart Sort scheduler are unchanged.
- Updated bilingual documentation and source comments.
- `versionCode` increased to 19 for signed in-place update.

## 3.3.1

- Reworked Direct Sort selection into one fixed five-row list: Artist, Genre, Year, Album and Title.
- Each row has a checkbox; only checked rows participate in the comparator.
- Replaced the 3.3.0 add/remove/up/down controls with long-press-and-drag row reordering using the ≡ handle.
- Kept a compact per-row direction control (A→Z/Z→A, Old→New/New→Old for Year).
- Persisted the full visual row order separately from the selected criteria and migrate existing 3.3.0 criteria without losing priority or direction.
- An empty Direct Sort selection is now preserved and intentionally disables Generate until at least one field is checked.
- Removed the broken 3.3.0 down-arrow UI path; the Direct Sort comparator itself is unchanged.
- Smart Sort scheduler, filters, background processing, output-folder behavior and media refresh are unchanged.
- `versionCode` increased to 18 for signed in-place update.

## 3.3.0

- Added a separate **Direct Sort** engine; the approved Smart Sort scheduler remains isolated and unchanged.
- Added a Smart Sort / Direct Sort selector to the Sort & Create card.
- Smart Sort continues to expose Balanced, Rising and Falling.
- Direct Sort hides all flow/energy controls and does not use BPM, character score, or global artist spacing.
- Added ordered Direct Sort criteria: Artist, Genre, Year, Album and Title.
- Supports one criterion or several criteria, up to all five, with per-field ascending/A→Z or descending/Z→A direction.
- Added up/down priority controls, add/remove controls and duplicate-field prevention.
- Filtering remains shared and happens first: All songs, multi-Artist, or multi-Genre.
- Missing Direct Sort values are always placed after known values; `relativePath` provides the final deterministic tie-break.
- Added Year metadata support using `METADATA_KEY_YEAR`; old 3.2.1 audio cache remains valid and is enriched without repeating audio analysis.
- Added Year persistence to cache and background analysis snapshots with backward-compatible reads of old snapshots.
- Background CREATE tasks now persist sort strategy and Direct Sort criteria for process recovery.
- Direct Sort `analysis.txt` reports metadata ordering fields instead of Smart flow/energy diagnostics.
- Updated bilingual documentation and source comments for the two-engine architecture.
- `versionCode` increased to 17 for signed in-place update.

## 3.2.1

- Filter UX update; no smart scheduling algorithm changes.
- Artist filter now supports selecting multiple artists from a scrollable multi-choice list.
- Genre filter now supports selecting multiple Genres from a scrollable multi-choice list.
- Selected entries remain checked when the dialog is reopened and the closed selector summarizes the current selection.
- Persisted multi-selection as JSON arrays while retaining backward compatibility with older single-value preferences/tasks.
- Filter preview count and resumable background CREATE task apply the same selected sets.
- Zero selected entries in Artist/Genre mode intentionally matches zero songs and keeps Create disabled.
- Kept the 3.2.0 output-folder and generic Android media refresh behavior unchanged.
- `versionCode` increased to 16 for signed in-place update.

## 3.2.0

- Storage/discovery update; no playlist scheduling algorithm changes.
- Added a persistent playlist output folder separate from the analyzed music folder.
- Kept the music folder as the backward-compatible default until a dedicated output folder is selected.
- Added GUI controls to show, choose/change, or reset the playlist save location.
- `analysis.txt` now follows the selected playlist output folder.
- Persisted the CREATE-task output URI in `BackgroundWorkService` so process recovery uses the same destination.
- Added a player-independent Android media refresh after writing M3U8: `ContentResolver.notifyChange()` plus `MediaScannerConnection.scanFile()` when a standard external-storage path can be derived.
- Removed the Poweramp launch button and Poweramp package query; no player-specific API is used.
- `versionCode` increased to 15 for signed in-place update.

## 3.1.2

- GUI usability patch; no playlist scheduling algorithm changes.
- Added system-bar safe-area handling for targetSdk 35 edge-to-edge devices so the title no longer sits under the status bar.
- Removed the user-facing Artist + Genre filter; the GUI now offers All songs, Artist, or Genre.
- Added immediate violet pressed-state feedback to programmatic buttons.
- Preserved 3.1.1 filter-count caching and fast language switching.
- Kept legacy combined-filter handling internally only for an already-persisted older task.
- `versionCode` increased to 14 for signed in-place update.

## 3.1.1

- GUI/performance patch; no playlist algorithm changes.
- Kept `Playlist Maker` on a single line in the top bar.
- Reduced the language selector to two compact controls and changed language by rebuilding only the visible UI instead of recreating the Activity.
- Replaced the four large filter tiles with one filter-type drop-down.
- Added progressive disclosure: Artist and/or Genre selectors appear only when required by the selected filter type.
- Cached the filtered-song count so the 500 ms foreground-state poller no longer rebuilds the filtered list repeatedly on the UI thread.
- `versionCode` increased to 13 for signed in-place update.

## 3.1.0

- Added pre-scheduler filters: **All songs, Artist, Genre, Artist + Genre**.
- Artist filtering reuses the scheduler's normalized artist key; Genre filtering uses stored reliable Genre only.
- Placeholder Genre values (`Unknown`, `Music`, `People & Blogs`) are omitted from the selectable Genre list.
- Persisted filter mode/Artist/Genre with the background task so process recovery rebuilds the same subset.
- Added a live filtered-song count and blocks creation when fewer than two songs match.
- Reworked the GUI into a dark card-based design with rounded surfaces, step hierarchy and violet accent.
- Kept the app as a playlist builder only; no playback/player controls were added.
- Changed the default new playlist filename to `Playlist_Maker.m3u8`.
- Kept the approved deterministic scheduling engine unchanged after the filter stage.

## 3.0.0

- Declared 0.2.8 playlist engine as the stable algorithm baseline.
- Added in-app **Hebrew / English** GUI language selection with persistent preference.
- Localized primary controls, help text, result summaries, dialogs, errors, progress text, completion notifications and diagnostic report headings.
- Kept the display name exactly **Playlist Maker**.
- Added bilingual project documentation: overview, algorithm description, architecture/file map and runtime file locations.
- Added descriptive bilingual source comments around GUI construction, library analysis, playlist creation, smart artist scheduler, adaptive Rising/Falling targets and resumable background processing.
- No intentional change to playlist scheduling formulas or priority rules.

## 0.2.8 — stable algorithm baseline

- Added adaptive Rising/Falling targets based on the library's real character-score distribution.
- Preserved scarce calm/energetic tracks for the appropriate later section of Falling/Rising.
- Preserved approved artist-first distribution and Balanced behavior.
- Display name set to `Playlist Maker`.

## 0.2.7

- Added persistent completion notifications and clearer completion/error messages.
- Added GUI polish/result diagnostics and optional `analysis.txt`.
- Added numeric Rising/Falling diagnostics without changing the playlist engine.

## 0.2.6

- Added resumable background processing with persisted task state and analysis snapshot.
- Switched GitHub Actions to a fixed signed Release APK so future versions can update in place.

## 0.2.5

- Balanced mode distributes whichever character class is the minority.
- Preserved artist target windows while allowing limited flow flexibility.

## 0.2.4

- Added automatic playlist analysis report and first foreground-service background implementation.

## 0.2.3

- Introduced global artist-first scheduling; repeated artists receive targets across the full playlist.
- Added GUI/RTL polish.

## 0.2.2

- Iterated on global distribution after testing artist clustering.

## 0.2.1

- Improved playlist creation performance.

## 0.2

- Added smart deterministic distribution foundations.
