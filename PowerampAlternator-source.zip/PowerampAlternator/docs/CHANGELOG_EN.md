# Changelog

## 3.1.1

- GUI/performance patch; no playlist algorithm changes.
- Kept `Playlist Maker` on a single line in the top bar.
- Reduced the language selector to two compact controls and changed language by rebuilding only the visible UI instead of recreating the Activity.
- Replaced the four large filter tiles with one filter-type drop-down.
- Added progressive disclosure: Artist and/or Genre selectors appear only when required by the selected filter type.
- Cached the filtered-song count so the 500 ms foreground-state poller no longer rebuilds the filtered list repeatedly on the UI thread.
- `versionCode` increased to 13 for signed in-place update.

## 3.1.0

- Added pre-scheduler filters: **All songs, Artist, Genre, Artist + Genre**.
- Artist filtering reuses the scheduler's normalized artist key; Genre filtering uses stored reliable Genre only.
- Placeholder Genre values (`Unknown`, `Music`, `People & Blogs`) are omitted from the selectable Genre list.
- Persisted filter mode/Artist/Genre with the background task so process recovery rebuilds the same subset.
- Added a live filtered-song count and blocks creation when fewer than two songs match.
- Reworked the GUI into a dark card-based design with rounded surfaces, step hierarchy and violet accent.
- Kept the app as a playlist builder only; no playback/player controls were added.
- Changed the default new playlist filename to `Playlist_Maker.m3u8`.
- Kept the approved deterministic scheduling engine unchanged after the filter stage.

## 3.0.0

- Declared 0.2.8 playlist engine as the stable algorithm baseline.
- Added in-app **Hebrew / English** GUI language selection with persistent preference.
- Localized primary controls, help text, result summaries, dialogs, errors, progress text, completion notifications and diagnostic report headings.
- Kept the display name exactly **Playlist Maker**.
- Added bilingual project documentation: overview, algorithm description, architecture/file map and runtime file locations.
- Added descriptive bilingual source comments around GUI construction, library analysis, playlist creation, smart artist scheduler, adaptive Rising/Falling targets and resumable background processing.
- No intentional change to playlist scheduling formulas or priority rules.

## 0.2.8 — stable algorithm baseline

- Added adaptive Rising/Falling targets based on the library's real character-score distribution.
- Preserved scarce calm/energetic tracks for the appropriate later section of Falling/Rising.
- Preserved approved artist-first distribution and Balanced behavior.
- Display name set to `Playlist Maker`.

## 0.2.7

- Added persistent completion notifications and clearer completion/error messages.
- Added GUI polish/result diagnostics and optional `analysis.txt`.
- Added numeric Rising/Falling diagnostics without changing the playlist engine.

## 0.2.6

- Added resumable background processing with persisted task state and analysis snapshot.
- Switched GitHub Actions to a fixed signed Release APK so future versions can update in place.

## 0.2.5

- Balanced mode distributes whichever character class is the minority.
- Preserved artist target windows while allowing limited flow flexibility.

## 0.2.4

- Added automatic playlist analysis report and first foreground-service background implementation.

## 0.2.3

- Introduced global artist-first scheduling; repeated artists receive targets across the full playlist.
- Added GUI/RTL polish.

## 0.2.2

- Iterated on global distribution after testing artist clustering.

## 0.2.1

- Improved playlist creation performance.

## 0.2

- Added smart deterministic distribution foundations.
