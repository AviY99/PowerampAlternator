# Architecture, files and locations — English

## Project tree

```text
PowerampAlternator/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/example/powerampalternator/
│           ├── AppLanguage.java
│           ├── BackgroundWorkService.java
│           ├── MainActivity.java
│           └── MetadataOnlineLookup.java
├── docs/
│   ├── README_EN.md
│   ├── README_HE.md
│   ├── ALGORITHMS_EN.md
│   ├── ALGORITHMS_HE.md
│   ├── ARCHITECTURE_EN.md
│   ├── ARCHITECTURE_HE.md
│   ├── CHANGELOG_EN.md
│   └── CHANGELOG_HE.md
├── .github/workflows/build-apk.yml
├── build.gradle
├── settings.gradle
├── gradle.properties
├── README.md
├── README_HE.md
└── CHANGELOG.md
```

## File responsibilities

### `MainActivity.java`

Owns the programmatic UI and the playlist-domain logic. Important sections include:

- folder/output-folder selection through SAF;
- music-library scan and metadata/audio analysis;
- analysis cache, embedded-tag presence tracking and internal metadata overrides;
- Artist/Genre multi-select filtering;
- **Sort strategy GUI** — Smart Sort vs Direct Sort;
- five fixed Direct Sort rows with checkboxes, direction controls and a ≡ vertical-only drag handle for priority reordering; Direct Sort always keeps at least one field selected;
- Direct Sort criteria JSON encoding/decoding;
- Year metadata parsing and old-cache enrichment;
- strict Direct Sort comparator;
- existing `scheduleSmart` engine and its Balanced/Rising/Falling helpers;
- M3U8 writing, diagnostic-file writing and generic Android media refresh;
- the 3.4.0 **Changes & corrections** area: missing-field counts, existing-Genre verification and six-field manual editing;
- explicit approval/apply flow for online suggestions, including wrapped confidence-colored result rows and color-based bulk selection;
- results and bilingual UI helpers.

The `Song` model stores the existing metadata/audio fields plus Year, embedded-tag presence flags for the six correction fields, and per-field override flags. This lets the correction UI distinguish a real embedded tag from filename/trusted-map fallback without changing the effective values used elsewhere.

### `MetadataOnlineLookup.java`

Read-only MusicBrainz client used only after explicit user opt-in from Changes & corrections. It:

- searches MusicBrainz recordings using available title/artist identity;
- obtains recording/release/release-group Genre data for Genre checks;
- calculates a conservative UI confidence value; confidence never blocks a concrete proposal from being reviewed;
- serializes requests to respect MusicBrainz's one-request-per-second requirement;
- never applies an override and never writes an audio file.

### `BackgroundWorkService.java`

Foreground service that owns long-running analysis, creation and online metadata lookup independently from the Activity. A CREATE task persists:

- source tree URI;
- output tree URI;
- filter mode and multi-selection values;
- sort strategy (`Smart Sort` / `Direct Sort`);
- Smart flow mode;
- encoded Direct Sort criteria;
- playlist name/report preference;
- analysis snapshot and progress state.

On process recreation the service reconstructs the same task. If Direct Sort uses Year and the persisted 3.2.1 snapshot has no Year values, the service asks `MainActivity` to perform lightweight Year metadata enrichment before sorting.

A metadata-lookup task persists selected song indexes, its field/check type, partial MusicBrainz results and the next pending index in the private `metadata_lookup_task.json` file. Each completed lookup is checkpointed. The service posts progress/completion notifications and hands persisted proposals back to the Activity only for user review; it never applies them.

### `AppLanguage.java`

Stores the Hebrew/English preference and provides bilingual text selection used by the Activity and Service.

### `AndroidManifest.xml`

Declares the Activity, foreground Service and required `INTERNET`, foreground-service, notification and WakeLock permissions. The application remains a playlist builder and has no player-specific package dependency.

### `app/build.gradle`

Android configuration and Release signing configuration.

Current version:

- `versionName 3.4.2`
- `versionCode 22`
- `applicationId com.example.powerampalternator`

The application ID is intentionally unchanged so the signed APK installs as an update.

### `.github/workflows/build-apk.yml`

GitHub Actions build workflow. It extracts the repository source archive, configures Java/Gradle, restores the Release keystore from GitHub Secrets, builds `:app:assembleRelease`, verifies the APK signature and uploads the Release APK artifact.

## Runtime-generated files and preferences

### SharedPreferences `prefs`

Stores user-facing settings and cache entries, including:

- source tree URI;
- output tree URI;
- GUI language (through `AppLanguage` preferences);
- Smart flow mode;
- playlist name;
- diagnostic-report preference;
- filter mode;
- Artist/Genre multi-selection JSON;
- `sort_strategy`;
- `direct_sort_criteria` JSON;
- per-song analysis cache and internal metadata overrides.

The override JSON can store Artist, Album Artist/Band, Title, Album, Year and Genre. 3.4.x writes only to this internal preference store; it does not rewrite media-file tags.

The per-song cache can also store embedded-tag presence flags. Old 3.3.2 cache objects remain valid: missing presence information is enriched with a lightweight metadata-only read, without re-running audio analysis.

### Background state preferences

`BackgroundWorkService` stores resumable task state under its private `background_job_state` preferences. In addition to the existing analysis/CREATE descriptor, 3.4.2 stores metadata-result readiness/revision, the checked field and whether the task verifies an existing Genre.

### `last_analysis_snapshot.json`

Private app file containing the last analyzed `Song` snapshot for process recovery. 3.4.0 snapshots also persist embedded-tag presence and override flags. Older snapshots remain readable and are enriched on demand for missing-field inspection.

### `metadata_lookup_task.json`

Private checkpoint file for an active/completed online metadata lookup. It stores the selected song indexes, field/check mode, next pending request and partial/result JSON so process recreation can resume the operation without the Activity.

### Playlist output

The selected output SAF tree receives:

- `<playlist>.m3u8`
- `<playlist>-analysis.txt` when diagnostics are enabled.

## Ordering architecture

Filtering is shared and runs first.

Smart branch:

`analysis snapshot -> filter -> scheduleSmart -> M3U8`

Direct branch:

`analysis snapshot -> filter -> optional Year enrichment -> sortDirect -> M3U8`

The branches intentionally meet only before ordering and again at the common file-output layer. This keeps the approved Smart Sort scheduler isolated from Direct Sort.

## Media refresh behavior

After writing a playlist, the app calls `ContentResolver.notifyChange()` for the new SAF document. If the document can be mapped to a standard primary/removable external-storage path, it also requests `MediaScannerConnection.scanFile()`. No player-specific API is called.

## Signing, rollback and updates

`applicationId` and the fixed Release keystore remain unchanged, so 3.4.2 is designed as an in-place signed update.

The stable 3.2.1 source/commit is preserved separately through the Git tag `v3.2.1-stable`. Returning to that source baseline requires rebuilding/signing that tagged source. Android normally will not install an APK with a lower `versionCode` over a newer installed APK without uninstall/downgrade tooling, so the Git tag is primarily a **source rollback point** for development.
