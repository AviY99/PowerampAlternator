# Architecture, files and locations — English

## Project tree

```text
PowerampAlternator/
├── README.md
├── README_HE.md
├── CHANGELOG.md
├── docs/
│   ├── README_HE.md / README_EN.md
│   ├── ALGORITHMS_HE.md / ALGORITHMS_EN.md
│   ├── ARCHITECTURE_HE.md / ARCHITECTURE_EN.md
│   └── CHANGELOG_HE.md / CHANGELOG_EN.md
├── .github/workflows/build-apk.yml
├── build.gradle
├── settings.gradle
├── gradle.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/example/powerampalternator/
            ├── MainActivity.java
            ├── BackgroundWorkService.java
            └── AppLanguage.java
```

## File responsibilities

### `MainActivity.java`
Main GUI and playlist-engine file.

Relevant UI/storage sections include:
- dark card-based GUI construction with system-bar safe areas and button press feedback;
- progressive All songs / Artist / Genre filtering with multi-select Artist and Genre dialogs;
- cached filter preview count;
- independent music-source and playlist-output SAF folder selection;
- output-folder display/change/reset controls;
- `filterSongsForPlaylist()`;
- `writePlaylist()` and optional diagnostic report writing;
- `requestAndroidMediaRefresh()`, which performs player-agnostic post-save refresh notification and MediaScanner request when a filesystem path is available.

The file also contains cache/metadata handling, audio analysis, energy normalization, artist distribution, Balanced/Rising/Falling scheduling and metadata editing.

### `BackgroundWorkService.java`
Foreground service that owns analysis/creation independently of the Activity. It persists task identity, source tree URI, filter state, snapshot and progress. In 3.2.1 a CREATE task also persists `task_output_tree_uri`, so recovery writes to the same selected playlist folder.

### `AppLanguage.java`
Stores `he`/`en` in SharedPreferences and serves bilingual text to Activity and service. It contains no playlist algorithm logic.

### `AndroidManifest.xml`
Foreground-service/notification/WakeLock permissions, service and Activity declarations, RTL support, display label and base theme. Version 3.2.1 has no player-package query because the app does not depend on a specific music player.

### `app/build.gradle`
Android configuration, version (`3.2.1`, code `16`) and Release signing from environment variables supplied by GitHub Secrets.

### `.github/workflows/build-apk.yml`
Extracts the source ZIP, configures Java/Android/Gradle, restores the fixed keystore, runs `assembleRelease`, verifies the APK signature and uploads the artifact.

## Runtime-generated files and preferences

- Music source: user-selected SAF tree used for scan/analysis.
- Playlist output: dedicated persisted SAF tree when selected; otherwise the music source tree is used as the backward-compatible default.
- Playlist: chosen `.m3u8` name in the active output tree.
- Diagnostic report: `<playlist>-analysis.txt` in the same output tree when enabled.
- Analysis snapshot: private app `filesDir`, managed by `BackgroundWorkService`.
- Analysis cache/manual metadata overrides: private SharedPreferences.
- UI preferences: language, flow, playlist name, report option, multi-select filter selections and optional output-tree URI.
- Background task preferences: task type, source URI, CREATE output URI, progress, filter and recovery data.

## Media refresh behavior

After writing the M3U8:

1. `ContentResolver.notifyChange(documentUri, null)` is attempted for every SAF document.
2. `DocumentsContract.getDocumentId()` is used to derive a standard external-storage path when possible.
3. For `primary:` and removable-volume IDs such as `1234-ABCD:`, `MediaScannerConnection.scanFile()` is requested for the exact playlist file.
4. If no normal filesystem path can be derived, the file remains valid in the selected SAF provider, but a third-party player may need its own Rescan/Refresh.

No Poweramp-specific or other player-specific API is called.

## Signing and updates

`applicationId` remains `com.example.powerampalternator`. The fixed release keystore remains unchanged, so 3.2.1 is intended to install as an in-place signed update over the previous stable releases.
