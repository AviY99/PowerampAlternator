# Architecture, files and locations — English

## Project tree

```text
PowerampAlternator/
├── README.md
├── README_HE.md
├── CHANGELOG.md
├── docs/
│   ├── README_HE.md / README_EN.md
│   ├── ALGORITHMS_HE.md / ALGORITHMS_EN.md
│   ├── ARCHITECTURE_HE.md / ARCHITECTURE_EN.md
│   └── CHANGELOG_HE.md / CHANGELOG_EN.md
├── .github/workflows/build-apk.yml
├── build.gradle
├── settings.gradle
├── gradle.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/example/powerampalternator/
            ├── MainActivity.java
            ├── BackgroundWorkService.java
            └── AppLanguage.java
```

## File responsibilities

### `MainActivity.java`
Main GUI and playlist-engine file.

3.1.x sections added/refined here:
- dark card-based GUI construction;
- one progressive filter-mode Spinner (3.1.1; replaces the 3.1.0 mode cards);
- Artist and Genre selector population;
- cached filter preview count to avoid repeated full scans from the UI state poller;
- `filterSongsForPlaylist()` filtering stage;
- filter description shown in results.

Existing responsibilities remain folder selection, cache/metadata, audio analysis, energy normalization, artist distribution, Balanced/Rising/Falling scheduling, M3U8/diagnostic writing and metadata editing.

### `BackgroundWorkService.java`
Foreground service that owns analysis/creation independently of the Activity. Since 3.1.0 it additionally persists `filterMode`, selected Artist and selected Genre and re-applies the filter to the full analysis snapshot before invoking the existing scheduler.

### `AppLanguage.java`
Stores `he`/`en` in SharedPreferences and serves bilingual text to Activity and service. It contains no playlist algorithm logic.

### `AndroidManifest.xml`
Foreground-service/notification/WakeLock permissions, service and Activity declarations, RTL support, display label and dark base theme.

### `app/build.gradle`
Android configuration, version (`3.1.1`, code `13`) and Release signing from environment variables supplied by GitHub Secrets.

### `.github/workflows/build-apk.yml`
Extracts the source ZIP, configures Java/Android/Gradle, restores the fixed keystore, runs `assembleRelease`, verifies the APK signature and uploads the artifact.

## Runtime-generated files

- Playlist: user-selected folder, chosen `.m3u8` name.
- Diagnostic report: same folder as `<playlist>-analysis.txt` when enabled.
- Analysis snapshot: private app `filesDir`, managed by `BackgroundWorkService`.
- Analysis cache/manual metadata overrides: private SharedPreferences.
- UI preferences: language, flow, playlist name, report option and 3.1.x filter selections are persisted in SharedPreferences.
- Background task preferences: task type, tree URI, progress, selected filter and other resumable task data are stored privately by `BackgroundWorkService`.

## Signing and updates

`applicationId` remains `com.example.powerampalternator`. The fixed release keystore remains unchanged, so 3.1.1 installs as an update over the stable signed 3.1.0/3.0.0 builds when `versionCode` increases.
