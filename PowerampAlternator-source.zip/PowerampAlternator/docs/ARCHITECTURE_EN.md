# Architecture, files and locations — English

## Project tree

```text
PowerampAlternator/
├── README.md
├── CHANGELOG.md
├── docs/
│   ├── README_HE.md / README_EN.md
│   ├── ALGORITHMS_HE.md / ALGORITHMS_EN.md
│   └── ARCHITECTURE_HE.md / ARCHITECTURE_EN.md
├── .github/workflows/build-apk.yml
├── build.gradle
├── settings.gradle
├── gradle.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/example/powerampalternator/
            ├── MainActivity.java
            ├── BackgroundWorkService.java
            └── AppLanguage.java
```

## File responsibilities

### `app/src/main/java/com/example/powerampalternator/MainActivity.java`
Main GUI and playlist-engine file. It contains the programmatic screen, folder selection, cache/metadata handling, audio analysis, character scoring/normalization, artist spacing, Balanced logic, Rising/Falling targets, M3U8/diagnostic writing, metadata editor and result rendering.

### `BackgroundWorkService.java`
Foreground service that owns analysis/creation tasks independently of the Activity. It persists state, runs one worker, manages the WakeLock and analysis snapshot, updates the progress notification and posts a separate completion notification.

### `AppLanguage.java`
3.0.0 language layer. Stores `he`/`en` in SharedPreferences and serves Hebrew/English text to both Activity and service. It contains no playlist algorithm logic.

### `AndroidManifest.xml`
Foreground-service/notification/WakeLock permissions, service and Activity declarations, RTL support and the `Playlist Maker` display label.

### `app/build.gradle`
Android configuration: namespace/applicationId, SDK levels, versionCode/versionName and Release signing from environment variables populated by GitHub Secrets.

### `.github/workflows/build-apk.yml`
GitHub Actions workflow: extracts the source ZIP, configures Java/Android/Gradle, restores the keystore from a Secret, runs `assembleRelease`, verifies the signature with `apksigner` and uploads the APK artifact.

### `README.md` + `docs/*`
User/developer documentation: overview, algorithms, architecture and file map in Hebrew and English.

### `CHANGELOG.md`
Version history and major changes.

## Runtime-generated files

- Playlist: written to the user-selected document/music folder under the chosen name with `.m3u8` extension.
- Diagnostic report: same folder as `<playlist>-analysis.txt` when enabled.
- Analysis snapshot: private app `filesDir` file managed by `BackgroundWorkService`.
- Analysis cache and manual metadata overrides: private app SharedPreferences.

## Signing and updates

The `applicationId` remains `com.example.powerampalternator`. The workflow uses the same fixed keystore through GitHub Secrets, so future Release builds can update the installed app as long as versionCode increases and the keystore is preserved.
