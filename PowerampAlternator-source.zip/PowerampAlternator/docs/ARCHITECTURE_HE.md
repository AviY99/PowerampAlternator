# ארכיטקטורה, קבצים ומיקומים — עברית

## עץ פרויקט

```text
PowerampAlternator/
├── README.md
├── README_HE.md
├── CHANGELOG.md
├── docs/
│   ├── README_HE.md / README_EN.md
│   ├── ALGORITHMS_HE.md / ALGORITHMS_EN.md
│   ├── ARCHITECTURE_HE.md / ARCHITECTURE_EN.md
│   └── CHANGELOG_HE.md / CHANGELOG_EN.md
├── .github/workflows/build-apk.yml
├── build.gradle
├── settings.gradle
├── gradle.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/example/powerampalternator/
            ├── MainActivity.java
            ├── BackgroundWorkService.java
            └── AppLanguage.java
```

## תפקידי הקבצים

### `MainActivity.java`
קובץ ה-GUI והמנוע המרכזי.

חלקים רלוונטיים כוללים:
- GUI כהה מבוסס כרטיסים עם Safe Area וחיווי לחיצה;
- סינון מדורג: כל השירים / אמן / Genre;
- מטמון לספירת תוצאת הסינון;
- בחירה נפרדת של תיקיית מקור למוזיקה ותיקיית פלט לפלייליסט;
- הצגה, שינוי ואיפוס של תיקיית הפלט;
- `filterSongsForPlaylist()`;
- כתיבת M3U8 וקובץ בדיקה אופציונלי;
- `requestAndroidMediaRefresh()` שמבצע רענון כללי שאינו תלוי בנגן לאחר השמירה.

הקובץ ממשיך להכיל גם Cache/metadata, ניתוח אודיו, נרמול אופי, פיזור אמנים, מאוזן/מתגבר/יורד ועריכת metadata.

### `BackgroundWorkService.java`
Foreground Service שמנהל ניתוח/יצירה מחוץ ל-Activity. נשמרים סוג המשימה, URI תיקיית המקור, הסינון, snapshot וההתקדמות. ב-3.2.0 משימת CREATE שומרת גם `task_output_tree_uri`, ולכן שחזור תהליך ממשיך לכתוב לאותה תיקיית פלייליסט שנבחרה.

### `AppLanguage.java`
שומר `he`/`en` ב-SharedPreferences ומספק טקסט דו-לשוני ל-Activity ולשירות. אין בו לוגיקת אלגוריתם.

### `AndroidManifest.xml`
הרשאות Foreground Service/notification/WakeLock, הגדרות Activity/Service, RTL, שם התצוגה ו-Theme. ב-3.2.0 אין שאילתת חבילה של נגן מסוים משום שאין תלות בנגן ספציפי.

### `app/build.gradle`
הגדרות Android, גרסה (`3.2.0`, קוד `15`) וחתימת Release ממשתני סביבה שמגיעים מ-GitHub Secrets.

### `.github/workflows/build-apk.yml`
חילוץ ZIP, הכנת Java/Android/Gradle, שחזור ה-keystore הקבוע, `assembleRelease`, אימות חתימה והעלאת artifact.

## קבצים והעדפות בזמן ריצה

- מקור מוזיקה: תיקיית SAF שנבחרה לסריקה ולניתוח.
- פלט פלייליסט: תיקיית SAF קבועה נפרדת אם נבחרה; אחרת תיקיית המוזיקה משמשת כברירת מחדל לצורך תאימות לאחור.
- פלייליסט: קובץ `.m3u8` בשם שנבחר בתיקיית הפלט הפעילה.
- קובץ בדיקה: `<playlist>-analysis.txt` באותה תיקיית פלט כאשר מופעל.
- snapshot ניתוח: קובץ פרטי ב-`filesDir` שמנוהל ב-`BackgroundWorkService`.
- Cache ותיקוני metadata: SharedPreferences פרטיים.
- העדפות GUI: שפה, זרימה, שם פלייליסט, קובץ בדיקה, סינון ו-URI אופציונלי של תיקיית הפלט.
- מצב משימת רקע: סוג משימה, URI מקור, URI פלט במשימת CREATE, התקדמות, סינון ופרטי שחזור.

## רענון מדיה

לאחר כתיבת M3U8:

1. מתבצעת קריאת `ContentResolver.notifyChange(documentUri, null)` עבור מסמך ה-SAF.
2. `DocumentsContract.getDocumentId()` משמש לניסיון להפיק נתיב אחסון חיצוני סטנדרטי.
3. עבור `primary:` ועבור מזהי כרטיס SD כגון `1234-ABCD:` נשלחת בקשת `MediaScannerConnection.scanFile()` לקובץ הפלייליסט המדויק.
4. אם אין נתיב filesystem רגיל, הקובץ עדיין נשמר ב-provider שנבחר, אבל אפליקציית מוזיקה חיצונית עשויה לדרוש Rescan/Refresh משלה.

אין שימוש ב-API של Poweramp או של נגן אחר.

## חתימה ועדכון

`applicationId` נשאר `com.example.powerampalternator` וה-keystore הקבוע אינו משתנה, לכן 3.2.0 מיועדת להתקנה כ-Update חתום מעל הגרסאות היציבות הקודמות.
