# ארכיטקטורה, קבצים ומיקומים — עברית

## עץ פרויקט

```text
PowerampAlternator/
├── README.md
├── CHANGELOG.md
├── docs/
│   ├── README_HE.md / README_EN.md
│   ├── ALGORITHMS_HE.md / ALGORITHMS_EN.md
│   └── ARCHITECTURE_HE.md / ARCHITECTURE_EN.md
├── .github/workflows/build-apk.yml
├── build.gradle
├── settings.gradle
├── gradle.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/example/powerampalternator/
            ├── MainActivity.java
            ├── BackgroundWorkService.java
            └── AppLanguage.java
```

## תפקידי הקבצים

### `app/src/main/java/com/example/powerampalternator/MainActivity.java`
הקובץ המרכזי של GUI ומנוע הפלייליסט. כולל בניית המסך, בחירת תיקייה, Cache/metadata, ניתוח אודיו, חישוב אופי, normalization, פיזור אמנים, Balanced, יעדי Rising/Falling, כתיבת M3U8 וקובץ הבדיקה, עריכת metadata והצגת תוצאות.

### `BackgroundWorkService.java`
Foreground Service שמחזיק את משימות הניתוח/יצירה מחוץ ל-Activity. שומר מצב, מפעיל Worker יחיד, מנהל WakeLock, snapshot, התראות התקדמות והתראת סיום.

### `AppLanguage.java`
שכבת השפה של 3.0.0. שומרת `he`/`en` ב-SharedPreferences ומחזירה טקסט עברי או אנגלי גם ל-Activity וגם לשירות. אינה מכילה לוגיקת פלייליסט.

### `AndroidManifest.xml`
הרשאות Foreground Service/notification/WakeLock, הגדרת השירות וה-Activity, תמיכה RTL ושם התצוגה `Playlist Maker`.

### `app/build.gradle`
הגדרות Android: namespace/applicationId, SDK, versionCode/versionName וחתימת Release מתוך משתני סביבה שמגיעים מ-GitHub Secrets.

### `.github/workflows/build-apk.yml`
GitHub Actions: חילוץ ZIP המקור, Java/Android/Gradle, שחזור keystore מ-Secret, `assembleRelease`, אימות חתימה עם `apksigner`, והעלאת APK כ-artifact.

### `README.md` + `docs/*`
תיעוד למפתחים ולמשתמש: תיאור, אלגוריתמים, ארכיטקטורה ומבנה קבצים בעברית ובאנגלית.

### `CHANGELOG.md`
לוג גרסאות ושינויים מרכזיים.

## קבצים שנוצרים בזמן ריצה

- הפלייליסט: נכתב כתיקיית המסמכים/המוזיקה שבחר המשתמש, בשם שבחר ובסיומת `.m3u8`.
- קובץ בדיקה: באותה תיקייה, בשם `<playlist>-analysis.txt`, אם האפשרות מסומנת.
- snapshot של הניתוח: קובץ פרטי באחסון הפנימי של האפליקציה (`filesDir`) שמנוהל על-ידי `BackgroundWorkService`.
- Cache ותיקוני metadata: SharedPreferences פרטיים של האפליקציה.

## חתימה ועדכונים

`applicationId` נשאר `com.example.powerampalternator`. ה-workflow משתמש באותו keystore קבוע דרך GitHub Secrets, ולכן גרסאות Release עתידיות יכולות להתקין כ-Update כל עוד versionCode עולה וה-keystore נשמר.
