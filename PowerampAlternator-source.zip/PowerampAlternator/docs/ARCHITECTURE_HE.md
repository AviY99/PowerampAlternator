# ארכיטקטורה, קבצים ומיקומים — עברית

## עץ פרויקט

```text
PowerampAlternator/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/example/powerampalternator/
│           ├── AppLanguage.java
│           ├── BackgroundWorkService.java
│           └── MainActivity.java
├── docs/
│   ├── README_EN.md
│   ├── README_HE.md
│   ├── ALGORITHMS_EN.md
│   ├── ALGORITHMS_HE.md
│   ├── ARCHITECTURE_EN.md
│   ├── ARCHITECTURE_HE.md
│   ├── CHANGELOG_EN.md
│   └── CHANGELOG_HE.md
├── .github/workflows/build-apk.yml
├── build.gradle
├── settings.gradle
├── gradle.properties
├── README.md
├── README_HE.md
└── CHANGELOG.md
```

## תפקידי הקבצים

### `MainActivity.java`

מנהל את ה-GUI שנבנה בקוד ואת לוגיקת הפלייליסט. בין החלקים המרכזיים:

- בחירת תיקיית מקור/פלט דרך SAF;
- סריקת הספרייה וניתוח metadata/אודיו;
- cache לניתוח ותיקוני metadata ידניים;
- סינון מרובה לפי Artist/Genre;
- **GUI של שיטת הסידור** — Smart Sort או Direct Sort;
- חמש שורות קבועות של Direct Sort עם ✓ לבחירה, כיוון וידית ≡ לגרירה ושינוי עדיפות;
- שמירה/קריאה של פרמטרי Direct Sort כ-JSON;
- קריאת Year והשלמת מטמון ישן;
- comparator קשיח של Direct Sort;
- מנוע `scheduleSmart` הקיים וכל פונקציות מאוזן/מתגבר/יורד;
- כתיבת M3U8, קובץ בדיקה ורענון Android כללי;
- תוצאות וכלי טקסט דו-לשוניים.

מודל `Song` שומר כעת גם `year` ו-`yearMetadataLoaded`. ערך `year == 0` פירושו שנה לא ידועה.

### `BackgroundWorkService.java`

Foreground Service שמנהל ניתוח/יצירה מחוץ ל-Activity. במשימת CREATE נשמרים:

- URI תיקיית המקור;
- URI תיקיית הפלט;
- מצב הסינון וקבוצות הבחירה המרובות;
- שיטת הסידור (`Smart Sort` / `Direct Sort`);
- מצב הזרימה של Smart Sort;
- פרמטרי Direct Sort המקודדים;
- שם הפלייליסט/בחירת דוח;
- snapshot והתקדמות.

לאחר שחזור תהליך השירות בונה את אותה משימה. אם Direct Sort דורש Year וה-snapshot הישן מ-3.2.1 אינו כולל שנה, השירות מבקש מ-`MainActivity` לקרוא רק את metadata של Year לפני המיון.

### `AppLanguage.java`

שומר בחירת עברית/English ומספק בחירת טקסט דו-לשונית ל-Activity ול-Service.

### `AndroidManifest.xml`

מגדיר Activity, Foreground Service והרשאות notification/WakeLock/foreground service. אין תלות בחבילת נגן מסוימת.

### `app/build.gradle`

הגדרות Android וחתימת Release.

הגרסה הנוכחית:

- `versionName 3.3.1`
- `versionCode 18`
- `applicationId com.example.powerampalternator`

ה-applicationId נשאר ללא שינוי כדי לאפשר Update חתום.

### `.github/workflows/build-apk.yml`

GitHub Actions מחלץ את ארכיון המקור, מכין Java/Gradle, משחזר keystore מתוך GitHub Secrets, בונה `:app:assembleRelease`, מאמת חתימה ומעלה APK Release כ-artifact.

## קבצים והעדפות בזמן ריצה

### SharedPreferences `prefs`

נשמרים בין היתר:

- URI תיקיית המקור;
- URI תיקיית הפלט;
- שפת GUI;
- מצב הזרימה של Smart Sort;
- שם הפלייליסט;
- בחירת קובץ בדיקה;
- מצב הסינון;
- קבוצות Artist/Genre כ-JSON;
- `sort_strategy`;
- `direct_sort_criteria` כ-JSON;
- cache ניתוח לכל שיר ותיקוני metadata ידניים.

cache של שיר יכול כעת לכלול Year. cache ישן ללא Year נשאר תקף ומועשר בלי להפעיל ניתוח אודיו מחדש.

### מצב רקע

`BackgroundWorkService` שומר מצב משימה ניתן לשחזור ב-`background_job_state`. ב-3.3.0 נוספו `task_sort_strategy` ו-`task_direct_sort_criteria` לתיאור משימת CREATE.

### `last_analysis_snapshot.json`

קובץ פרטי של האפליקציה עם snapshot הניתוח האחרון לצורך שחזור תהליך. snapshot חדש יכול לכלול Year; snapshot ישן ללא Year עדיין נקרא.

### פלט פלייליסט

בתיקיית הפלט שנבחרה נכתבים:

- `<playlist>.m3u8`
- `<playlist>-analysis.txt` אם דוח בדיקה מופעל.

## ארכיטקטורת הסידור

הסינון משותף ומתבצע ראשון.

ענף Smart:

`analysis snapshot -> filter -> scheduleSmart -> M3U8`

ענף Direct:

`analysis snapshot -> filter -> השלמת Year לפי צורך -> sortDirect -> M3U8`

הענפים נפגשים לפני שלב הסידור ושוב רק בשכבת כתיבת הקובץ. כך Smart Sort המאושר נשאר מבודד מ-Direct Sort.

## רענון מדיה

אחרי כתיבת הפלייליסט נשלח `ContentResolver.notifyChange()` למסמך SAF החדש. אם ניתן לחשב נתיב אחסון ראשי/כרטיס חיצוני רגיל, נשלחת גם בקשת `MediaScannerConnection.scanFile()`. אין API ייעודי לנגן.

## חתימה, חזרה ועדכון

`applicationId` וה-keystore הקבוע נשארים ללא שינוי, ולכן 3.3.1 מיועדת להתקנה כ-Update חתום.

מקור 3.2.1 היציב נשמר בנפרד באמצעות Git tag בשם `v3.2.1-stable`. זהו **נקודת חזרה של המקור** לפיתוח. Android בדרך כלל אינו מתקין APK עם `versionCode` נמוך יותר מעל גרסה חדשה בלי הסרה/כלי downgrade, ולכן חזרה לפיתוח נעשית מה-tag ואז בונים גרסת המשך מתאימה.
