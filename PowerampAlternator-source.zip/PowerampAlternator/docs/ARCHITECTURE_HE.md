# ארכיטקטורה, קבצים ומיקומים — עברית

## עץ פרויקט

```text
PowerampAlternator/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── res/mipmap-*/ic_launcher.png
│       └── java/com/example/powerampalternator/
│           ├── AppLanguage.java
│           ├── BackgroundWorkService.java
│           ├── MainActivity.java
│           └── MetadataOnlineLookup.java
├── docs/
│   ├── README_EN.md
│   ├── README_HE.md
│   ├── ALGORITHMS_EN.md
│   ├── ALGORITHMS_HE.md
│   ├── ARCHITECTURE_EN.md
│   ├── ARCHITECTURE_HE.md
│   ├── CHANGELOG_EN.md
│   └── CHANGELOG_HE.md
├── .github/workflows/build-apk.yml
├── build.gradle
├── settings.gradle
├── gradle.properties
├── README.md
├── README_HE.md
└── CHANGELOG.md
```

## תפקידי הקבצים

### `MainActivity.java`

מנהל את ה-GUI שנבנה בקוד ואת לוגיקת הפלייליסט. בין החלקים המרכזיים:

- בחירה מתמשכת של כמה ספריות מקור/תיקיית פלט דרך SAF, עם ✓ ובחירת תתי-ספריות נפרדת לכל שורש;
- סריקת הספרייה וניתוח metadata/אודיו;
- cache לניתוח, מעקב אחרי קיום תגיות משובצות ו-overrides פנימיים של metadata;
- סינון מרובה לפי Artist/Genre;
- **GUI של שיטת הסידור** — Smart Sort או Direct Sort;
- חמש שורות קבועות של Direct Sort עם ✓ לבחירה, כיוון וידית ≡ לגרירה ושינוי עדיפות;
- שמירה/קריאה של פרמטרי Direct Sort כ-JSON;
- קריאת Year והשלמת מטמון ישן;
- comparator קשיח של Direct Sort;
- מנוע `scheduleSmart`, פונקציות מאוזן/מתגבר/יורד ושכבת פיזור תקופות אופציונלית;
- כתיבת M3U8, קובץ בדיקה ורענון Android כללי;
- אזור **שינויים ותיקונים** של 3.4.0: ספירת שדות חסרים, בדיקת Genre קיים ועורך ידני לשישה שדות;
- מסלול אישור מפורש לפני החלת הצעת רשת, כולל שורות תוצאה עטופות בצבעי ביטחון ובחירה מרוכזת לפי צבע;
- תוצאות וכלי טקסט דו-לשוניים.

מודל `Song` שומר את שדות ה-metadata/אודיו הקיימים, Year, דגלים שמציינים האם כל אחת משש התגיות קיימת באמת בקובץ, ודגלי override לכל שדה. כך ממשק התיקונים יכול להבדיל בין תגית אמיתית לבין fallback בלי לשנות את הערכים האפקטיביים בשאר האפליקציה.

### `MetadataOnlineLookup.java`

לקוח MusicBrainz לקריאה בלבד, שמופעל רק אחרי opt-in מפורש מתוך שינויים ותיקונים. הוא:

- מחפש Recording לפי כותרת/אמן זמינים;
- קורא Genre מ-Recording/Release Group לצורך בדיקת Genre;
- מחשב רמת ביטחון שמרנית להצגה; הביטחון אינו חוסם הצעה ממשית מהצגת/בחירת המשתמש;
- מסדר בקשות כך שלא תישלח יותר מבקשה אחת בשנייה;
- אינו מחיל override ואינו כותב לקובץ אודיו.

### `BackgroundWorkService.java`

Foreground Service שמנהל ניתוח, יצירה וחיפוש metadata ברשת מחוץ ל-Activity. במשימת CREATE נשמרים:

- URI של ספריית המקור הראשית לצורך תאימות;
- רשימת JSON של שורשי הספריות השמורים, מצב ✓ ובחירת רקורסיה לכל שורש;
- URI תיקיית הפלט;
- מצב הסינון וקבוצות הבחירה המרובות;
- שיטת הסידור (`Smart Sort` / `Direct Sort` / `Era Spread`);
- מצב הזרימה של Smart Sort;
- פרמטרי Direct Sort המקודדים;
- שם הפלייליסט/בחירת דוח;
- snapshot והתקדמות.

לאחר שחזור תהליך השירות בונה את אותה משימה. אם Direct Sort דורש Year או אם נבחר Era Spread וה-snapshot הישן אינו כולל שנה, השירות מבקש מ-`MainActivity` לקרוא רק את metadata של Year לפני המיון.

משימת metadata שומרת בקובץ הפרטי `metadata_lookup_task.json` את אינדקסי השירים, סוג השדה/הבדיקה, תוצאות MusicBrainz חלקיות ואת האינדקס הבא. כל תוצאה שהושלמה נשמרת כ-checkpoint. השירות מציג התקדמות/התראת סיום ומחזיר את ההצעות השמורות ל-Activity רק לצורך החלטת המשתמש; הוא אינו מחיל אותן.

### `AppLanguage.java`

שומר בחירת עברית/English ומספק בחירת טקסט דו-לשונית ל-Activity ול-Service.

### `AndroidManifest.xml`

מגדיר Activity, Foreground Service והרשאות `INTERNET`, notification, WakeLock ו-foreground service. אין תלות בחבילת נגן מסוימת.

### `app/build.gradle`

הגדרות Android וחתימת Release.

הגרסה הנוכחית:

- `versionName 3.4.16`
- `versionCode 36`
- `applicationId com.example.powerampalternator`

ה-applicationId נשאר ללא שינוי כדי לאפשר Update חתום.

### `.github/workflows/build-apk.yml`

GitHub Actions מחלץ את ארכיון המקור, מכין Java/Gradle, משחזר keystore מתוך GitHub Secrets, בונה `:app:assembleRelease`, מאמת חתימה ומעלה APK Release כ-artifact.

## קבצים והעדפות בזמן ריצה

### SharedPreferences `prefs`

נשמרים בין היתר:

- URI של ספריית המקור הראשית לצורך תאימות;
- רשימת JSON של שורשי הספריות השמורים, מצב ✓ ובחירת רקורסיה לכל שורש;
- URI תיקיית הפלט;
- שפת GUI;
- מצב הזרימה של Smart Sort;
- שם הפלייליסט;
- בחירת קובץ בדיקה;
- מצב הסינון;
- קבוצות Artist/Genre כ-JSON;
- `sort_strategy`;
- `direct_sort_criteria` כ-JSON;
- cache ניתוח לכל שיר ו-overrides פנימיים של metadata.

JSON ה-override יכול לשמור אמן, Album Artist/להקה, כותרת, אלבום, שנה ו-Genre. ב-3.4.x אין כתיבה חוזרת של תגיות לקובצי המדיה.

cache של שיר יכול לכלול גם דגלים של קיום תגיות משובצות. cache ישן מ-3.3.2 נשאר תקף; מידע חסר על קיום תגיות מושלם בקריאת metadata קלה בלבד, בלי ניתוח אודיו מחדש.

### מצב רקע

`BackgroundWorkService` שומר מצב משימה ניתן לשחזור ב-`background_job_state`, כולל מצב בדיקת metadata, התקדמות ותוצאות שמורות. ב-3.4.5 משימת ANALYZE שומרת גם את רשימת שורשי הספרייה הפעילים ואת בחירת הרקורסיה לכל שורש. כל עוד ה-Activity פתוח, `MainActivity` קורא את אותו מצב ומציג חיווי חי בתוך אזור שינויים ותיקונים; לא נוצר worker נוסף. במזעור/עזיבה רק ה-UI מתנתק והשירות ממשיך, ובחזרה ה-UI מתחבר שוב לאותה משימה. בזמן שמצב `busy` השמור פעיל, `MainActivity` גם משבית את כל פקדי הקלט במסך הראשי. זו נעילת UI בלבד; היא אינה מפעילה worker נוסף ומשתחררת כאשר אותו מצב שמור חוזר ל-false. `task_sort_strategy` ו-`task_direct_sort_criteria` נשמרים כחלק ממשימת CREATE.

### `last_analysis_snapshot.json`

קובץ פרטי של האפליקציה עם snapshot הניתוח האחרון לצורך שחזור תהליך. ב-3.4.0 נשמרים גם דגלי קיום תגיות ודגלי override. snapshot ישן עדיין נקרא ומועשר לפי צורך בעת בדיקת שדות חסרים.


### `metadata_lookup_task.json`

קובץ checkpoint פרטי למשימת metadata פעילה/שהושלמה. נשמרים בו אינדקסי השירים שנבחרו, סוג השדה/מצב הבדיקה, הפריט הבא ותוצאות חלקיות, כדי לאפשר Resume ללא תלות ב-Activity.

### פלט פלייליסט

בתיקיית הפלט שנבחרה נכתבים:

- `<playlist>.m3u8`
- `<playlist>-analysis.txt` אם דוח בדיקה מופעל.

## ארכיטקטורת הסידור

הסינון משותף ומתבצע ראשון.

ענף Smart:

`analysis snapshot -> filter -> scheduleSmart -> M3U8`

ענף Direct:

`analysis snapshot -> filter -> השלמת Year לפי צורך -> sortDirect -> M3U8`

ענף Era:

`analysis snapshot -> filter -> השלמת Year קלה לפי הצורך -> scheduleEraSpread -> M3U8`

שלושת מנועי הסידור עצמאיים: Smart Sort אינו מפעיל Era Spread, ו-Era Spread אינו מפעיל Smart Sort או Direct Sort. שלושתם נפגשים שוב רק בשכבת כתיבת הקובץ.

## רענון מדיה

אחרי כתיבת הפלייליסט נשלח `ContentResolver.notifyChange()` למסמך SAF החדש. אם ניתן לחשב נתיב אחסון ראשי/כרטיס חיצוני רגיל, נשלחת גם בקשת `MediaScannerConnection.scanFile()`. אין API ייעודי לנגן.

## חתימה, חזרה ועדכון

`applicationId` וה-keystore הקבוע נשארים ללא שינוי, ולכן 3.4.16 מיועדת להתקנה כ-Update חתום.

מקור 3.2.1 היציב נשמר בנפרד באמצעות Git tag בשם `v3.2.1-stable`. זהו **נקודת חזרה של המקור** לפיתוח. Android בדרך כלל אינו מתקין APK עם `versionCode` נמוך יותר מעל גרסה חדשה בלי הסרה/כלי downgrade, ולכן חזרה לפיתוח נעשית מה-tag ואז בונים גרסת המשך מתאימה.
