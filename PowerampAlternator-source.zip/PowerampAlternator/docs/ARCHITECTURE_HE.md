# ארכיטקטורה, קבצים ומיקומים — עברית

## עץ פרויקט

```text
PowerampAlternator/
├── README.md
├── README_HE.md
├── CHANGELOG.md
├── docs/
│   ├── README_HE.md / README_EN.md
│   ├── ALGORITHMS_HE.md / ALGORITHMS_EN.md
│   ├── ARCHITECTURE_HE.md / ARCHITECTURE_EN.md
│   └── CHANGELOG_HE.md / CHANGELOG_EN.md
├── .github/workflows/build-apk.yml
├── build.gradle
├── settings.gradle
├── gradle.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/example/powerampalternator/
            ├── MainActivity.java
            ├── BackgroundWorkService.java
            └── AppLanguage.java
```

## תפקידי הקבצים

### `MainActivity.java`
קובץ ה-GUI והמנוע המרכזי.

ב-3.1.0 נוספו בו:
- בניית GUI כהה מבוסס כרטיסים;
- כרטיסי בחירת מצב סינון;
- רשימות בחירת Artist ו-Genre;
- תצוגת מספר השירים לאחר סינון;
- `filterSongsForPlaylist()`;
- תיאור הסינון בתוצאות.

הקובץ ממשיך להכיל גם בחירת תיקייה, Cache/metadata, ניתוח אודיו, נרמול אופי, פיזור אמנים, מאוזן/מתגבר/יורד, כתיבת M3U8 וקובץ בדיקה ועריכת metadata.

### `BackgroundWorkService.java`
Foreground Service שמנהל ניתוח/יצירה מחוץ ל-Activity. ב-3.1.0 הוא שומר גם `filterMode`, Artist ו-Genre נבחרים ומחיל את הסינון על snapshot הניתוח המלא לפני קריאה לאלגוריתם הקיים.

### `AppLanguage.java`
שומר `he`/`en` ב-SharedPreferences ומספק טקסט דו-לשוני ל-Activity ולשירות. אין בו לוגיקת אלגוריתם.

### `AndroidManifest.xml`
הרשאות Foreground Service/notification/WakeLock, הגדרות Activity/Service, RTL, שם התצוגה ו-Theme בסיס כהה.

### `app/build.gradle`
הגדרות Android, גרסה (`3.1.0`, קוד `12`) וחתימת Release ממשתני סביבה שמגיעים מ-GitHub Secrets.

### `.github/workflows/build-apk.yml`
חילוץ ZIP, הכנת Java/Android/Gradle, שחזור ה-keystore הקבוע, `assembleRelease`, אימות חתימה והעלאת artifact.

## קבצים ומצב בזמן ריצה

- פלייליסט: בתיקייה שבחר המשתמש, בשם `.m3u8` שנבחר.
- קובץ בדיקה: `<playlist>-analysis.txt` באותה תיקייה אם מופעל.
- snapshot ניתוח: קובץ פרטי ב-`filesDir` שמנוהל ב-`BackgroundWorkService`.
- Cache ותיקוני metadata: SharedPreferences פרטיים.
- העדפות GUI: שפה, זרימה, שם פלייליסט, קובץ בדיקה ובחירות הסינון של 3.1.0 נשמרות ב-SharedPreferences.
- מצב משימת רקע: סוג משימה, URI, התקדמות, סינון ופרטי שחזור נוספים נשמרים באופן פרטי על-ידי השירות.

## חתימה ועדכון

`applicationId` נשאר `com.example.powerampalternator` וה-keystore הקבוע אינו משתנה, לכן 3.1.0 מיועדת להתקנה כ-Update מעל 3.0.0 החתומה.
