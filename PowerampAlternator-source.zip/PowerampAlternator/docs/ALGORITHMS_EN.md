# Playlist Maker algorithms — English

## Principles

Scheduling is deterministic: the same input and settings are intended to produce the same order. No random number generator is used. Stable file-path ordering participates in tie breaking.

## 3.1.x data path

`Full analyzed snapshot -> User filter -> Existing smart scheduler -> M3U8`

The filter stage does not reorder tracks. It only selects the input subset. Version 3.1.1 changes only GUI presentation/performance around this stage; `filterSongsForPlaylist()` and the scheduler priority rules remain unchanged.

## Filter stage — START

`MainActivity.filterSongsForPlaylist()` creates a new list from the analysis snapshot:

- `FILTER_ALL`: accept every analyzed song.
- `FILTER_ARTIST`: compare the selected artist against the song's normalized scheduling artist key.
- `FILTER_GENRE`: compare the selected Genre against the normalized stored Genre.
- `FILTER_ARTIST_GENRE`: require both matches.

The original analysis snapshot is retained. `BackgroundWorkService` persists filter mode/artist/Genre with the task and applies the filter again immediately before playlist creation, so process recovery uses the same subset.

Genre filtering never derives Genre from audio. Placeholder genres excluded from the selector include `Unknown`, `Music`, and `People & Blogs`.

## Filter stage — END

## Priority order inside the smart scheduler

1. **Filtered input set** — only songs accepted by the 3.1.x filter participate.
2. **Global artist/band distribution** — primary hard constraint.
3. **Reliable Genre** — secondary signal only.
4. **Album/version separation** — secondary anti-clustering signal.
5. **Character flow** — Balanced/Rising/Falling.
6. **Deterministic tie break**.

## Artist/band distribution — START

`MainActivity.scheduleSmart()` assigns each track a scheduling artist key. An artist occurring `N` times receives `N` ideal target slots spread across the complete filtered playlist. Once this artist skeleton exists, each artist token may move by at most **±1 position** from its target.

Unknown artists are not merged into one giant group; each unknown file receives its own deterministic singleton key.

## Artist/band distribution — END

## Balanced — START

The character threshold divides the filtered set into calm and energetic groups. The algorithm counts both and distributes the **smaller group**. It does not manufacture a 50/50 ratio.

## Balanced — END

## Rising / Falling — START

`buildDirectionalFlowTargets()` sorts the filtered set's real character scores and generates a target for each position from that distribution instead of using an artificial fixed ramp.

- **Rising** moves from lower-score targets toward higher-score targets.
- **Falling** moves from higher-score targets toward lower-score targets.

Artist spacing remains primary: the flow target chooses the best song within the artist window.

## Rising / Falling — END

## Secondary signals

After artist and flow constraints narrow the candidates, `secondaryDistributionScore()` gives a small influence to Genre, album and version-family separation. These signals are not allowed to reintroduce artist clustering.

## Character score

The app derives character from audio features such as loudness/RMS, BPM/activity and normalizes them against the analyzed library. The 0–100 value shown in diagnostics is a presentation of the internal value and is not a Genre classifier.

## analysis.txt

The diagnostic file is generated from the final filtered playlist. It includes position, artist, title, character score, calm/energetic class, BPM, Genre and distribution group. Balanced reports minority target/actual gap; Rising/Falling report fifth-segment averages, start/end, change and position-energy correlation.
