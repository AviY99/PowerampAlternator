# Playlist Maker algorithms — English

## Principles

Scheduling is deterministic: the same input and settings are intended to produce the same order. No random number generator is used. Stable file-path ordering participates in tie breaking.

## Priority order

1. **Input/filter set** — only selected/analyzed tracks participate.
2. **Global artist/band distribution** — primary hard constraint.
3. **Reliable Genre** — secondary signal only.
4. **Album/version separation** — secondary anti-clustering signal.
5. **Character flow** — Balanced/Rising/Falling.
6. **Deterministic tie break**.

## Artist/band distribution — START

`MainActivity.scheduleSmart()` assigns each track a scheduling artist key. An artist occurring `N` times receives `N` ideal target slots spread across the complete playlist. Once this artist skeleton exists, each artist token may move by at most **±1 position** from its target. This hard window prevents the large repeated-artist clusters that earlier versions could create.

Unknown artists are not merged into one giant group; each unknown file receives its own deterministic singleton key.

## Artist/band distribution — END

## Balanced — START

The character threshold divides tracks into calm and energetic groups. The algorithm counts both groups and distributes the **smaller group**. It does not manufacture a 50/50 ratio that the library does not contain.

Example: with 140 calm and 596 energetic tracks, calm tracks are the distributed minority. If the ratio is reversed, energetic tracks are distributed. The target gap comes from playlist size divided by minority count.

## Balanced — END

## Rising / Falling — START

`buildDirectionalFlowTargets()` sorts the library's real character scores and generates a target for each position from that distribution instead of using an artificial fixed 0.10–0.90 ramp.

- **Rising** moves from lower-score targets toward higher-score targets.
- **Falling** moves from higher-score targets toward lower-score targets.

This reserves scarce tracks for the section that needs them. For example, when energetic tracks are a minority in Rising mode, they are not all consumed too early.

Artist spacing remains primary: the flow target chooses the best song within the artist window; it does not replace the artist skeleton.

## Rising / Falling — END

## Secondary signals

After artist and flow constraints narrow the candidates, `secondaryDistributionScore()` gives a small influence to Genre, album and version-family separation. These signals are not allowed to reintroduce artist clustering.

## Character score

The app derives character from audio features such as loudness/RMS, BPM/activity and normalizes them against the library. The 0–100 value shown in diagnostics is a presentation of the internal value and is not a Genre classifier.

## analysis.txt

The diagnostic file includes position, artist, title, character score, calm/energetic class, BPM, Genre and distribution group. Balanced reports minority target/actual gap; Rising/Falling report fifth-segment averages, start/end, change and position-energy correlation.
