# Playlist Maker algorithms — English

## Principles

Playlist Maker is deterministic: the same analyzed library, filter and ordering settings produce the same ordering. No random shuffle is used.

Version 3.4.15 keeps the two ordering engines separate. Direct Sort still performs strict ordered metadata comparison and never calls the Smart Sort scheduler. Smart Sort keeps the existing global artist skeleton and Balanced/Rising/Falling formulas, with one new optional era-spread score.

> **3.4.15 scope:** Era spread is active only when explicitly enabled. When it is off, the era score is zero. Global artist targets, the ±1 window, Balanced minority distribution, adaptive Rising/Falling targets and deterministic tie breaking remain as in 3.4.14. Direct Sort never uses era spread.

## 3.4.0 data path

`Analyzed library -> Filter -> [Smart Sort OR Direct Sort] -> M3U8`

The filter stage selects the input subset only. It does not reorder tracks.

## Filter stage — START

The GUI exposes:

- **All songs**;
- **Artist** — one or more selected artists;
- **Genre** — one or more selected Genres.

Artist matching uses the same normalized artist identity used by Smart Sort. Genre matching uses stored reliable Genre metadata/trusted mapping only and never audio-only Genre guessing. `Unknown`, `Music` and `People & Blogs` are not selectable Genre filters.

Selections are stored as JSON arrays. Legacy single-value preferences remain readable. A selected Artist/Genre mode with zero selected values matches zero songs.

## Filter stage — END

## Smart Sort — START

Smart Sort is the existing algorithm; 3.4.15 adds only an optional era preference layer.

### Priority order inside Smart Sort

1. User filter is applied first, outside the scheduler.
2. Global artist/band distribution is a hard constraint through the target skeleton and ±1 window.
3. Inside that window, the flow/character target and optional 3.4.15 era score influence candidate choice.
4. Reliable Genre, album/version and other secondary keys remain lower-priority signals.
5. A deterministic path tie-break resolves equality.

When era spread is disabled its contribution is `0.0`, keeping the Smart Sort selection path behavior-compatible with 3.4.14.

### Artist/band distribution

Repeated artists receive global targets across the whole filtered playlist. Approved normalization groups safe variants such as Beatles/The Beatles and selected known collection names. A small target window allows lower-priority flow improvements without destroying artist spacing.

### Balanced

Balanced distributes whichever energy class is smaller. If calm tracks are the minority, calm tracks are distributed; if energetic tracks are the minority, energetic tracks are distributed. Near an even split, alternation is used where possible.

### Rising / Falling

Rising and Falling use adaptive targets derived from the actual character-score distribution of the selected library/subset. This preserves scarce calm/energetic tracks for the appropriate part of the list instead of consuming them too early.

### Secondary signals

Reliable Genre, album/version and related schedule keys are lower-priority than artist spacing. Genre is never inferred from audio alone.

### Era spread — 3.4.15

The optional **Also spread by era** control uses the Year already stored on each `Song`:

- `1 / new` — year 2000 or later;
- `2 / less new` — 1980–1999;
- `3 / old` — before 1980;
- `0` — unknown Year.

Each known era gets an `idealNext` occurrence derived from its total count and how many tracks from that era have already been placed. A small era therefore gets wider gaps and remains distributed across the full playlist rather than being consumed by the first pattern cycles.

When multiple eras are similarly due, preference advances through an 18-position cycle containing all six permutations:
`1-2-3`, `1-3-2`, `2-1-3`, `2-3-1`, `3-1-2`, `3-2-1`.

Closeness/overdue status relative to `idealNext` provides a soft score, with an additional bonus for the pattern-preferred era. Other known eras remain legal and unknown-Year tracks are never blocked, so missing/exhausted groups cannot deadlock the scheduler. Global artist spacing remains the hard constraint and Balanced/Rising/Falling continues at the same time.


## Smart Sort — END

## Direct Sort — START

Direct Sort is a strict lexicographic metadata sort. It does **not** use:

- BPM;
- character/energy score;
- Balanced/Rising/Falling targets;
- global artist-spacing targets;
- Smart Sort secondary distribution scoring.

The user may choose one to five criteria from:

- `artist`
- `genre`
- `year`
- `album`
- `title`

The criteria list order is the priority order. For each pair of songs, criterion 1 is compared first. Criterion 2 is evaluated only if criterion 1 is equal, and so on.

Each criterion stores a direction:

- ascending / A→Z;
- descending / Z→A.

Duplicate criteria are not allowed.

### Direct Artist

Artist comparison uses the normalized artist scheduling identity. This groups approved safe name variants, but **does not distribute** repeated artists across the playlist.

### Direct Genre

Genre comparison uses the stored normalized Genre value. No audio-only Genre inference is introduced.

### Direct Year

Year is parsed from Android `METADATA_KEY_YEAR`. The first plausible four-digit year in the metadata value is stored. `0` means unknown.

Known years are compared numerically. Unknown years are always placed after known years, for both ascending and descending order.

### Direct Album / Title

Album and Title are compared case-insensitively, with a case-sensitive comparison as a secondary deterministic comparison. Missing text values are always placed after known values.

### Final tie-break

If every selected criterion compares equal, `relativePath` is compared case-insensitively and then case-sensitively. This final tie-break is always ascending and exists only to make output deterministic.

## Direct Sort — END

## Year cache compatibility

The 3.2.1 cache format did not contain Year. 3.3.0 intentionally keeps the existing audio-analysis cache version so expensive audio analysis remains reusable. On an old cache hit, only missing Year metadata is read and then written back into the cache. Old persisted analysis snapshots are similarly enriched when Direct Sort needs Year or when Smart Sort era spread is enabled.

## Character score

The character score remains an internal Smart Sort diagnostic derived from normalized loudness/activity/BPM-related analysis. It is not used by Direct Sort.

## analysis.txt

Smart Sort reports retain the existing energy/flow diagnostics. In 3.4.15 they also report whether era spread is enabled, counts for new/less-new/old/unknown-Year tracks, and the preferred permutation cycle.

Direct Sort reports instead contain:

- sort method;
- ordered Direct Sort criteria;
- filter description;
- song count;
- Position, Artist, Title, Year, Album and Genre columns.

Direct Sort reports deliberately omit character/BPM flow diagnostics because those values do not participate in the direct ordering.

## Output and media refresh

Both engines write the same M3U8 format and use the same selected output folder. After writing, Playlist Maker requests a generic Android media refresh without a player-specific API.
