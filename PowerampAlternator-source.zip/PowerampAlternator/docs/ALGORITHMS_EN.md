# Playlist Maker algorithms — English

## Principles

Playlist Maker is deterministic: the same analyzed library, filter and ordering settings produce the same ordering. No random shuffle is used.

Version 3.4.5 keeps the two separate ordering engines from 3.3.2 unchanged. Smart Sort preserves the approved smart scheduler. Direct Sort performs strict ordered metadata comparison and does not call the Smart Sort scheduler.

> **3.4.5 scope:** Multiple source libraries only expand the analyzed input set before filtering/sorting, and Changes & corrections can alter effective metadata only after explicit user approval. No Smart Sort, artist-spacing, Balanced/Rising/Falling, or Direct Sort algorithm code was changed.

## 3.4.0 data path

`Analyzed library -> Filter -> [Smart Sort OR Direct Sort] -> M3U8`

The filter stage selects the input subset only. It does not reorder tracks.

## Filter stage — START

The GUI exposes:

- **All songs**;
- **Artist** — one or more selected artists;
- **Genre** — one or more selected Genres.

Artist matching uses the same normalized artist identity used by Smart Sort. Genre matching uses stored reliable Genre metadata/trusted mapping only and never audio-only Genre guessing. `Unknown`, `Music` and `People & Blogs` are not selectable Genre filters.

Selections are stored as JSON arrays. Legacy single-value preferences remain readable. A selected Artist/Genre mode with zero selected values matches zero songs.

## Filter stage — END

## Smart Sort — START

Smart Sort is the existing algorithm and remains intentionally unchanged in 3.4.0.

### Priority order inside Smart Sort

1. User filter is applied first, outside the scheduler.
2. Global artist/band distribution.
3. Reliable Genre consideration.
4. Album/version separation.
5. Flow/character objective.
6. Deterministic tie-break.

### Artist/band distribution

Repeated artists receive global targets across the whole filtered playlist. Approved normalization groups safe variants such as Beatles/The Beatles and selected known collection names. A small target window allows lower-priority flow improvements without destroying artist spacing.

### Balanced

Balanced distributes whichever energy class is smaller. If calm tracks are the minority, calm tracks are distributed; if energetic tracks are the minority, energetic tracks are distributed. Near an even split, alternation is used where possible.

### Rising / Falling

Rising and Falling use adaptive targets derived from the actual character-score distribution of the selected library/subset. This preserves scarce calm/energetic tracks for the appropriate part of the list instead of consuming them too early.

### Secondary signals

Reliable Genre, album/version and related schedule keys are lower-priority than artist spacing. Genre is never inferred from audio alone.

## Smart Sort — END

## Direct Sort — START

Direct Sort is a strict lexicographic metadata sort. It does **not** use:

- BPM;
- character/energy score;
- Balanced/Rising/Falling targets;
- global artist-spacing targets;
- Smart Sort secondary distribution scoring.

The user may choose one to five criteria from:

- `artist`
- `genre`
- `year`
- `album`
- `title`

The criteria list order is the priority order. For each pair of songs, criterion 1 is compared first. Criterion 2 is evaluated only if criterion 1 is equal, and so on.

Each criterion stores a direction:

- ascending / A→Z;
- descending / Z→A.

Duplicate criteria are not allowed.

### Direct Artist

Artist comparison uses the normalized artist scheduling identity. This groups approved safe name variants, but **does not distribute** repeated artists across the playlist.

### Direct Genre

Genre comparison uses the stored normalized Genre value. No audio-only Genre inference is introduced.

### Direct Year

Year is parsed from Android `METADATA_KEY_YEAR`. The first plausible four-digit year in the metadata value is stored. `0` means unknown.

Known years are compared numerically. Unknown years are always placed after known years, for both ascending and descending order.

### Direct Album / Title

Album and Title are compared case-insensitively, with a case-sensitive comparison as a secondary deterministic comparison. Missing text values are always placed after known values.

### Final tie-break

If every selected criterion compares equal, `relativePath` is compared case-insensitively and then case-sensitively. This final tie-break is always ascending and exists only to make output deterministic.

## Direct Sort — END

## Year cache compatibility

The 3.2.1 cache format did not contain Year. 3.3.0 intentionally keeps the existing audio-analysis cache version so expensive audio analysis remains reusable. On an old cache hit, only missing Year metadata is read and then written back into the cache. Old persisted analysis snapshots are similarly enriched when Direct Sort needs Year.

## Character score

The character score remains an internal Smart Sort diagnostic derived from normalized loudness/activity/BPM-related analysis. It is not used by Direct Sort.

## analysis.txt

Smart Sort reports retain the existing energy/flow diagnostics.

Direct Sort reports instead contain:

- sort method;
- ordered Direct Sort criteria;
- filter description;
- song count;
- Position, Artist, Title, Year, Album and Genre columns.

Direct Sort reports deliberately omit character/BPM flow diagnostics because those values do not participate in the direct ordering.

## Output and media refresh

Both engines write the same M3U8 format and use the same selected output folder. After writing, Playlist Maker requests a generic Android media refresh without a player-specific API.
