# Playlist Maker 3.4.6 — English documentation

## Application description

Playlist Maker reads one or more local Android music folders, analyzes metadata and audio characteristics, and writes deterministic `M3U8` playlists. It is a playlist-building tool, **not a music player**, and it does not depend on one playback application.

Version 3.4.6 is a presentation/identity-only update: it installs the approved launcher icon, adds an **About** dialog, and shows the version plus developer name in the bottom footer. The existing multi-library, metadata and ordering behavior is unchanged.

## Workflow

1. Select one or more local music-library roots through Android Storage Access Framework; each selected root asks whether to include all subfolders.
2. Scan audio files from every checked root, recursively only where the user enabled subfolders.
3. Read metadata; unchanged tracks may be restored from the analysis cache.
4. When required by Smart Sort analysis, decode audio and measure RMS/loudness, BPM/tempo and activity.
5. Normalize the character/energy score used by Smart Sort.
6. Optionally open **Changes & corrections** to count missing Artist / Band-Album Artist / Title / Album / Year / Genre fields, verify an existing Genre online, or edit metadata manually.
7. Choose a playlist filter: **All songs, Artist, or Genre**. Artist and Genre support scrollable multi-selection.
8. Choose an ordering engine: **Smart Sort** or **Direct Sort**.
9. Smart Sort: choose Balanced, Rising or Falling.
10. Direct Sort: all five fields are shown as rows; check ✓ the fields to use, choose each checked row direction, and vertically drag rows to set priority. At least one field always remains selected.
11. Choose the playlist filename and output folder.
12. Write `.m3u8`; optionally write the matching `analysis.txt` diagnostic file.
13. Request a generic Android media refresh for the new playlist file.

## Smart Sort

Smart Sort is the established deterministic scheduler. Its priority and formulas are intentionally unchanged in 3.3.0. It protects global artist/band spacing first and then uses the selected flow mode plus lower-priority reliable metadata/album signals.

Available flow modes remain:

- **Balanced** — distributes the smaller calm/energetic class across the list;
- **Rising** — generally starts calmer and becomes more energetic;
- **Falling** — generally starts more energetic and becomes calmer.

## Direct Sort

Direct Sort is deliberately independent from Smart Sort. When selected, the flow controls are hidden and the ordering ignores BPM, energy/character score and smart artist spacing.

The user may choose one or more criteria, up to all five:

1. Artist
2. Genre
3. Year
4. Album
5. Title

The visible order of criteria is the priority order. For example:

`Year newest→oldest -> Album A→Z -> Title A→Z`

means that Year is compared first, Album only breaks equal years, and Title only breaks equal Year+Album values.

Each criterion can be ascending/A→Z or descending/Z→A. Duplicate criteria are blocked. Missing values are always placed after known values for both ascending and descending sorts. When every selected criterion is equal, `relativePath` is used as the final deterministic tie-break.

Artist direct sorting uses the app's normalized artist identity so approved safe variants remain grouped as the same scheduling identity; it does not apply global artist spacing.

## Filter behavior

Filtering is shared by both ordering engines and always runs first:

- **All songs** — complete analyzed library;
- **Artist** — one or more normalized artist identities;
- **Genre** — one or more stored reliable Genre values.

Genre is never guessed from audio. Placeholder values such as `Unknown`, `Music`, and `People & Blogs` are omitted from the selectable Genre list.

## Multiple library roots

The Step 1 library manager keeps every granted SAF root in a checklist. Checked roots participate in the next analysis; unchecked roots remain remembered and can be re-enabled later. Android itself chooses one directory per picker invocation, so **Add library** opens the system picker for one additional root and returns to the app-managed multi-selection list. Whenever a root is newly selected, Playlist Maker asks whether to recurse through all subfolders or scan only files directly in that root.

The old single `tree_uri` setting is migrated as one checked recursive root. During discovery, overlapping roots are de-duplicated by provider/document identity. The first checked root is also retained as the legacy primary tree so an installation with no dedicated playlist-output folder continues to save to a music-library root exactly as before.

## Changes & corrections

The 3.4.x GUI has one dedicated area for all metadata changes. Missing-field song lists and existing-Genre verification lists support multi-selection plus **Select all / Clear all**. Multi-song online results are reviewed together and only explicitly checked proposals can be applied. It reports missing embedded tags by **Artist, Band / Album Artist, Title, Album, Year and Genre**. A value obtained only from filename fallback or the conservative legacy artist-to-Genre map does not hide a missing embedded tag. A user-approved internal override does satisfy the field.

For a missing field, the user first chooses the field type and then one song, several songs, or Select all. One explicit consent precedes the online lookup. The current provider is **MusicBrainz**; identification metadata such as title/artist is sent only after this opt-in. After consent, single and batch lookups run inside the resumable foreground service. Request indexes, partial results and the next pending item are persisted, so minimizing/leaving the Activity does not stop the operation and process recreation can continue from saved progress.

The **Existing Genre** workflow also checks Genre values that are already present. If MusicBrainz Genre data contains the same normalized value, the UI reports that the existing Genre is supported. Otherwise it shows `current -> suggested` with confidence. Result rows wrap to multiple lines. Confidence is advisory only: green is 85–100%, yellow is 65–84%, and red is 0–64%. A concrete red/low-confidence proposal remains selectable; only failed/no-result rows or a Genre already reported as supported cannot be applied. The approval screen supports quick selection of all, green, yellow, red, or clear. No change occurs until the user presses the explicit approve action. Genre is never inferred from audio.

The manual editor now covers all six fields and is located in the same area. Approved manual or online corrections are stored in `SharedPreferences` as per-song internal overrides. Version 3.4.5 intentionally does **not** write tag changes back into MP3/FLAC files.

MusicBrainz requests use a meaningful User-Agent and are serialized to at most one request per second. The same foreground service used for analysis and playlist creation now also owns metadata lookup and persisted lookup progress; it still never applies an override itself.

## Year metadata and old-cache compatibility

3.2.1 did not persist Year. Version 3.3.0 adds a `year` value to `Song`, cache and analysis snapshots. The value is read from Android `MediaMetadataRetriever.METADATA_KEY_YEAR` and the first plausible four-digit year is stored.

Old 3.2.1 audio-analysis cache remains valid. If an old cache or persisted snapshot has no Year field, Playlist Maker reads only Year metadata and updates the cache/snapshot when needed; it does not repeat expensive audio analysis.

Tracks without a usable Year are considered **unknown** and are placed after known years in Direct Sort, regardless of ascending/descending direction.

## Playlist output and Android refresh

The analyzed music roots and playlist output tree are separate. If no dedicated output folder is selected, the first checked music library remains the backward-compatible default. The optional diagnostic report is written beside the M3U8.

After writing, Playlist Maker performs a player-independent best-effort refresh using `ContentResolver.notifyChange()` and, where a standard external-storage path can be resolved, `MediaScannerConnection.scanFile()`. Third-party music apps may still require their own Rescan/Refresh command.

## GUI language and design

The header offers Hebrew / English language selection. Dark cards, violet accents, system-bar safe areas, compact language controls and pressed-state feedback remain. Direct Sort shows five fixed checkbox rows with direction controls and a ≡ vertical-only drag handle; at least one row must remain selected; Smart flow controls are shown only in Smart Sort.

## Background processing

`BackgroundWorkService` owns long-running analysis, playlist creation and online metadata lookup. ANALYZE tasks persist the checked library roots plus each root's subfolder choice. CREATE tasks persist the primary source/output tree, filter selection, ordering strategy, Smart flow mode, Direct Sort criteria, report preference and the analysis snapshot. Metadata lookup tasks persist selected song indexes, partial results and the next item. Process recreation therefore resumes the same operation rather than depending on the Activity.

An explicit Android Settings **Force stop** remains a platform exception: Android prevents automatic restart until the user launches the app again.

## Stability scope

Version 3.4.5 changes source-library selection and retains the 3.4.x metadata-correction workflows. Smart Sort, artist distribution, Balanced/Rising/Falling and the Direct Sort comparator/priority behavior are intentionally unchanged. It does **not** intentionally change `scheduleSmart`, global artist target spacing, the ±1 artist window, Balanced minority distribution, adaptive Rising/Falling targets, secondary Smart Sort scoring, or Smart Sort deterministic tie breaking.
