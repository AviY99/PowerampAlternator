# Playlist Maker 3.3.1 — English documentation

## Application description

Playlist Maker reads a local Android music folder, analyzes metadata and audio characteristics, and writes deterministic `M3U8` playlists. It is a playlist-building tool, **not a music player**, and it does not depend on one playback application.

Version 3.3.1 provides two separate ordering engines: the approved **Smart Sort** engine and a new strict **Direct Sort** engine.

## Workflow

1. Select a local music folder through Android Storage Access Framework.
2. Scan audio files recursively.
3. Read metadata; unchanged tracks may be restored from the analysis cache.
4. When required by Smart Sort analysis, decode audio and measure RMS/loudness, BPM/tempo and activity.
5. Normalize the character/energy score used by Smart Sort.
6. Choose a playlist filter: **All songs, Artist, or Genre**. Artist and Genre support scrollable multi-selection.
7. Choose an ordering engine: **Smart Sort** or **Direct Sort**.
8. Smart Sort: choose Balanced, Rising or Falling.
9. Direct Sort: all five fields are shown as rows; check ✓ the fields to use, choose each checked row direction, and drag rows to set priority.
10. Choose the playlist filename and output folder.
11. Write `.m3u8`; optionally write the matching `analysis.txt` diagnostic file.
12. Request a generic Android media refresh for the new playlist file.

## Smart Sort

Smart Sort is the established deterministic scheduler. Its priority and formulas are intentionally unchanged in 3.3.0. It protects global artist/band spacing first and then uses the selected flow mode plus lower-priority reliable metadata/album signals.

Available flow modes remain:

- **Balanced** — distributes the smaller calm/energetic class across the list;
- **Rising** — generally starts calmer and becomes more energetic;
- **Falling** — generally starts more energetic and becomes calmer.

## Direct Sort

Direct Sort is deliberately independent from Smart Sort. When selected, the flow controls are hidden and the ordering ignores BPM, energy/character score and smart artist spacing.

The user may choose one or more criteria, up to all five:

1. Artist
2. Genre
3. Year
4. Album
5. Title

The visible order of criteria is the priority order. For example:

`Year newest→oldest -> Album A→Z -> Title A→Z`

means that Year is compared first, Album only breaks equal years, and Title only breaks equal Year+Album values.

Each criterion can be ascending/A→Z or descending/Z→A. Duplicate criteria are blocked. Missing values are always placed after known values for both ascending and descending sorts. When every selected criterion is equal, `relativePath` is used as the final deterministic tie-break.

Artist direct sorting uses the app's normalized artist identity so approved safe variants remain grouped as the same scheduling identity; it does not apply global artist spacing.

## Filter behavior

Filtering is shared by both ordering engines and always runs first:

- **All songs** — complete analyzed library;
- **Artist** — one or more normalized artist identities;
- **Genre** — one or more stored reliable Genre values.

Genre is never guessed from audio. Placeholder values such as `Unknown`, `Music`, and `People & Blogs` are omitted from the selectable Genre list.

## Year metadata and old-cache compatibility

3.2.1 did not persist Year. Version 3.3.0 adds a `year` value to `Song`, cache and analysis snapshots. The value is read from Android `MediaMetadataRetriever.METADATA_KEY_YEAR` and the first plausible four-digit year is stored.

Old 3.2.1 audio-analysis cache remains valid. If an old cache or persisted snapshot has no Year field, Playlist Maker reads only Year metadata and updates the cache/snapshot when needed; it does not repeat expensive audio analysis.

Tracks without a usable Year are considered **unknown** and are placed after known years in Direct Sort, regardless of ascending/descending direction.

## Playlist output and Android refresh

The analyzed music tree and playlist output tree are separate. If no dedicated output folder is selected, the music folder remains the backward-compatible default. The optional diagnostic report is written beside the M3U8.

After writing, Playlist Maker performs a player-independent best-effort refresh using `ContentResolver.notifyChange()` and, where a standard external-storage path can be resolved, `MediaScannerConnection.scanFile()`. Third-party music apps may still require their own Rescan/Refresh command.

## GUI language and design

The header offers Hebrew / English language selection. Dark cards, violet accents, system-bar safe areas, compact language controls and pressed-state feedback remain. Direct Sort shows five fixed checkbox rows with direction controls and a ≡ drag handle; Smart flow controls are shown only in Smart Sort.

## Background processing

`BackgroundWorkService` owns long-running analysis/playlist creation. For CREATE tasks it persists the source/output tree, filter selection, ordering strategy, Smart flow mode, Direct Sort criteria, report preference and the analysis snapshot. Process recreation therefore resumes the same operation.

An explicit Android Settings **Force stop** remains a platform exception: Android prevents automatic restart until the user launches the app again.

## Stability scope

Version 3.3.1 keeps Direct Sort as a separate branch and changes only its selection/priority UI. It does **not** intentionally change `scheduleSmart`, global artist target spacing, the ±1 artist window, Balanced minority distribution, adaptive Rising/Falling targets, secondary Smart Sort scoring, or Smart Sort deterministic tie breaking.
