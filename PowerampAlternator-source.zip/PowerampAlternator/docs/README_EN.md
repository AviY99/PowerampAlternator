# Playlist Maker 3.1.0 — English documentation

## Application description

Playlist Maker reads a local Android music folder, analyzes metadata and audio characteristics, and creates a deterministic `M3U8` playlist intended for Poweramp. The goal is controlled distribution rather than random shuffle: artist/band spacing is protected first, while the selected flow mode shapes the character of the list.

Playlist Maker is **not a music player**. Version 3.1.0 adopts a dark, card-based visual language inspired by modern audio applications, but no playback screen, queue, transport controls or audio playback engine is added.

## Workflow

1. Select a local music folder through Android's Storage Access Framework.
2. Scan audio files recursively.
3. Read metadata; unchanged tracks may be restored from the analysis cache.
4. When required, decode audio and measure RMS/loudness, BPM/tempo and activity.
5. Normalize character/energy scores against the analyzed library.
6. Choose a playlist filter: **All songs, Artist, Genre, or Artist + Genre**.
7. Choose Balanced, Rising or Falling flow.
8. Apply the filter to the full analyzed snapshot.
9. Run the unchanged deterministic smart scheduler on that filtered subset.
10. Write `.m3u8`; optionally write `analysis.txt`.

## 3.1.0 filter behavior

Filtering is deliberately placed **before** scheduling. This keeps the approved scheduling logic isolated.

- **All songs**: the complete analyzed library participates.
- **Artist**: only songs whose normalized scheduling-artist key matches the selected artist participate.
- **Genre**: only songs carrying the selected reliable Genre participate.
- **Artist + Genre**: both conditions must match.

The Artist filter uses the same normalization rules already used by the scheduler, so harmless naming variations that already belong to one artist distribution group remain together. Genre is not inferred from audio.

The filtered task description is persisted by `BackgroundWorkService`, so if Android recreates the process while playlist creation is running, the same filter is restored before rebuilding the deterministic playlist.

## GUI languages

The header lets the user choose **עברית** or **English**. The choice is persisted and is used by controls, help text, results, errors and background notifications. Changing language recreates only the Activity and is not intended to cancel an active background task.

## GUI design

3.1.0 replaces the plain form layout with a dark step-based interface:

- near-black application background;
- rounded dark cards for Library, Analysis, Filter, Flow/Create and Results;
- violet accent for selected states and the primary Generate action;
- compact language controls;
- clear separation between primary and secondary actions;
- no copied player UI and no playback controls.

## Background processing

`BackgroundWorkService` is a foreground service that owns long-running work independently of the Activity. Task type, folder URI, progress state, filter specification and the analysis snapshot are persisted. If Android recreates the service, it can reconstruct the task. The WakeLock helps CPU availability but is not the sole recovery mechanism.

An explicit Android Settings **Force stop** is a platform exception: Android prevents automatic restart until the user launches the app again.

## Genre rule

Genre participates only when it comes from file metadata, a manual correction, or a conservative trusted-artist mapping. Genre is never guessed from audio alone. Placeholder values such as `Unknown`, `Music`, and `People & Blogs` are omitted from the selectable Genre filter list.

## Stability scope

3.1.0 does **not** intentionally change artist target spacing, the ±1 artist window, Balanced minority distribution, adaptive Rising/Falling targets, secondary Genre/album/version scoring, or deterministic tie breaking.
