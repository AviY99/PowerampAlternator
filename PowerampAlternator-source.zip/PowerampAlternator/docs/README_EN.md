# Playlist Maker 3.0.0 — English documentation

## Application description

Playlist Maker reads a local Android music folder, analyzes metadata and audio characteristics, and creates a deterministic `M3U8` playlist intended for Poweramp. The goal is controlled distribution rather than random shuffle: artist/band spacing is protected first, while the selected flow mode shapes the character of the list.

## Workflow

1. The user selects a music folder through Android's Storage Access Framework.
2. Audio files are scanned recursively.
3. File metadata is read; unchanged tracks can be restored from the analysis cache.
4. When required, audio is decoded and RMS/loudness, BPM/tempo and activity are measured.
5. Character/energy scores are normalized against the current library.
6. The user selects Balanced, Rising or Falling flow.
7. The scheduler creates a global artist/band distribution first, then chooses the best song inside the permitted artist window using flow and secondary distribution signals.
8. The app writes `.m3u8`; an `analysis.txt` diagnostic file is optional.

## GUI languages

The top of the screen lets the user choose **עברית** or **English**. The choice is persisted in SharedPreferences and is used by controls, help text, results, errors and background notifications. Changing language recreates only the Activity and is not intended to cancel an active background task.

## Background processing

`BackgroundWorkService` is a foreground service that owns long-running work independently of the Activity. Task type, folder URI, progress state and the analysis snapshot are persisted. If Android recreates the service, it can reconstruct the task. The WakeLock helps CPU availability but is not the sole recovery mechanism.

An explicit Android Settings **Force stop** is a platform exception: Android prevents automatic restart until the user launches the app again.

## Genre rule

Genre contributes to distribution only when it is considered reliable: file metadata, a manual correction, or a conservative trusted-artist mapping. Genre is never guessed from audio alone.

## 3.0.0 stability scope

3.0.0 is based on the playlist engine approved in 0.2.8. This release adds localization and documentation only; artist spacing formulas, the artist window, Balanced logic and adaptive Rising/Falling targets are unchanged.
