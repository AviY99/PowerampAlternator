# Playlist Maker 3.2.1 — English documentation

## Application description

Playlist Maker reads a local Android music folder, analyzes metadata and audio characteristics, and creates a deterministic `M3U8` playlist. It is designed as a playlist-building tool rather than a player and does not depend on one specific playback application.

The goal is controlled distribution instead of random shuffle: artist/band spacing is protected first, while the selected flow mode shapes the character of the list.

Playlist Maker is **not a music player**. The dark card-based interface contains no playback screen, queue, transport controls or audio playback engine.

## Workflow

1. Select a local music folder through Android's Storage Access Framework.
2. Scan audio files recursively.
3. Read metadata; unchanged tracks may be restored from the analysis cache.
4. When required, decode audio and measure RMS/loudness, BPM/tempo and activity.
5. Normalize character/energy scores against the analyzed library.
6. Choose a playlist filter: **All songs, Artist, or Genre**. Artist and Genre each support selecting multiple entries from a scrollable checked list.
7. Choose Balanced, Rising or Falling flow.
8. Apply the filter to the full analyzed snapshot.
9. Run the unchanged deterministic smart scheduler on the filtered subset.
10. Choose a playlist save folder, or keep the music folder as the default.
11. Write `.m3u8`; optionally write `analysis.txt` beside it.
12. Request a generic Android media refresh for the new playlist file.

## 3.2.1 output-folder behavior

The analyzed music tree and the playlist output tree are now separate concepts.

- If no dedicated output folder has been selected, the music folder remains the output location for backward compatibility.
- **Choose / change** stores a persistent SAF permission for a dedicated playlist folder.
- **Music folder** clears the dedicated output preference and returns to the previous behavior.
- The active output folder is shown directly in the Flow & Create card.
- `BackgroundWorkService` persists the output URI with a CREATE task, so process recreation continues writing to the same destination.
- The optional diagnostic report is written to the same output tree as the M3U8.

## Generic Android media refresh

After the M3U8 is written, Playlist Maker performs a best-effort, player-independent refresh:

- it calls `ContentResolver.notifyChange()` for the new SAF document;
- when the document maps to standard primary or removable external storage, it also calls `MediaScannerConnection.scanFile()` for the exact M3U8 path.

This deliberately avoids any Poweramp-specific or other player-specific API. Some third-party music apps maintain their own private library index, so they may still require their own Rescan/Refresh command.

## Filter behavior

Filtering is deliberately placed **before** scheduling so the approved scheduling logic remains isolated.

- **All songs**: the complete analyzed library participates.
- **Artist**: songs participate when their normalized scheduling-artist key belongs to the selected artist set.
- **Genre**: songs participate when their reliable stored Genre belongs to the selected Genre set.

The Artist filter reuses the scheduler's normalization and accepts one or more selected artists. Genre filtering accepts one or more stored reliable Genre values and never infers Genre from audio. Placeholder values such as `Unknown`, `Music`, and `People & Blogs` are omitted from the selectable Genre list.

## GUI languages and design

The header lets the user choose Hebrew or English. The choice is persisted and is used by controls, help text, results, errors and background notifications.

The visual refinements remain in 3.2.1: dark cards, violet accents, system-bar safe areas, a compact language selector, progressive filter controls, cached filter-count calculation and pressed-state feedback.

## Background processing

`BackgroundWorkService` is a foreground service that owns long-running work independently of the Activity. Task type, source folder URI, output folder URI for CREATE tasks, progress state, filter specification and the analysis snapshot are persisted. If Android recreates the service, it can reconstruct the task.

An explicit Android Settings **Force stop** remains a platform exception: Android prevents automatic restart until the user launches the app again.

## Genre rule

Genre participates only when it comes from file metadata, a manual correction, or a conservative trusted-artist mapping. Genre is never guessed from audio alone.

## Stability scope

3.2.1 does **not** intentionally change artist target spacing, the ±1 artist window, Balanced minority distribution, adaptive Rising/Falling targets, secondary Genre/album/version scoring or deterministic tie breaking. The only filter-stage semantic change is single-selection → multi-selection.
